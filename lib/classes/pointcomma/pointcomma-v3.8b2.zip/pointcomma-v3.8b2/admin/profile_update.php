<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcinput.php');
include('lib/adminlib.inc.php');

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // timeout protection: selected values will be kept
  echo makeLoginForm('notloggedin', 'profile_update.php', $HTTP_POST_VARS);
  exit();
}
// comment : this part makes the form to change the profile in the db according to the
//           profile selected in the jump menu.

if ($profileId == 'new') {
  $action = 'new';
}
else {
  $rsCurrentSelectedProfile = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'profiles` WHERE profileId='.addslashes($profileId));
  $currentProfile = $rsCurrentSelectedProfile[0];
  $moduleId = $currentProfile['moduleId'];
}
if (!$clearance['isModuleSupervisor'][$moduleId]) {
  echo makeLoginForm('authtoolow', 'module.php?moduleId='.$moduleId);
  exit();
}


switch ($action){

  case 'new':
    if ($password != '') {
      $password = '\''.md5($password).'\'';
    } else {
      $password = 'NULL';
    }
    if ($newProfileId = pcdb_insert('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'profiles` (moduleId, description, label, requireAdminConfirm, password) VALUES(\''.addslashes($moduleId).'\', \''.addslashes($description).'\', \''.addslashes($label).'\', \''.addslashes($requireAdminConfirm).'\', '.$password.')')) {
      setGlobal('lastAdminUpdateOn', time());
      setGlobal('lastAdminUpdateBy', $clearance['userName']);
      header("Location: profile.php?profileId=$newProfileId&pcAdminMsg=newprofilesuccess");
      exit;
    }
    else {
      header("Location: module.php?moduleId=$moduleId&pcAdminMsg=errnewprofile");
      exit();
    }
  break;

  case 'params':
    if ($password != '') {
      $password = ', password=\''.md5($password).'\'';
    }
    if ($removePassword==1) {
      $password = ', password=NULL';
    }
    if (pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'profiles` SET label=\''.addslashes($label).'\', description=\''.addslashes($description).'\', requireAdminConfirm=\''.addslashes($requireAdminConfirm).'\', adminEmail=\''.addslashes($adminEmail).'\''.$password.' WHERE profileId='.addslashes($profileId))) {
      setGlobal('lastAdminUpdateOn', time());
      setGlobal('lastAdminUpdateBy', $clearance['userName']);
      header("Location: profile.php?profileId=".$profileId."&pcAdminMsg=paramprofilesuccess");
    }
    else {
      header("Location: profile.php?profileId=$profileId&pcAdminMsg=errparamprofile");
      exit();
    }
  break;

  case 'msgs':
    if (pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'profiles` SET confirmMsg=\''.addslashes($confirmMsg).'\', signupMsg=\''.addslashes($signupMsg).'\', adminMsg=\''.addslashes($adminMsg).'\', passwdMsg=\''.addslashes($passwdMsg).'\', confirmSubj=\''.addslashes($confirmSubj).'\', signupSubj=\''.addslashes($signupSubj).'\', adminSubj=\''.addslashes($adminSubj).'\', passwdSubj=\''.addslashes($passwdSubj).'\' WHERE profileId='.addslashes($profileId))) {
      setGlobal('lastAdminUpdateOn', time());
      setGlobal('lastAdminUpdateBy', $clearance['userName']);
      header("Location: profile.php?profileId=".$profileId."&pcAdminMsg=msgsprofilesuccess");
    }
    else {
      header("Location: profile.php?profileId=$profileId&pcAdminMsg=errmsgsprofile");
      exit();
    }
  break;

  case 'del':
    if ($sure){
      if (pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'profiles` WHERE profileId='.addslashes($profileId))){
        setGlobal('lastAdminUpdateOn', time());
        setGlobal('lastAdminUpdateBy', $clearance['userName']);
        header("Location: module.php?moduleId=$moduleId&pcAdminMsg=delprofilesuccess");
      }
      else {
        header("Location: profile.php?profileId=$profileId&pcAdminMsg=errdelprofile");
      }
    }
    else{
      header("Location: profile.php?profileId=$profileId&pcAdminMsg=abort");
    }
  break;

  case 'roles':
    $rolesForQuery = array();
    foreach ($setDefaultRoles as $roleId => $confirm) {
      if ($confirm) {
        $rolesForQuery[] = addslashes($roleId);
      }
    }
    if (pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'profiles` SET defaultRoles=\''.implode(';', $rolesForQuery).'\' WHERE profileId='.$profileId,__FILE__,__LINE__)) {
      setGlobal('lastAdminUpdateOn', time());
      setGlobal('lastAdminUpdateBy', $clearance['userName']);
      header("Location: profile.php?profileId=$profileId&pcAdminMsg=setprofilesuccess");
    }
    else {
      header("Location: profile.php?profileId=$profileId&pcAdminMsg=errsetprofile");
    }

  break;
}
?>

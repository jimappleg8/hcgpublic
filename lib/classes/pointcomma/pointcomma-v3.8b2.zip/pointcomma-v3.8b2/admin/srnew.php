<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcuserlib.inc.php');
include('lib/adminlib.inc.php');

echo pageHeader('Register as a new user');
pcErrorDisplay(WARNING);
if (!isset($userName)) {
  // Display form
?>
<form name="create" action="srnew.php" method="post">
<table border="0">
<tr><td>User name:</td><td><input type="text" name="userName"></td></tr>
<tr><td>Password:</td><td><input type="password" name="password"></td></tr>
<tr><td>First name:</td><td><input type="text" name="firstName"></td></tr>
<tr><td>Last name:</td><td><input type="text" name="lastName"></td></tr>
<tr><td>Email:</td><td><input type="text" name="eMail"></td></tr>
<tr><td></td><td><input type="submit" value="register"></td></tr>
</table>
</form>
<?php
} else {
  // Do creation
  if (pcCreateUser('admin', $userName, $password, $firstName, $lastName, $eMail)) {
    echo '<p>&nbsp;<br><b>Success</b><br>You have been successfully registered as a new PointComma user. Please check your email and confirm your registration.<br>&nbsp;</p>';
  } else {
    echo '<p>&nbsp;<br><b>Error</b><br>Registration failed, sorry: '.$pcCreateUserLog.'.<br>&nbsp;</p>';
  }
}

echo pageFooter();
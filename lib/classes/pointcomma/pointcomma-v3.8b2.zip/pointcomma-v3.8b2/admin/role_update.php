<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcinput.php');
include("lib/adminlib.inc.php");


$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
	// timeout protection: entered values will be kept and re-submitted
	echo makeLoginForm('notloggedin', 'role_update.php', $_POST);
	exit();
}
// comment : this part makes the form to change the role in the db according to the
//           role selected in the jump menu.
$action = pcDefaultValue('string', '', 'action', 'P');
$roleId = pcDefaultValue('pcId', 0, 'roleId', 'P');
$moduleId = pcDefaultValue('pcStrId', 0, 'moduleId', 'P');
$description = pcDefaultValue('string', '', 'description', 'P');
$label = pcDefaultValue('string', 'no label', 'label', 'P');
$isModuleSupervisor = pcDefaultValue('bool', 0, 'isModuleSupervisor', 'P');
$isModuleMgr = pcDefaultValue('bool', 0, 'isModuleMgr', 'P');
$addType = pcDefaultValue('array', array(), 'addType', 'P');
$addAssignment = pcDefaultValue('array', array(), 'addAssignment', 'P');
$sure = pcDefaultValue('bool', 0, 'sure', 'P');

if ($roleId == 'new') {
	$action = 'new';
} else {
	$rsCurrentSelectedRole = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE roleId='.addslashes($roleId));
	$currentRole = $rsCurrentSelectedRole[0];
	$moduleId = $currentRole['moduleId'];
}
if (!$clearance['isModuleSupervisor'][$moduleId]) {
	echo makeLoginForm('authtoolow', 'module.php?moduleId='.$moduleId);
	exit();
}


switch ($action){

	case 'new' :
		if($newRoleId = pcdb_insert('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'roles` (moduleId, description, label, isModuleSupervisor, isModuleMgr) VALUES(\''.addslashes($moduleId).'\', \''.addslashes($description).'\', \''.addslashes($label).'\', '.addslashes($isModuleSupervisor).', '.addslashes($isModuleMgr).')')){
			setGlobal('lastAdminUpdateOn', time());
			setGlobal('lastAdminUpdateBy', $clearance['userName']);
			header("Location: role.php?roleId=$newRoleId&pcAdminMsg=newrolesucces");
			exit();
		} else {
			header("Location: module.php?moduleId=$moduleId&pcAdminMsg=newrolefail");
			exit();
		}
		break;

	case 'edit' :
		// make nice error
		pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'roles` SET label=\''.addslashes($label).'\', description=\''.addslashes($description)."', isModuleSupervisor='" .addslashes($isModuleSupervisor) ."', isModuleMgr='".addslashes($isModuleMgr)."' WHERE roleId=".addslashes($roleId));
		setGlobal('lastAdminUpdateOn', time());
		setGlobal('lastAdminUpdateBy', $clearance['userName']);
		header("Location: role.php?roleId=".$roleId."&pcAdminMsg=updaterolesucces");
	break;

	case 'del' :
		if ($sure){
			if (deleteRole($roleId)){
				setGlobal('lastAdminUpdateOn', time());
				setGlobal('lastAdminUpdateBy', $clearance['userName']);
				header("Location: module.php?moduleId=$moduleId&pcAdminMsg=delrolesucces");
			} else {
				header("Location: role.php?roleId=$roleId&pcAdminMsg=delrolefail");
			}
		} else{
			header("Location: role.php?roleId=$roleId&pcAdminMsg=abort");
		}
	break;
		
	case 'auth' :
		// Maintain the authorizations provided by this role
		// First drop all authorizations (ugly but simpler)
		$rsDropAllAuths = pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'authorizations` WHERE roleId='.addslashes($roleId));
		$rsAllModuleTypes = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId=\''.addslashes($moduleId).'\'');
		for($i=0;$i<count($rsAllModuleTypes);$i++){
			// The for each type, set authorization
			$currentTypeId = $rsAllModuleTypes[$i]['typeId'];
			if ($addType[$currentTypeId] > 0) {
				pcdb_query('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'authorizations` SET roleId='.addslashes($roleId).', typeId LIKE \''.addslashes($currentTypeId).'\', writelevel='.addslashes($addType[$currentTypeId]));
			}
		}
		setGlobal('lastAdminUpdateOn', time());
		setGlobal('lastAdminUpdateBy', $clearance['userName']);
		header("Location: role.php?roleId=".$roleId."&pcAdminMsg=updateauthsucces");
		exit();
	break;

	case 'assign' :
		// First drop all authorizations (ugly but simpler)
		$rsDropAllAuths = pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'assignments` WHERE roleId='.addslashes($roleId));
		$rsAllUsers = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'webusers');
		for($i=0;$i<count($rsAllUsers);$i++){
			// The for each type, set authorization
			$currentUser = $rsAllUsers[$i]['userName'];
			if ($addAssignment[$currentUser] > 0) {
				pcdb_query('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'assignments` SET roleId='.addslashes($roleId).', userName=\''.addslashes($currentUser).'\'');
			}
		}
		setGlobal('lastAdminUpdateOn', time());
		setGlobal('lastAdminUpdateBy', $clearance['userName']);
		header("Location: role.php?roleId=".$roleId."&pcAdminMsg=updateauthsucces");
		exit();
	break;

}
?>
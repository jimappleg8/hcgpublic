<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcinput.php');
include("lib/adminlib.inc.php");

$action = pcDefaultValue('string', '', 'action', 'P');
$pubState = pcDefaultValue('numeric', 1, 'pubState', 'P');
$typeId = pcDefaultValue('pcTypeId', 0, 'typeId', 'P');
$itemId = pcDefaultValue('pcId', 0, 'itemId', 'P');
$chars = pcDefaultValue('array', array(), 'chars', 'P');

if (empty($itemId)) {
  header('Location: ./?pcAdminMsg=erritemnotspecified');
  exit();
}

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // User must be logged in
  echo makeLoginForm('notloggedin', "item.php", $HTTP_POST_VARS);
  exit();
}

// Let's try to identify the item, its type and its module
if ($itemId == 'new') {
  // New item
  if (!$clearance['rights'][$typeId]) {
    // User must have some rights to this type
    echo makeLoginForm('authtoolow2');
    exit();
  }

  $typeQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId=\''.addslashes($typeId).'\'');
  $type = $typeQuery[0];

}
else {
  // Existing item
  if (!$itemQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE itemId='.addslashes($itemId))) {
    header('Location: ./?pcAdminMsg=errwrongitem');
    exit();
  }
  $item = $itemQuery[0];

  if (!$clearance['rights'][$item['typeId']]) {
    // User must have some rights to this type
    echo makeLoginForm('authtoolow3');
    exit();
  }
  if ($clearance['rights'][$item['typeId']] < 2 && ($clearance['userName'] != $item['createdBy'] || $clearance['userName'] != $item['lastUpdateBy'] || $item['pubState'] > 1)) {
    // Submitters may only access their own submissions, while they are still in submitted state
    // TODO create a different error message for the different errors
    echo makeLoginForm('authtoolow1');
    exit();
  }

  if ((!$typeQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId=\''.addslashes($item['typeId']).'\'')) || (addslashes($typeId) != addslashes($item['typeId']))) {
    header('Location: ./?pcAdminMsg=errwrongtype');
    exit();
  }
  $type = $typeQuery[0];

}
// End identification

// Limit the publishing rights of submitters
if ($clearance['rights'][$type['typeId']] < 2) {
  $pubState = 10;
}

if ($action == 'del') {
  $pubState = 0;
}

if ($returnTo = writeItem($itemId, $pubState, $typeId, $chars)) {
  
  // Now see where the user wants to be taken
  switch ($action) {
    case 'save':
      header("Location: item.php?itemId=$returnTo&pcAdminMsg=itemsaved");
    break;

    case 'close':
      header("Location: type.php?typeId=".$type['typeId']."&pcAdminMsg=itemsaved");
    break;

    case 'modif':
      header("Location: item.php?itemId=$returnTo$pcRedirectBottomAnchor");
    break;

    case 'del':
      header("Location: type.php?typeId=".$type['typeId']."&pcAdminMsg=itemdeleted");
    break;

    default:
      header("Location: item.php?itemId=$returnTo");
    break;

  }
}
else {
  echo pageHeader('Error');
  pcErrorDisplay(WARNING);
  echo "<p><a href=\"JavaScript:history.go(-1)\">Return</a></p>\n";
  echo pageFooter();
}

?>
<?php

$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcuserlib.inc.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcinput.php');
include("lib/adminlib.inc.php");

$action = pcDefaultValue('string', '', 'action', 'P');
$moduleId = pcDefaultValue('pcStrId', '', 'moduleId', 'P');
$isSupervisor = pcDefaultValue('bool', 0, 'isSupervisor', 'P');
$isFrameworkMgr = pcDefaultValue('bool', 0, 'isFrameworkMgr', 'P');
$password = pcDefaultValue('string', '', 'password', 'P');
$cpassword = pcDefaultValue('string', '', 'cpassword', 'P');
$new_password = pcDefaultValue('string', '', 'new_password', 'P');
$confirm_password = pcDefaultValue('string', '', 'confirm_password', 'P');
$firstName = pcDefaultValue('string', '', 'firstName', 'P');
$lastName = pcDefaultValue('string', '', 'lastName', 'P');
$userName = pcDefaultValue('string', '', 'userName', 'P');
$submitEMail = pcDefaultValue('string', '', 'submitEMail', 'P');
$addRoles = pcDefaultValue('array', array(), 'addRoles', 'P');
$sure = pcDefaultValue('bool', 0, 'sure', 'P');

$clearance = unserialize(CLEARANCE);

// comment : this part makes the form to change the role in the db according to the
//           role selected in the jump menu.

$canSeeUsers = $clearance['isSupervisor'];
foreach ($clearance['isModuleSupervisor'] as $oneModuleSup) {
	if ($oneModuleSup) {
		$canSeeUsers = true;
	}
}
$action = pcDefaultValue('string',false,'action', "PG");

if ($action == 'new') {
	if (!$clearance['isSupervisor'] && ($isSupervisor || $isFrameworkMgr)) {
		header("Location: user.php?userName=$userName&moduleId=$moduleId&pcAdminMsg=errauthtoolow");
		exit();
	}
	$selectedUser = array(
		'userName' => pcDefaultValue('string', false, 'userName', "PG"),
		'isSupervisor' => $isSupervisor,
		'isFrameworkMgr' => $isFrameworkMgr
	);
} else {
	$rsCurrentSelectedUser = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'webusers` WHERE userName=\''.addslashes($userName).'\'');
	$selectedUser = $rsCurrentSelectedUser[0];
}

if (!$clearance['isSupervisor'] && $userName != $clearance['userName'] && ($selectedUser['isFrameworkMgr'] || $selectedUser['isSupervisor'])) {
	header("Location: user.php?userName=$userName&moduleId=$moduleId&pcAdminMsg=errauthtoolow");
	exit();
}

$action = pcDefaultValue("string", false, 'action', "PG");

switch ($action){

	case 'new' :

		// check if username is unique, but it does not work, itl hang on the insert query, need
		// to fix this but has no priority !!!
		if (pcdb_select('SELECT userName FROM `'.addslashes($pcConfig['dbPrefix']).'webusers` WHERE userName=\''.addslashes($selectedUser['userName']).'\'')) {
			header("Location: user.php?moduleId=$moduleId&action=new&pcAdminMsg=erruserexists");
			exit;
		} else {
			// check if the passwords are the same
			if($password == $cpassword){
				// update database
				if(pcdb_query('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'webusers` SET userName=\''.addslashes($selectedUser['userName'])."', password='".md5($password)."', `status`=2, firstName='".addslashes($firstName)."', lastName='".addslashes($lastName)."', createdBy='".addslashes($clearance['userName'])."', isSupervisor='".addslashes($selectedUser['isSupervisor'])."', isFrameworkMgr='".addslashes($selectedUser['isFrameworkMgr'])."'")) {
					if (!pcSendEmailToken('admin', $userName, $submitEMail)) {
						header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&userName='.$userName.'&pcAdminMsg=newusersucces,erremail,'.$pcCreateUserLog);
						exit();
					}
					header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&userName='.$userName.'&pcAdminMsg=newusersucces&mailsuccess');
					exit();
				} else {
					header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&pcAdminMsg=errnewuserfail');
					exit();
				}
			} else {
				header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&pcAdminMsg=errpasswdnomatch');
				exit();
			}
		}

	break;

	case 'edit' :
		if(pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'webusers` SET firstName=\''.addslashes($firstName)."', lastName='".addslashes($lastName)."', isSupervisor='".addslashes($isSupervisor)."', isFrameworkMgr='".addslashes($isFrameworkMgr)."' WHERE userName='".addslashes($userName)."'")) {
			setGlobal('lastAdminUpdateOn', time());
			setGlobal('lastAdminUpdateBy', $clearance['userName']);
			if (isset($changeEMail)) {
				if (!pcSendEmailToken('admin', $userName, $changeEMail)) {
					header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&pcAdminMsg=updateusersucces&mailfailure,'.$pcCreateUserLog);
					exit();
				}
				header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&pcAdminMsg=updateusersucces&mailsuccess');
				exit();
			}
			header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&pcAdminMsg=updateusersucces');
			exit();
		} else {
			header('Location: user.php?moduleId='.$moduleId.'&userName='.$userName.'&pcAdminMsg=errupdateuserfail');
		}
		exit();
	break;

	case 'assign' :

		$rsAllModuleRoles = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
		foreach ($rsAllModuleRoles as $oneRole){
			pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'assignments` WHERE roleId='.addslashes($oneRole['roleId']).' && userName=\''.addslashes($userName).'\'');
			if($addRoles[$oneRole['roleId']] == 1){
				pcdb_query('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'assignments` SET roleId='.addslashes($oneRole['roleId']).', userName=\''.addslashes($userName).'\'');
			}
		}
		setGlobal('lastAdminUpdateOn', time());
		setGlobal('lastAdminUpdateBy', $clearance['userName']);
		header("Location: user.php?moduleId=$moduleId&userName=$userName&pcAdminMsg=savedassignments");
		exit();
	break;

	case 'passwd':
		if ($new_password != $confirm_password) {
			// Passwords don't match
			header("Location: user.php?userName=$userName&action=passwd&moduleId=$moduleId&pcAdminMsg=errpasswdnomatch");
			exit();
		}
		if ($userName == $clearance['userName'] && !pcdb_select('SELECT userName FROM `'.addslashes($pcConfig['dbPrefix']).'webusers` WHERE userName = \''.addslashes($userName)."' && password='".md5($current_password)."'")) {
			// Wrong old password
			header("Location: user.php?userName=$userName&action=passwd&moduleId=$moduleId&pcAdminMsg=errpassoldwrong");
			exit();
		}
		// Do the changes
		if (pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'webusers` SET password=\''.md5($new_password)."' WHERE userName='".addslashes($userName)."'")) {
			setGlobal('lastAdminUpdateOn', time());
			setGlobal('lastAdminUpdateBy', $clearance['userName']);
			header("Location: user.php?userName=$userName&moduleId=$moduleId&pcAdminMsg=passwdchanged");
			exit();
		} else {
			header("Location: user.php?userName=$userName&action=passwd&moduleId=$moduleId&pcAdminMsg=errupdateuserfailed");
			exit();
		}
	break;

	case 'reactivate':
		if ($sure){
			if (pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'webusers` SET status=(status-4) WHERE userName=\''.addslashes($userName).'\' && status>3')) {
				setGlobal('lastAdminUpdateOn', time());
				setGlobal('lastAdminUpdateBy', $clearance['userName']);
				header("Location: user.php?moduleId=$moduleId&userName=$userName&pcAdminMsg=reactivateusersuccess");
				exit();
			} else {
				header("Location: user.php?moduleId=$moduleId&userName=$userName&pcAdminMsg=errreactivateuserfail");
				exit();
			}
		} else{
			header("Location: user.php?moduleId=$moduleId&userName=$userName&pcAdminMsg=abort");
			exit();
		}
	break;

	case 'freeze' :

		if ($sure){
			if (pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'webusers` SET status=(status+4) WHERE userName=\''.addslashes($userName).'\' && status<4')) {
				setGlobal('lastAdminUpdateOn', time());
				setGlobal('lastAdminUpdateBy', $clearance['userName']);
				header("Location: user.php?moduleId=$moduleId&userName=$userName&pcAdminMsg=freezeusersucces");
				exit();
			} else {
				header("Location: user.php?moduleId=$moduleId&userName=$userName&pcAdminMsg=errfreezeuserfail");
				exit();
			}
		} else{
			header("Location: user.php?moduleId=$moduleId&userName=$userName&pcAdminMsg=abort");
			exit();
		}
	break;
}

?>
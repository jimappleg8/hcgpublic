<?php

require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
include("lib/htmllib.inc.php");

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // User must be logged in
  echo makeLoginForm('debugpage','test.php');
	exit();
} else {
	
	//only a framework manager can play with debugging
	if (!$clearance['isFrameworkMgr']) {
    header('Location: index.php?pcAdminMsg=errauthtoolow');
    exit();
  }
	
	//Form processing
  if (isset($_POST['pcResetStack'])) {
		$tempStack = new messageStack('debug');
		$tempStack->resetStack();
		unset($tempStack);
	}
	
	if (isset($_POST['pcDebugSwitch'])) {
    
 	// Manual Debug ON/OFF 
  $_SESSION['pcDebugDisplay'] = ($_POST['pcDebugSwitch'])?true:false;
  }
}
echo pageHeader("Debugging page");
?>
<script type="text/javascript">
function openPopUp() {
window.open("<?php echo $pcConfig['adminServer'];?>debug.php","PointCommaDebugConsole","width=680,height=600,resizable,scrollbars=yes",true);
}
</script>
<form action="test.php" method="post">
<div>
<fieldset style="float: left;height:60px;">
<legend>Display Debug info</legend>
<input type="radio" name="pcDebugSwitch" value="1" id="pcDebugSwitchOn" <?php if (isset($_SESSION['pcDebugDisplay']) and $_SESSION['pcDebugDisplay']) { echo ' checked="checked"'; } ?> />On<br />
<input type="radio" name="pcDebugSwitch" value="0" id="pcDebugSwitchOff" <?php if (isset($_SESSION['pcDebugDisplay']) and !$_SESSION['pcDebugDisplay']) { echo ' checked="checked"'; } ?> />Off
</fieldset>
<fieldset style="float: left;height:60px;">
<legend>Reset the Debug Stack</legend>
<input type="checkbox" name="pcResetStack" value="reset" id="pcResetStack" />Ok?<br />
</fieldset>  
<a style="margin: 0 0 0 40px;height:60;" href="javascript:openPopUp()">Open the Debug PopUp</a><br/>
</div>

<div style="display: block; clear: both; padding-top: 1em;">
<input type="submit" value="set"/>
</div>
</form>
</body></html>
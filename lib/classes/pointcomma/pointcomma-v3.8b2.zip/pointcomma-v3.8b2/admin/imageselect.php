<?php
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
include("lib/htmllib.inc.php");

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // User must be logged in
  echo makeLoginForm('imagebrowser','imagebrowser.php');
  exit();
}

// output of normal page header
echo pageHeader("Image Browser");

// shortening of the image path
$image_directory = $pcConfig['upload']['path']."images";
$image_path = $pcConfig['productionServer'].$image_directory;
$image_directory = $pcConfig['upload']['adminOffset'].$image_directory;
// check if the image directory exists
// these error messages must be cleaned up later -> make real html
// maybe drop an email.. or try to create the directory
if (!is_dir($image_directory)) {
    print "<div class='error'>Image directory error!<br />Please contact your site administrator.</div><div>image directory: $image_directory is not a directory</div>";
    exit;
} elseif (!is_writable($image_directory)) {
    print "<div class='error'>Image directory rights error!<br />Please contact your site administrator.</div><div>image directory: $image_directory is not writable</div>";
    exit;
}

// see if the page is called correctly
if (!isset($_GET['rte'])){
    $_GET['rte'] = "";
}

// handle file uploads
if (isset($_POST['upload-submit'])&&!empty($_POST['upload-submit'])) {
    if (!isset($HTTP_POST_FILES['uploadfile']['error'])
        || ($HTTP_POST_FILES['uploadfile']['error'] != "2") // check filesize
    ) {
    	// upload kopieren
        $tempname = $HTTP_POST_FILES['uploadfile']['name'];
    	$tempmime = $HTTP_POST_FILES['uploadfile']['type'];
    	$tempsize = $HTTP_POST_FILES['uploadfile']['size'];
    	$temptmpn = $HTTP_POST_FILES['uploadfile']['tmp_name'];
        if (!isset($_POST['destination']) || empty($_POST['destination']) || !file_exists($_POST['destination'])) {
            if (!getimagesize($temptmpn)) {
           		$file_message = "File is not an image.";
            } else {
                $_POST['destination'] = realpath($image_directory);
            	if (move_uploaded_file($temptmpn,  $_POST['destination']."/$tempname")) {
            		$file_message = "Image upload success.";
            	} else {
            		$file_message = "Image upload failure, the server fucked up.";
            	}
            }
        }
    } else {
        $file_message = "File is to large, max size is ".round($_POST['MAX_FILE_SIZE']/1024)."Kb. Please try again after compressing it again.";
    }
}

$image_ext = array('.jpg','.gif','.png','.jpeg');

$image_template = "
        <div class=\"thumbcontainer\">
            <table>
				<tr>
					<td>
					<a href=\"%1\$s\" onClick=\"selectImage('%1\$s','%4\$s','%2\$s','%3\$s');\" title=\"select\"><img src=\"%1\$s\" width=\"160\" height=\"120\" alt=\"%1\$s\" /></a>
					</td>
				</tr>
                <tr>
                    <td>%4\$s</td>
				</tr>
                <tr>
                    <td>
            <a href=\"#\" onClick=\"selectImage('%1\$s','%4\$s','%2\$s','%3\$s','left');\" title=\"select left aligned\">&lt;</a>
            <a href=\"#\" onClick=\"selectImage('%1\$s','%4\$s','%2\$s','%3\$s','');\" title=\"select normal alignement\">select this</a>
            <a href=\"#\" onClick=\"selectImage('%1\$s','%4\$s','%2\$s','%3\$s','right');\" title=\"select right aligned\">&gt;</a>
            <a href=\"#\" onClick=\"popupImage('%1\$s','%4\$s','%2\$s','%3\$s');\" title=\"select\">preview this</a></td>
                </tr>
            </table>
        </div>
";
// sort a multidimensional array
/*
syntax:
$new_array = array_multisort($array [, 'col1' [, SORT_FLAG [, SORT_FLAG]]]...);

explanation:
$array is the array you want to sort, 'col1' is the name of the column you want to sort, SORT_FLAGS are : SORT_ASC, SORT_DESC, SORT_REGULAR, SORT_NUMERIC, SORT_STRING
you can repeat the 'col',FLAG,FLAG, as often you want, the highest prioritiy is given to the first - so the array is sorted by the last given column first, then the one before ...

example:
in my case the array has it's index as first dimension (i like that for using foreach later):

$array[0]['name'] = "Niko";
$array[0]['age'] = 24;
$array[0]['town'] = "Berlin";
$array[1]['name'] = "Dennis";
$array[1]['age'] = 34;
$array[1]['town'] = "Berlin";
$array[2]['name'] = "Oliver";
$array[2]['age'] = 44;
$array[2]['town'] = "Aachen";
$array[3]['name'] = "Andi";
$array[3]['age'] = 34;
$array[3]['town'] = "Berlin";

use the function like this:
$array = array_csort($array,'town','age',SORT_DESC,'name');
*/

function multisort() {  //coded by Ichier2003
    $args = func_get_args();
    $marray = array_shift($args);
    $i = '';
    $msortline = "return(array_multisort(";
    foreach ($args as $arg) {
       $i++;
       if (is_string($arg)) {
           foreach ($marray as $row) {
               $sortarr[$i][] = $row[$arg];
           }
       } else {
           $sortarr[$i] = $arg;
       }
       $msortline .= "\$sortarr[".$i."],";
    }
    $msortline .= "\$marray));";

    eval($msortline);
    return $marray;
}
function GetDirArray($imgpath, $imgext, $imgtemplate) {
    $imgext= '';
		$imgtemplate = '';
	/* debug
    print "<div class=\"debug\">
    <strong>relative path</strong> ".$imgpath."<br />\n
    <strong>real path </strong>".realpath($imgpath)."<br />\n
    </div>";
    /* end debug */
    $imgs = array();
	//Load Directory Into Array 
	$handle=opendir($imgpath);
	while ($file = readdir($handle)) {
        //$retVal[] = $file;
        $imgloc = $imgpath."/".$file;
        if ($fileimg = @getimagesize($imgloc)) {
    		$imgs[$file]['filename'] = $file;
    		$imgs[$file]['path'] = dirname($imgloc);
            $imgs[$file]['ctime'] = filectime($imgloc);
            $imgs[$file]['mtime'] = filemtime($imgloc);
            $imgs[$file]['atime'] = fileatime($imgloc);
            $imgs[$file]['x'] = $fileimg['0'];
            $imgs[$file]['y'] = $fileimg['1'];
            switch($fileimg['2']) {
                case '1':
                    $imgs[$file]['type'] = "image/gif";
                    break;
                case '2':
                    $imgs[$file]['type'] = "image/jpg";
                    break;
                case '3':
                    $imgs[$file]['type'] = "image/png";
                    break;
                default:
                    $imgs[$file]['type'] = false;
            }
        } elseif (is_dir($imgloc) && ($file != ".") && ($file != "..")) {
						// we don't want any directories here at the moment
            // do nothing here use the get directories function
            //$imgdirs[] = $file;
        }
	}
	//Clean up and sort
	closedir($handle);
	//sort($retVal);
	if (isset($imgs) && is_array($imgs) && !empty($imgs)) {
	  $imgs = multisort($imgs, "mtime", SORT_DESC, 'filename');
	  foreach ($imgs as $selectedimg) {
      $imgs2[] = $selectedimg;
	  }
	} else {
		$imgs2 = $imgs;
	}

  return $imgs2;
}
function PrintDirContent ($imgs2, $imgtemplate, $image_path) {
    /* debug
    print debug_array($imgs2,"images");
    print "<table><tr><td>".debug_array($imgs,"images")."</td><td>".debug_array(multisort($imgs, "mtime", SORT_DESC, 'filename'),"images sorted (new on top)")."</td></tr></table>";
    print debug_array($imgdirs,"directories");
    /* end debug */
    $files = "";
    $output = "";
    $num = 12;
    $total = count ($imgs2);
    $pages = ceil($total/$num);
    if (isset($_GET['go'])) {
        switch ($_GET['go']) {
            case 'first':
                $start = 0;
                $next = $_GET['go']+1;
                break;
            case 'last':
                $start = ($pages-1)*$num;
                $prev = $_GET['go']-1;
                break;
            default:
                $start = $_GET['go']*$num;
                if ($start != ($pages-1)*$num) {
                    $next = $_GET['go']+1;
                }
                if ($start > 0) {
                    $prev = $_GET['go']-1;
                }
        }
    } else {
        $start = 0;
        $next = 1;
    }
    $browse = "\t<ul class=\"browse\">\n\t\t<li><a class=\"first\" href=\"?go=first\">first</a></li>\n";
    if (isset($prev)) {
        $browse .= "\t\t<li><a class=\"prev\" href=\"?go=$prev&amp;rte=".$_GET['rte']."\">previous</a></li>\n";
    }
    for ($j = 0; $j < $pages; $j++) {
        if ($start != $j*$num) {
            $browse .= "\t\t<li><a href=\"?go=$j&amp;rte=".$_GET['rte']."\">$j</a></li>\n";
        } else {
            $browse .= "\t\t<li><a class=\"current\" href=\"?go=$j&amp;rte=".$_GET['rte']."\">$j</a></li>\n";
        }
    }
    if (isset($next)) {
        $browse .= "\t\t<li><a class=\"last\" href=\"?go=$next&amp;rte=".$_GET['rte']."\">next</a></li>\n";
    }
    $browse .= "\t\t<li><a class=\"last\" href=\"?go=last&amp;rte=".$_GET['rte']."\">last</a></li>\n\t</ul>\n";
    for ($i = $start; $i < ($start+$num); $i++) {
        if (isset($imgs2[$i])) {
            $files .= sprintf($imgtemplate, $image_path."/".$imgs2[$i]['filename'], 160, 140, substr($imgs2[$i]['filename'],0,20), date("Y-m-d",$imgs2[$i]['mtime']), "-");
        }
    }

    // show browser
    if ($browse != "") {
        $output .= "<div id=\"browsetop\" class=\"outlinecontainer\">\n$browse\n</div>\n";
    }

    // show selected images
	if ($files != "") {
        $output .="<div id=\"results\" class=\"outlinecontainer\">\n".$files."\n<br clear=\"all\" />\n</div>\n";
	} else {
        $output .="<div id=\"results\" class=\"outlinecontainer\">\n<div>\nno files found</div>\n\n<br clear=\"all\" />\n</div>\n";
    }

    // show browser
    if ($browse != "") {
        $output .="<div id=\"browsefoot\" class=\"outlinecontainer\">\n$browse\n</div>\n";
    }

    return $output;
}
function GetDirContent ($dir, $scriptname) {
	//Load Directory Into Array 
	$numfiles = 0;
	$numdirs = 0;
	$handle=opendir($dir); 
	while ($file = readdir($handle)) { 
		$retVal[] = $file; 
	} 
	//Clean up and sort 
	closedir($handle); 
	sort($retVal); 
	//return $retVal; 
	while (list($key, $val) = each($retVal)) {
		if (($val != ".") && ($val != "..") && (!in_array($val,$scriptname))) {
			if (is_dir($dir.$val)) {
				$numdirs++;
			} else {
				$numfiles++;
			}
		}
	}
	$output = "<span>";
	if ($numdirs > 0 && $numfiles < 1) {
		$output .= "$numdirs directories";
	} elseif ($numdirs < 1 && $numfiles > 0) {
		$output .= "$numfiles files";
	} elseif ($numdirs > 0 && $numfiles > 0) {
		$output .= "$numdirs directories, $numfiles files";
	} else {
		$output .= "no contents";
	}
	$output .= "</span>\n";
	return $output;
}

$imagesarr = GetDirArray ($image_directory, $image_ext, $image_template);
?>
<div id="popup" onload="window.focus();">
<style type="text/css">
ul.browse, ul.browse li {
list-style: none;
margin: 0;
padding: 0;
}
ul.browse li {
display: inline;
}
div.thumbcontainer {
width: 200px;
float: left;
clear: none;
border: 1px solid #ddd;
}
</style>
<script language="JavaScript" type="text/javascript">
	<!--
	function selectImage(imageurl,imagetitle,imagex,imagey,imagealign) {
		if (!imagealign) {
			window.opener.AddImage('<?php print $_GET['rte']; ?>', imageurl);
		} else if(imagealign=='left') {
			window.opener.AddText('<?php print $_GET['rte']; ?>', "<span style=\"float:"+imagealign+"; clear: none;\"><img src=\""+imageurl+"\" title=\""+imagetitle+"\" align=\""+imagealign+"\"/></span>");
		} else if(imagealign=='right') {
			window.opener.AddText('<?php print $_GET['rte']; ?>', "<img src=\""+imageurl+"\" title=\""+imagetitle+"\" align=\""+imagealign+"\"/>");
		}
		window.close ();
	}
	function popupImage(url,name,width,height,scrollbars) {
		// popup as window 
		// just your average centered popup with some sensible defaults
		if ( scrollbars == null ) {
			scrollbars = "1";
		}
		if ( !name ) {
			name = "imagepop";
		}
		if ( !width ) {
			width = "500";
		}
		if ( !height ) {
			height = "400";
		}
	 
		var str  = ""; 
		str += "resizable=1,"; 
		str += "scrollbars=" + scrollbars + ","; 
		str += "width=" + width + ","; 
		str += "height=" + height + ","; 
	 
		if ( window.screen ) { 
			var ah = screen.availHeight - 30; 
			var aw = screen.availWidth - 10; 
	 
			var xc = ( aw - width ) / 2; 
			var yc = ( ah - height ) / 2; 
	 
			str += ",left=" + xc + ",screenX=" + xc; 
			str += ",top=" + yc + ",screenY=" + yc; 
		}
		var remote = window.open( url, name, str ); 
	
		if (remote.opener == null)
			{	// if something went wrong
				remote.opener = window;
			}
		remote.opener.name = window.name;
		return remote;
	}
	//-->
</script>
<div>
    <div id="uploadbox">
        <form id="upload" class="outlinecontainer" action="" method="post" enctype="multipart/form-data">
<?php
if(isset($file_message)) {
    print "<h2>file upload operation</h2><div>$file_message</div>\n";
}
?>
        	<input type="hidden" name="MAX_FILE_SIZE" value="512000" />
        	<input type="hidden" name="destination" value="" />
            <fieldset> 
                <h2>new upload</h2>
                <div><label for="uploadfile">Choose a file to upload<br /><small>(Only jpg, gif or png images please.)</small></label>
                <input type="file" name="uploadfile" id="uploadfile" accept="image/png,image/jpeg,image/gif" /></div>
                <div><label for="upload-submit">Go for it</label>
                <input type="submit" name="upload-submit" id="upload-submit" value="Start upload" /></div>
            </fieldset>
        </form>
<?php
if (isset($imagesarr['0']) && is_array($imagesarr['0'])) {
	// there is at least one image to display
?>
    	<div id="latest" class="outlinecontainer">
            <h2>latest upload</h2>
            <table>
                <tr>
                    <td>name</td>
                    <td><?php print $imagesarr['0']['filename'] ?></td>
                    <td rowspan="4"><img src="<?php print $image_path."/".$imagesarr['0']['filename'] ?>" width="160" height="140" alt="" /></td>
                </tr>
                <tr>
                    <td>filetype</td>
                    <td><?php print $imagesarr['0']['type'] ?></td>
                </tr>
                <tr>
                    <td>date</td>
                    <td><?php print date("Y-m-d",$imagesarr['0']['mtime']) ?></td>
                </tr>
                <tr>
                    <td colspan="2">
            <a href="#" onClick="selectImage('<?php print $image_path."/".$imagesarr['0']['filename'] ?>','<?php print $imagesarr['0']['filename'] ?>','<?php print $imagesarr['0']['x'] ?>','<?php print $imagesarr['0']['y'] ?>','left');" title="select">&lt;</a>
            <a href="#" onClick="selectImage('<?php print $image_path."/".$imagesarr['0']['filename'] ?>','<?php print $imagesarr['0']['filename'] ?>','<?php print $imagesarr['0']['x'] ?>','<?php print $imagesarr['0']['y'] ?>','');" title="select">select this</a>
            <a href="#" onClick="selectImage('<?php print $image_path."/".$imagesarr['0']['filename'] ?>','<?php print $imagesarr['0']['filename'] ?>','<?php print $imagesarr['0']['x'] ?>','<?php print $imagesarr['0']['y'] ?>','right');" title="select">&gt;</a></td>
                </tr>
            </table>
    	</div>
    </div>
<?php

	if (count($imagesarr)>1) {
		// there must be more than one image available.
		//GetDirArray ($image_directory, $image_ext, $image_template, $image_path);
		print PrintDirContent ($imagesarr, $image_template, $image_path);
	}

// end latest image display
} else {
	print "<div><h2>No images found</h2><p>Please upload an image first</p></div>";
}
?>
</div>
<div>
<a href="#" onClick="window.close()">Close window</a>
</div>
</div>
<!--
<h2>pcDebugArray</h2>
<pre>
<?php print_r($pcDebugArray) ?>
</pre>
<h2>clearance</h2>
<pre>
<?php print_r($clearance) ?>
</pre> -->
<?php
echo pageFooter();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
  <title>select link</title>
  <link rel="stylesheet" type="text/css" href="img/style.css">
  <link rel="stylesheet" type="text/css" href="img/richtext.css">
<style type="text/css">
body {
  font: normal normal normal 12px/normal Verdana, Geneva, Arial, Helvetica, sans-serif;
  color: #000;
}
div.formrow {
  float: left;
  clear: both;
    display: inline;
  width: 100%;
  margin: 0;
  padding: 5px 0;
  border-bottom: 1px dotted #999;
}
label.nt {
  display: block;
  float: left;
  clear: both;
  width: 140px;
}
label.rb {
  float: left;
  clear: none;
}
input.rb {
  float: left;
  clear: both;
  width: 40px;
}
input.nt { /* nt stands for normal text */
  display: block;
  float: left;
  clear: none;
  width: 200px;
}
form {
  float: left;
  clear: both;
    display: inline;
    width: 750px;
  border: 1px dotted #444;
  margin: 5px;
  padding: 0;
}
form.editform {
  padding: 5px;
}
#leftcol {
  display: none;
}
#leftcol, #rightcol {
  float: left;
  clear: none;
  width: 220px;
  border: 1px dotted #444;
  margin: 5px;
  padding: 5px;
}
#leftcol form, #rightcol form {
  border: 1px none;
  margin: 0;
}
h1 {
  font-size: 140%;
  margin: 0 5px;
  padding: 0;
}
h2 {
  font-size: 130%;
  margin: 0 5px;
  padding: 0;
}
h3 {
  font-size: 120%;
  margin: 0 5px;
  padding: 0;
  color: #888;
}
body.contentpreview {
  background: #aaa;
  color: #000;
}
div.previewarea {
  border: 1px solid #000;
  margin: 10px 0 0 0;
  padding: 5px 5px 15px 5px;
  overflow: auto;
  height: 300px;
  background: #fff;
}
span.cpcontrol {
  display: block;
  padding: 5px;
  text-align: right;
}

</style>
<script language="JavaScript" type="text/javascript">
  <!--
  function selectLink(linkurl,linktext,linktitle,linktarget) {
    // fix the checkbox for the target
    if (linktarget['0'].checked==true) {
      linktarget.value = linktarget['0'].value;
    } else {
      linktarget.value = linktarget['1'].value;
    }
    //self.parent.setLink(linkurl,linktext,linktitle,linktarget);
    //alert("<a href=\""+linkurl.value+"\" title=\""+linktitle.value+"\" target=\""+linktarget.value+"\">"+linktext.value+"</a>");
    window.opener.AddText('<?php print $_GET['rte']; ?>', "<a href=\""+linkurl.value+"\" title=\""+linktitle.value+"\" target=\""+linktarget.value+"\">"+linktext.value+"</a>");
    window.close ();
  }
  function linkInsert(lurl,ltext,ltitle,ltarget) {
    document.linkinfo.linkurl.value = lurl;
    document.linkinfo.linktext.value = ltext;
    document.linkinfo.linktitle.value = ltitle;
    //document.linkinfo.linktarget.value = ltarget;
    return true;
  }
  //-->
</script>
</head>

<body onload="window.focus();">
<div>
  <div id="leftcol">
    <h1>select link</h1>
    <div class="formrow">
      <style>
        ul.links a:hover {
          cursor: pointer;
          cursor: hand;
          text-decoration: underline;
        }
      </style>
      <ul class="links">
        <li><a onClick="linkInsert('./index.php','home','go home','_self')">home</a></li>
        <li><a onClick="linkInsert('./news.php','news','go to news','_self')">news</a></li>
        <li>support
          <ul>
            <li><a onClick="linkInsert('./faq.php','faq','go to faq','_self')">faq</a></li>
            <li><a onClick="linkInsert('./contact.php','contact','go to contact page','_self')">contact</a></li>
          </ul></li>
        <li>products
          <ul>
            <li>tables
              <ul>
                <li><a onClick="linkInsert('./products.php?cat=1&amp;id=1','table #1','table #1','_self')">#1</a></li>
                <li><a onClick="linkInsert('./products.php?cat=1&amp;id=1','table #2','table #2','_self')">#2</a></li>
              </ul></li>
            <li><a onClick="linkInsert('./products.php?cat=2','chairs','chairs','_self')">chairs</a></li>
            <li><a onClick="linkInsert('./products.php?cat=3','closets','closets','_self')">closets</a></li>
          </ul></li>
        <li><a onClick="linkInsert('./community.php','community','participate','_self')">community</a></li>
      </ul>
    </div>
    <form id="linksearch" name="linksearch" method="post">
    <div class="formrow">
      <input type="text" name="linksearch" id="linksearch">
      <input type="submit" value="search!">
    </div>
    </form>
  </div>
  <div id="rightcol">
    <form id="linkinfo" name="linkinfo" method="post" onsubmit="selectLink(this.linkurl, this.linktext ,this.linktitle ,this.linktarget);">
    <h1>edit link</h1>
    <div class="formrow">
    <label for="linkurl">Link url</label>
    <input class="lt" type="text" name="linkurl" id="linkurl" value="./">
    </div>

    <div class="formrow">
    <label for="linktext">Link text</label>
    <input class="lt" type="text" name="linktext" id="linktext" value="link text">
    </div>

    <div class="formrow">
    <label for="linktitle">Link title (mouseover)</label>
    <input class="lt" type="text" name="linktitle" id="linktitle" value="link title">
    </div>

    <div class="formrow">
    <label for="linktarget">Open in...</label>
    <input class="rb" type="radio" name="linktarget" id="linktargetself" value="_self" checked="true">
    <label class="rb" for="linktargetself">same window</label>
    <br clear="all">
    <input class="rb" type="radio" name="linktarget" id="linktargetblank" value="_blank">
    <label class="rb" for="linktargetblank">new window</label>
    </div>
    <div class="formrow">
      <input type="submit" value="select this link">
      <input type="reset" value="cancel" onclick="window.close();">
    </div>
    </form>
  </div>
</div>
</body>
</html>

<?php
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require("lib/adminlib.inc.php");

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // User must be logged in
  echo makeLoginForm('debugpage','test.php');
	exit();
} else {	
	//only a framework manager can play with debugging
	if (!$clearance['isFrameworkMgr']) {
    header('Location: index.php?pcAdminMsg=errauthtoolow');
    exit();
	}
}

$smarty = new pcSmarty;
$smarty->assign('arrayDebug',$_SESSION['arraydebugMessageStack']);
$smarty->assign('arrayError',$_SESSION['arrayerrorMessageStack']);
	
//liste of the different package
$arrayPackage = array();
$arrayErrorLevel = array();
	
if (isset($_SESSION['arraydebugMessageStack'])) {
	foreach($_SESSION['arraydebugMessageStack'] as $arrayDebugInfo) {
		$arrayPackage[]= $arrayDebugInfo['package'];
		$arrayErrorLevel[]= $arrayDebugInfo['debugLevel'];
	}
}

//transform them into unique packeage
$arrayPackage = array_unique($arrayPackage);
$arrayPackage = array_merge(array('None'),$arrayPackage);

$arrayErrorLevel = array_unique($arrayErrorLevel);
$arrayErrorLevel = array_merge(array('None'),$arrayErrorLevel);

$smarty->assign('arrayUniquePackage',$arrayPackage);
$smarty->assign('arrayUniqueLevel',$arrayErrorLevel);

//$smarty->debugging=true;
$smarty->display('pcdebug.tpl');
	
?>
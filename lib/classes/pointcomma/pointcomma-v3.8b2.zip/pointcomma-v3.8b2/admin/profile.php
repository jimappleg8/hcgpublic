<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pceditor.php');
include('lib/adminlib.inc.php');

$clearance = unserialize(CLEARANCE);

if ($profileId != 'new') {
  // Existing profile
  // Obtain module
  $rsCurrentSelectedProfile = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'profiles` WHERE profileId='.addslashes($profileId));
  $currentProfile = $rsCurrentSelectedProfile[0];
  $moduleId = $currentProfile['moduleId'];
  if (!$clearance['isModuleSupervisor'][$moduleId]) {
    // Security check
    echo makeLoginForm('authtoolow', 'module.php?moduleId='.$moduleId);
    exit();
  }

  $navArray = array(
    array(
      'label' => 'new profile',
      'href' => 'profile.php?profileId=new&amp;moduleId='.$moduleId
    ),
    array(
      'formName' => 'profile',
      'action' => "profile.php?moduleId=".$moduleId,
      'selectName' => 'profileId'
    )
  );

  $menuArray = array(
    array(
      'label' => 'general',
      'href' => "profile.php?profileId=".$profileId
    ),
    array(
      'label' => 'parameters',
      'href' => "profile.php?profileId=".$profileId."&action=params"
    ),
    array(
      'label' => 'messages',
      'href' => "profile.php?profileId=".$profileId."&action=msgs"
    ),
    array(
      'label' => 'default roles',
      'href' => "profile.php?profileId=".$profileId."&action=roles"
    ),
    array(
      'label' => 'delete',
      'href' => "profile.php?profileId=".$profileId."&action=del"
    )
  );
  $rsAvailableModuleProfiles = pcdb_select('SELECT profileId, label FROM `'.addslashes($pcConfig['dbPrefix']).'profiles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');

  for ($i=0;$i<count($rsAvailableModuleProfiles);$i++) {
    $navArray[1]['menu'][$i]['label'] = $rsAvailableModuleProfiles[$i]['label'];
    $navArray[1]['menu'][$i]['value'] = $rsAvailableModuleProfiles[$i]['profileId'];
    $navArray[1]['menu'][$i]['isSelected'] = ($rsAvailableModuleProfiles[$i]['profileId'] == $profileId);
  }
} else {
  // Create new profile
  $action = 'params';
  $currentProfile = array();
}

$rsModInfo = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
echo pageHeader("Profiles menu", 0, $moduleId, $rsModInfo[0]['label']);

// comment : this part displays the form to change the profile if the user has selected a
//           profile from the jump menu, thus the profileId is NOT 0, zero be nothing selected.
$defaultRoles = array();
if ($profileId != 'new') {
  echo makeMenuBox($currentProfile['label'], $currentProfile['description'], $menuArray, $navArray);
  foreach (explode(';', $currentProfile['defaultRoles']) as $oneRoleId) {
    $defaultRoles[$oneRoleId] = true;
  }
}
 if (!isset($action)){$action=false;} // init missing vars
 if (!isset($displayString)){$displayString="";} // init missing vars
 if (!isset($boxDescr)){$boxDescr="";} // init missing vars
 if (!isset($currentProfile['label'])) {
   $currentProfile['label'] = false;
   $currentProfile['description'] = false;
   $currentProfile['requireAdminConfirm'] = false;
   $currentProfile['adminEmail'] = false;
 }
switch($action){

  case 'params' :
    $displayString = makeInputField('', 'moduleId', 'hidden', $moduleId);
    $displayString .= makeInputField('', 'profileId', 'hidden', $profileId);
    $displayString .= makeInputField('', 'action', 'hidden', 'params');
    $displayString .= makeInputField('Label', 'label', 'string', $currentProfile['label']);
    $displayString .= makeInputField('Description', 'description', 'text', $currentProfile['description']);
    $displayString .= makeInputField('Require admin confirmation', 'requireAdminConfirm', 'bool', $currentProfile['requireAdminConfirm'], 'New accounts are only created after an administrator validates them.');
    $displayString .= makeInputField('Admin email', 'adminEmail', 'string', $currentProfile['adminEmail']);
    $displayString .= makeInputField('Password (optional)', 'password', 'string');
    $displayString .= makeInputField('Remove password', 'removePassword', 'bool', 0, 'The password is not stored as plain text: if you forget it, you must set another one. To remove a password, check this box. If you leave the password field empty, the existing password will remain.');
    $boxDescr = ($profileId == 'new') ? 'Add a new profile' : 'Edit profile';
    echo makeDisplayBox($displayString, $boxDescr, 'profile_update.php');
  break;


  case 'msgs' :
    $displayString = makeInputField('', 'profileId', 'hidden', $profileId);
    $displayString .= makeInputField('', 'action', 'hidden', 'msgs');
    $displayString .= '<p>When a user signs up and email verification is required by the profile, he will get a mail with a confirmation token that will allow him to activate his account. The <b>Signup message</b> is the email sent when a visitor self-registers as a PointComma user. The <b>Admin request message</b> is sent to the Admin email, which should belong to the person in charge of validating users. The <b>Confirm message</b> is sent once the procedure is complete. If email confirmation is not required, the first message is not used. If admin validation is not required, the second is not used. If neither is required, none of the three messages are used.</p><p>The subject lines cannot be customized. The IP address of the requesting computer is logged in the message headers.</p>';
    $displayString .= '<p style="margin-top: 5px; border-top: 1px solid #999;"><b>Signup and email change</b> (sent to the user)<br>Use %t to represent the random token, %u for the user name, %f for the first name, %l (lowercase L) for the last name.</p>';
    $displayString .= makeInputField('Subject', 'signupSubj', 'string', $currentProfile['signupSubj']);
    $displayString .= makeInputField('Message', 'signupMsg', 'text', $currentProfile['signupMsg']);
    $displayString .= '<p style="margin-top: 5px; border-top: 1px solid #999;"><b>Admin moderation</b> (sent to admin email: '.$currentProfile['adminEmail'].')<br>Use %u for the user name.</p>';
    $displayString .= makeInputField('Subject', 'adminSubj', 'string', $currentProfile['adminSubj']);
    $displayString .= makeInputField('Message', 'adminMsg', 'text', $currentProfile['adminMsg']);
    $displayString .= '<p style="margin-top: 5px; border-top: 1px solid #999;"><b>Confirmation</b> (sent to the user)<br>Use %u for the user name, %p for the password, %f for the first name, %l (lowercase L) for the last name.</p>';
    $displayString .= makeInputField('Subject', 'confirmSubj', 'string', $currentProfile['confirmSubj']);
    $displayString .= makeInputField('Message', 'confirmMsg', 'text', $currentProfile['confirmMsg']);
    $displayString .= '<p style="margin-top: 5px; border-top: 1px solid #999;"><b>Forgotten password</b> (sent to the user)<br>Use %t to represent the random token, %u for the user name, %f for the first name, %l (lowercase L) for the last name</p>';
    $displayString .= makeInputField('Subject', 'passwdSubj', 'string', $currentProfile['passwdSubj']);
    $displayString .= makeInputField('Message', 'passwdMsg', 'text', $currentProfile['passwdMsg']);
    echo makeDisplayBox($displayString, $boxDescr, 'profile_update.php');
  break;


  case 'del' :
    $displayString  = makeInputField('Are you sure to delete this profile?', 'sure', 'confirm');
    $displayString .= makeInputField(0, 'profileId', 'hidden', $profileId);
    $displayString .= makeInputField(0, 'action', 'hidden', 'del');
    echo makeDisplayBox($displayString, 'Deleting the profile','profile_update.php');
  break;

  case 'roles' :
    // make sure we know what module and what profile we are working in
    $displayString .= makeInputField(0, 'profileId', 'hidden', $profileId);

    // get all the roles that belong to the current module
    $rsAllModuleRoles = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'') or $rsAllModuleRoles = array();
    foreach ($rsAllModuleRoles as $oneRole) {
      if (isset($defaultRoles[$oneRole['roleId']]) && $defaultRoles[$oneRole['roleId']]) {
        $displayString .= makeInputField($oneRole['label'], 'setDefaultRoles['.$oneRole['roleId'].']', 'bool', $defaultRoles[$oneRole['roleId']]);
      }
    }
    $displayString .= makeInputField(0, 'profileId', 'hidden', $profileId);
    $displayString .= makeInputField(0, 'action', 'hidden', 'roles');
    echo makeDisplayBox($displayString, 'Default roles', 'profile_update.php');
  break;

  default :
    // This is to display the general part

    $rsAllModuleRoles = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'') or $rsAllModuleRoles = array();
    $rolesArray = array();
    foreach ($rsAllModuleRoles as $oneRole) {
      if (isset($defaultRoles[$oneRole['roleId']]) && $defaultRoles[$oneRole['roleId']]) {
        $rolesArray[] = $oneRole['label'];
      }
    }
    if (count($rolesArray)) {
      $displayString = 'Default roles: <b>'.implode('</b>, <b>', $rolesArray).'</b>.<br>';
    } else {
      $displayString = '<b>No</b> default roles defined.<br>';
    }
    $displayString .= 'Require admin confirmation: <b>'.(($currentProfile['requireAdminConfirm'])?'yes':'no').'</b><br>';
    $displayString .= 'Password protected: <b>'.(($currentProfile['password']!='')?'yes':'no').'</b>';
    $displayString .= '<br><br>profileId: <b>'.$currentProfile['profileId'].'</b>';
    echo makeDisplayBox($displayString, 'General Information');
}

  echo pageFooter();
?>
<?php

$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pceditor.php');
include("lib/adminlib.inc.php");
$pcAdminMsg = pcDefaultValue('string', '', 'pcAdminMsg', 'G');
$action = pcDefaultValue('string', '', 'action', 'G');
$moduleId = pcDefaultValue('pcStrId', '', 'moduleId', 'G');
$userName = pcDefaultValue('string', false, 'userName', 'G');

// comment : makes sure that the user has the right to change roles in
//           the system.
//           extend this according to the modulemanager rights ?
//           is the supevisor the only guy who can do this...

$clearance = unserialize(CLEARANCE);
$canSeeUsers = ($clearance['isSupervisor']);
foreach ($clearance['isModuleSupervisor'] as $oneModuleSup) {
	if ($oneModuleSup) {
		$canSeeUsers = true;
	}
}
if ($canSeeUsers) {
	$navArray = array(
		array(
						'label' => 'new user',
						'href' => "user.php?action=new&amp;moduleId=$moduleId"
		),
		array(
			'formName' => 'user',
			'action' => "user.php",
			'hiddenName1' => "moduleId",
			'hiddenVal1' => $moduleId,
			'selectName' => 'userName',
			'menu' => array(
				array(
					'label' => 'Select a user',
					'value' => '0'
				),
				array(
					'label' => '',
					'value' => '0'
				)
			)
		)
	);

	// comment : this part makes the selects in the drop down jump menu with all the other roles beloning
	//           to the module belonging to the current selected role

	$rsAvailableUsers = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'webusers`');
	for ($i=0;$i<count($rsAvailableUsers);$i++) {
		$navArray[1]['menu'][$i+2]['label'] = $rsAvailableUsers[$i]['userName'];
		$navArray[1]['menu'][$i+2]['value'] = $rsAvailableUsers[$i]['userName'];
		$navArray[1]['menu'][$i+2]['isSelected'] = ($rsAvailableUsers[$i]['userName'] == $userName);
	}
} else {
	$navArray = array();
	$userName = $clearance['userName'];
}

// did that already near line 20
//  $userName = pcDefaultValue('','','userName');
if ($userName) {
	$rsCurrentSelectedUser = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'webusers` WHERE userName=\''.addslashes($userName).'\'');
	$selectedUser = $rsCurrentSelectedUser[0];

	$menuArray = array(
		array(
			'label' => 'general',
			'href' => "user.php?userName=".$userName."&amp;action=gen&amp;moduleId=$moduleId"
		),
		array(
			'label' => 'assignments',
			'href' => "user.php?userName=".$userName."&amp;action=assign&amp;moduleId=$moduleId"
		),
		array(
			'label' => 'edit',
			'href' => "user.php?userName=".$userName."&amp;action=edit&amp;moduleId=$moduleId"
		),
		array(
			'label' => 'password',
			'href' => "user.php?userName=".$userName."&amp;action=passwd&amp;moduleId=$moduleId"
		)
	);
	if ($selectedUser['status']>3) {
		$menuArray[] = array(
			'label' => 'reactivate',
			'href' => "user.php?userName=".$userName."&amp;action=reactivate&amp;moduleId=$moduleId"
		);
	} else {
		$menuArray[] = array(
			'label' => 'freeze',
			'href' => "user.php?userName=".$userName."&amp;action=freeze&amp;moduleId=$moduleId"
		);
	}

	$canEditUser = $clearance['isSupervisor'] || ($userName == $clearance['userName']);
	// Only supervisors may do things to other supervisors
	// For non-supervisors, check if the target user is framework manager or supervisor...
	if ($canSeeUsers && (!$selectedUser['isFrameworkMgr'] && !$selectedUser['isSupervisor'])) {
		$canEditUser = true;
	}
	if (!$canEditUser) {
		unset($menuArray);
	} elseif (isset($clearance['isModuleSupervisor'][$moduleId]) && !$clearance['isModuleSupervisor'][$moduleId] && $moduleId != '') {
		unset($menuArray[1]);
	}
	if (!$canSeeUsers) {
		unset($menuArray[1]);
		unset($menuArray[4]);
	}
} else {
	// No userName is provided, no tabs shown
	$menuArray = array();
}



$rsModuleInfo = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
echo pageHeader("User menu", 0, $moduleId, $rsModuleInfo[0]['label']);
pcErrorDisplay(WARNING);
// comment : this part displays the form to change the role if the user has selected a
//           role from the jump menu, thus the roleId is NOT 0, zero be nothing selected.
if (!empty($userName)) {
	echo makeMenuBox($selectedUser['userName'], $selectedUser['firstName']." ".$selectedUser['lastName'] , $menuArray, $navArray);
} elseif ($action == 'new') {
	echo makeMenuBox('New user', 'Please enter some information about the new user. A valid email address is required.', $menuArray, $navArray);
} else {
	echo makeMenuBox('Users', 'Select a user name in the right-hand menu, or create a new user.', $menuArray, $navArray);
}
$displayString = '';
switch($action){

	case 'new' :

		$displayString .= makeInputField('', 'action', 'hidden', 'new');
		$displayString .= makeInputField('Username', 'userName', 'string');
		$displayString .= makeInputField('Password', 'password', 'password');
		$displayString .= makeInputField('Confirm Password', 'cpassword', 'password');
		$displayString .= makeInputField('Firstname', 'firstName', 'string');
		$displayString .= makeInputField('Lastname', 'lastName', 'string');
		$displayString .= makeInputField('E-mail', 'submitEMail', 'string');
		if ($clearance['isSupervisor']) {
			$displayString .= makeInputField('', 'isFrameworkMgr', 'bool', '', 'Framework Manager');
			$displayString .= makeInputField('', 'isSupervisor', 'bool', '', 'Supervisor');
		}
		echo makeDisplayBox($displayString, 'Add a new user:', 'user_update.php');
		break;

	case 'edit' :

		$displayString .= makeInputField('', 'userName', 'hidden', $selectedUser['userName']);
		$displayString .= makeInputField('', 'action', 'hidden', 'edit');
		$displayString .= makeInputField('Firstname', 'firstName', 'string', $selectedUser['firstName']);
		$displayString .= makeInputField('Lastname', 'lastName', 'string', $selectedUser['lastName']);
		$displayString .= makeInputField('E-mail', 'changeEMail', 'string', $selectedUser['eMail']);
		if (isset($selectedUser['newEMail'])) {
			$displayString .= '<p>Pending email change: <b>'.$selectedUser['newEMail'].'</b>.</p>';
		}
		if ($clearance['isSupervisor']) {
			$displayString .= makeInputField('', 'isSupervisor', 'bool', $selectedUser['isSupervisor'], 'Supervisor');
			$displayString .= makeInputField('', 'isFrameworkMgr', 'bool', $selectedUser['isFrameworkMgr'], 'Framework Manager');
		}

		echo makeDisplayBox($displayString,'Edit the user: '.$selectedUser['userName'], 'user_update.php');
		break;

	case 'passwd':
		if ($canEditUser) {
			if ($clearance['userName'] == $userName) {
				$displayString .= makeInputField('Current password', 'current_password', 'password');
			}
			$displayString .= makeInputField('New password', 'new_password', 'password');
			$displayString .= makeInputField('Confirm new password', 'confirm_password', 'password');
			$displayString .= makeInputField('', 'action', 'hidden', 'passwd');
			$displayString .= makeInputField('', 'moduleId', 'hidden', $moduleId);
			$displayString .= makeInputField('', 'userName', 'hidden', $selectedUser['userName']);
			echo makeDisplayBox($displayString,'Change the password', 'user_update.php');
		}
	break;

	case 'freeze' :
		if ($canEditUser) {
			$displayString  = makeInputField('Do you want to make this user inactive? He will no longer be able to log in, but all of his other characteristics will be retained.', 'sure', 'confirm');
			$displayString .= makeInputField(0, "userName", "hidden", $selectedUser['userName']);
			$displayString .= makeInputField('', 'action', 'hidden', 'freeze');
			$displayString .= makeInputField('', 'moduleId', 'hidden', $moduleId);
			echo makeDisplayBox($displayString, 'Freeze the user','user_update.php');
		}
		break;

	case 'reactivate' :
		if ($canEditUser) {
			$displayString  = makeInputField('Do you want to reactivate this user? He will regain the capability to log in and be granted all his rights.', 'sure', 'confirm');
			$displayString .= makeInputField(0, "userName", "hidden", $selectedUser['userName']);
			$displayString .= makeInputField('', 'action', 'hidden', 'reactivate');
			$displayString .= makeInputField('', 'moduleId', 'hidden', $moduleId);
			echo makeDisplayBox($displayString,'Reactivate the user', 'user_update.php');
		}
		break;

	case 'assign' :

		if ($moduleId != '') {
			if (!$rsAllModuleRoles = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'')){
				$rsAllModuleRoles = array();
			}

			if (!$rsCurrentassign = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'assignments` WHERE userName=\''.addslashes($userName).'\'')) {
				$rsCurrentassign = array();
			}

			foreach ($rsCurrentassign as $assign){
				$sortedassignes[$assign['roleId']] = true;
			}

			foreach ($rsAllModuleRoles as $role){
		if(!isset($sortedassignes[$role['roleId']])) {$sortedassignes[$role['roleId']]=false;}
				$displayString .= makeInputField($role['label'],'addRoles['.$role['roleId'].']','bool',$sortedassignes[$role['roleId']], $role['description']."<br>Module Manager : ".$role['isModuleMgr']."<br>Module Supervisor : ".$role['isModuleSupervisor']);
			}

			$displayString .= makeInputField(0, "userName", "hidden", $userName);
			$displayString .= makeInputField(0, "moduleId", "hidden", $moduleId);
			$displayString .= makeInputField(0, "action", "hidden", 'assign');

			if (count($rsAllModuleRoles)) {
				$submitTo = 'user_update.php';
			} else {
				$displayString = 'No roles available';
			}

			echo makeDisplayBox($displayString, 'Assigned to roles', $submitTo);
		}
		else {
			if ($rsAllModules = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules`')) {
				foreach ($rsAllModules as $oneModule) {
					if ($clearance['isModuleSupervisor'][$oneModule['moduleId']]) {
						$displayString .= '<p><a href="user.php?userName='.addslashes($userName).'&amp;action=assign&amp;moduleId='.addslashes($oneModule['moduleId']).'"><b>'.addslashes($oneModule['label']).'</b></a>: '.stripslashes($oneModule['description'])."<br>&nbsp;</p>\n";
					}
				}
			}
			else {
				$displayString = "<p>There are no modules to choose from.</p>";
			}
			echo makeDisplayBox($displayString, 'Select a module');
		}
		break;

	default :

		// This is to display the general part
		if(isset($rsCurrentSelectedUser) && $rsCurrentSelectedUser){
		if (!isset($displayString)) {$displayString="";} // init missing var
			$displayString .= "First name: ".$selectedUser['firstName']."<br>\n";
			$displayString .= "Last name: ".$selectedUser['lastName']."<br>\n";
			$displayString .= "Email: ".$selectedUser['eMail']."<br>\n";
			$displayString .= "Active since: ".$selectedUser['activeSince']."<br>\n";
			$displayString .= "Created by: ".$selectedUser['createdBy']."<br>\n";
			$status = $newStatus = substr('000'.decbin($selectedUser['status']), -3, 3);
			$statusFrozen = substr($status, 0, 1);
			$statusAdminOK = substr($status, 1, 1);
			$statusEmailOK = substr($status, 2, 1);
			if ($statusFrozen) {
				$displayString .= "User is <b>frozen</b> and may not log in<br>\n";
			} else {
				$displayString .= "User is active<br>\n";
			}
			if ($statusAdminOK) {
				$displayString .= "User has been <b>OKayed</b> by an admin, or no OK was required<br>\n";
			} else {
				$displayString .= 'User has not yet been validated by an admin. <a href="sradmin.php?u='.$selectedUser['userName'].'">Activate this user</a><br>';
			}
			if ($statusEmailOK) {
				$displayString .= "User's email has been <b>verified</b><br>\n";
			} else {
				$displayString .= "User's email has yet to be verified<br>\n";
			}
			if (isset($selectedUser['newEMail'])) {
				$displayString .= 'Pending email change: <b>'.$selectedUser['newEMail'].'</b>.<br>';
			}

			//$displayString .= "current user = ".$clearance['userName']."<br>\n";

			if($selectedUser['isSupervisor']){
				$displayString .= "user is a Supervisor <br>\n";
			}
			if ($selectedUser['isFrameworkMgr']){
				$displayString .= "user is a Framework Manager <br>\n";
			}
			echo makeDisplayBox($displayString, 'General Information User');
		}
}

echo pageFooter();
?>
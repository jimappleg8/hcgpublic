<?php

// PointComma admin site template
require('../config.inc.php');require($pcConfig['includePath'].'pcEngine.php');
// PointComma library. Initializes the clearance array, and stores
// its serialized representation in the CLEARANCE constant, and
// makes PointComma i/o functions available, as well as the
// database abstraction layer.

include("lib/htmllib.inc.php");
// The admin interface HTML generation libraries

$clearance = unserialize(CLEARANCE);
if (!$clearance['isFrameworkMgr'] && 0) {
  // ... or whatever check is needed in this file
//  echo makeLoginForm(string [errMessage], string [targetPage='index.php'], array [postData]);
  // See documentation in htmllib.inc.php
  exit();
}

echo pageHeader();pcErrorDisplay(WARNING);
// echo pageHeader([title], [message], [moduleId, moduleName], [typeId, typeName]);
// See documentation in htmllib.inc.php


//
// The page's main code here
//

//
// Examples of use of HTMLlib functions
//

$navArray = array(
  array(
    'label' => 'test one',
    'href' => 'test.php'
  ),
  array(
    'label' => 'test two',
    'href' => 'test.php?t=2'
  ),
  array(
    'action' => 'template.php',
    'selectName' => 'stuffId',
    'hiddenName1' => 'oneId',
    'hiddenVal1' => '14',
    'hiddenName2' => 'someId',
    'hiddenVal2' => '24',
    'menu' => array(
      array(
        'label' => 'Select something',
        'value' => '0'
      ),
      array(
        'label' => '',
        'value' => '0'
      ),
      array(
        'label' => 'Whatever',
        'value' => 'here'
      )
    )
  ),
  array(
    'action' => 'template.php',
    'selectName' => 'itemId',
    'hiddenName1' => 'itemType',
    'hiddenVal1' => '14',
    'menu' => array(
      array(
        'label' => 'Select something',
        'value' => '0'
      ),
      array(
        'label' => '',
        'value' => '0'
      ),
      array(
        'label' => 'One item',
        'value' => '7',
        'isSelected' => true
      ),
      array(
        'label' => 'Another item',
        'value' => '4'
      )
    )
  )
);


echo makeNavBox('module menu', 'The game', 'game.php', 'Hello there, greetings. This may be fairly long and have a lot of very different and varied words into it, as well as some form elements. Actually, no form elements...', '12 types, 865 items, 7 policies', $navArray);

echo makeDisplayBox("<p>Hello there</p>", 'title of the box', 'template.php');

//
// End of the page's main code
//

echo pageFooter();
// echo pageFooter([mainNav], [moduleId, moduleName], [typeId, typeName]);
// See documentation in htmllib.inc.php

?>

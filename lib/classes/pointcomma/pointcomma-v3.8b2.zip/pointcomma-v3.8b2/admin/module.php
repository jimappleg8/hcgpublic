<?php
// PointComma admin site module.php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pceditor.php');
require("lib/adminlib.inc.php");
$clearance = unserialize(CLEARANCE);
$action = pcDefaultValue('string', '', 'action', 'G');
$moduleId = pcDefaultValue('pcStrId', '', 'moduleId', 'GP');
$pcAdminMsg = pcDefaultValue('string', '', 'pcAdminMsg', 'G');


if (!$clearance['userName']) {
  // User must be logged in
  echo makeLoginForm('notloggedin', "module.php?moduleId=$moduleId");
  exit();
}

if (!isset($profileId)) {$profileId=false;} // init missing chars
if (!isset($modename)) {$modename=false;} // init missing chars
if (!isset($modescr)) {$modescr=false;} // init missing chars


if ($action=='new') {
  //if add new module
  if (!$clearance['isFrameworkMgr']) {
    header('Location: index.php?pcAdminMsg=errauthtoolow');
    exit();
  }


	// If creation failed, re-display entries
	$modename = pcDefaultValue('string', '', 'modename', 'G');
	$modescr = pcDefaultValue('string', '', 'modescr', 'G');
	$moduleIdent = pcDefaultValue('string', '', 'moduleIdent', 'G');

  echo pageHeader('Create a new module');
	pcErrorDisplay(WARNING);
  $boxContent=makeInputField('Module name', 'moduleName', 'string',$modename);
	$boxContent.=makeInputField('Module identifier', 'moduleIdent', 'string',$moduleIdent, '', 8);
	// Added limit to 8 characters
  $boxContent.=makeInputField('Description', 'moduleDescription', 'text', $modescr);
  $boxContent.=makeInputField(0, 'action', 'hidden','new');
  $boxTitle='Add New Module';
  $submitToPage='module_update.php';
  echo makeDisplayBox($boxContent,$boxTitle,$submitToPage);
  echo pageFooter();
  exit();
}

$moduleQuery=pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');

//select correspondent module data for modules using moduleId
if (!$moduleQuery) {
//if $moduleQuery=false or count($moduelQuery)<>1 then show error
  header('Location: index.php?pcAdminMsg=errwrongmodule');
  exit();
}
$oneModule=$moduleQuery[0];
$navArray = array(
  array(
    'label' => 'new module',
    'href' => 'module.php?action=new'
  ),
  array(
    'formName' => 'Module',
    'action' => "module.php?moduleId=".$moduleId,
    'selectName' => 'moduleId',
    'menu' => array()
  )
);
foreach($clearance['rights'] as $oneType=>$right) {
  // Obtain a list of all modules that contain types that the current user can instanciate
  if ($right) {
    if ($typeQuery = pcdb_select('SELECT moduleId FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId=\''.addslashes($oneType).'\'')) {
      foreach ($typeQuery as $oneTypesModule) {
        $allModulesRights[$oneTypesModule['moduleId']] = true;
      }
    }
  }
}

$moduleQuery = pcdb_select('SELECT label, moduleId FROM `'.addslashes($pcConfig['dbPrefix']).'modules`');
for ($i=0;$i<count($moduleQuery);$i++) {
  // FIXME: the next line drops an error when you create a module
  // index 1 doesn ot exist // allModulesRights does not exist
  // I guess on creation of a module the clearance update fails
  // logout and login again solves the problem
  if ((isset($clearance['isModuleMgr'][$moduleQuery[$i]['moduleId']]) and $clearance['isModuleMgr'][$moduleQuery[$i]['moduleId']]) or $clearance['isModuleSupervisor'][$moduleQuery[$i]['moduleId']] or $allModulesRights[$moduleQuery[$i]['moduleId']]) {
    $navArray[1]['menu'][$i]['label'] = $moduleQuery[$i]['label'];
    $navArray[1]['menu'][$i]['value'] = $moduleQuery[$i]['moduleId'];
    $navArray[1]['menu'][$i]['isSelected'] = ($moduleQuery[$i]['moduleId'] == $moduleId);
  }
}
if ($clearance['isFrameworkMgr']) {
  $menuArray = array(
    array(
      'label' => 'General',
      'href' => "module.php?moduleId=".$moduleId
    ),
    array(
      'label' => 'Edit Module',
      'href' => "module.php?action=edit&moduleId=".$moduleId
    ),
    array(
      'label' => 'Delete Module',
      'href' => "module.php?action=del&moduleId=".$moduleId
    )
  );
} else {
  unset($navArray[0]);
}

echo pageHeader('Module Menu', 0, $oneModule['moduleId'], $oneModule['label']);
pcErrorDisplay(WARNING);
echo makeMenuBox($oneModule['label'],$oneModule['description'], $menuArray, $navArray);
switch($action){
  case 'edit' :
    $moduleQuery=pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
    //select correspondent module data for modules using moduleId
    if ((!$moduleQuery) or (count($moduleQuery)<>1)) {
    //if $moduleQuery=false or count($moduelQuery)<>1 then show error
      assert("\$pcConfig['debug']['errorLevel'] > pcDebugInfo(get_defined_vars(),'pcModuleManagement',\"No module\" ,4)");
      exit();
    }
    $oneModule=$moduleQuery[0];
    $boxContent=makeInputField('Module name', 'moduleName', 'string',$oneModule['label']);
    $boxContent.=makeInputField('Description', 'moduleDescription', 'text', $oneModule['description']);
    $boxContent.=makeInputField(0, 'action', 'hidden','edit');
    $boxContent.=makeInputField(0, 'moduleId', 'hidden',$moduleId);
    $boxTitle='Edit Module';
    $submitToPage='module_update.php';
    echo makeDisplayBox($boxContent,$boxTitle,$submitToPage);
    //display module edit box, makeDisplayBox function can be seen in htmllib.inc.php
  break;

  case 'del' :
    $moduleDeleteQuery=pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
    $displayString  = makeInputField('Are you sure to delete this module, it will also delete its types, roles,items,xvals,units,assignments and authorisations', 'sure', 'confirm');
    $displayString .= makeInputField(0, "moduleId", "hidden", $moduleDeleteQuery[0]['moduleId']);
    $displayString .= makeInputField(0, 'action', 'hidden', 'del');
    echo makeDisplayBox($displayString, 'Deleting the module','module_update.php');
  break;

  default:
    if ($clearance['isModuleSupervisor'][$moduleId]) {
      $navArray = array(
        array(
          'label' => 'users',
          'href' => "user.php?moduleId=$moduleId"
        ),
        array(
          'label' => 'new role',
          'href' => "role.php?roleId=new&action=new&moduleId=$moduleId"
        ),
        array(
          'formName' => 'module',
          'action' => "role.php?moduleId=".$moduleId,
          'selectName' => 'roleId',
          'menu' => array(
            array(
              'label' => 'select a role',
              'value' => '0'
            ),
            array(
              'label' => '',
              'value' => '0'
            )
          )
        )
      );
      // Populate roles jump menu
      if ($rsRoles = pcdb_select('SELECT roleId, label FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'')) {
        if(!isset($roleId)){$roleId=false;}
        for ($i=0;$i<count($rsRoles);$i++) {
          $navArray[2]['menu'][$i+2]['label'] = $rsRoles[$i]['label'];
          $navArray[2]['menu'][$i+2]['value'] = $rsRoles[$i]['roleId'];
          $navArray[2]['menu'][$i+2]['isSelected'] = ($rsRoles[$i]['roleId'] == $roleId);
        }
      } else {
        unset($navArray[2]['menu']);
        $navArray[2]['label'] = 'no existing roles';
      }
    }
    if ($clearance['isModuleMgr'][$moduleId]) {
      $navArray[] = array(
        'label' => 'new type',
        'href' => "type.php?typeId=new&action=new&moduleId=$moduleId"
      );
    }
    if ($clearance['isModuleSupervisor'][$moduleId]) {
      $navArray[] = array(
        'label' => 'new profile',
        'href' => "profile.php?profileId=new&moduleId=$moduleId"
      );
      $navArray[5] = array(
        'formName' => 'profile',
        'action' => "profile.php?moduleId=".$moduleId,
        'selectName' => 'profileId',
        'menu' => array(
          array(
            'label' => 'select a profile',
            'value' => '0'
          ),
          array(
            'label' => '',
            'value' => '0'
          )
        )
      );
      // Populate profiles jump menu
      if ($rsProfiles = pcdb_select('SELECT profileId, label FROM `'.addslashes($pcConfig['dbPrefix']).'profiles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'')) {
        for ($i=0;$i<count($rsProfiles);$i++) {
          $navArray[5]['menu'][$i+2]['label'] = $rsProfiles[$i]['label'];
          $navArray[5]['menu'][$i+2]['value'] = $rsProfiles[$i]['profileId'];
          $navArray[5]['menu'][$i+2]['isSelected'] = ($rsProfiles[$i]['profileId'] == $profileId);
        }
      } else {
        unset($navArray[5]['menu']);
        $navArray[5]['label'] = 'no existing profiles';
      }
    }
    if ($clearance['isModuleSupervisor'][$moduleId] || $clearance['isModuleMgr'][$moduleId]) {
      echo makeDisplayBox(displayNavArray($navArray), 'General');
    }

    $allTypes=pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
    //select all types from the modules table
    if (!$allTypes) {
      //if $alltypes=false then do nothing
      $allTypes=array();
    }
    foreach($allTypes as $oneType) {
      $typeId = $oneType['typeId'];
      $navArray = array(
        array(
          'label' => 'new item',
          'href' => 'item.php?itemId=new&amp;typeId='.$typeId
        ),
        array(
          'action'=> 'item.php',
          'selectName'=> 'itemId',
          'menu' => array(
            array(
              'label' => 'recently submitted items',
              'value' => 0
            ),
            array(
              'label' => '',
              'value' => 0
            )
          )
        ),
        array(
          'label' => 'published items',
          'href' => 'type.php?action=items&amp;typeId='.$typeId.'&pubState=5'
        ),
      );
      if ($clearance['rights'][$typeId]<3) {
        $countModif = " && createdBy='".addslashes($clearance['userName'])."' && lastUpdateBy='".addslashes($clearance['userName'])."'";
      } else {
        $countModif = '';
      }
      $last10Items = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId LIKE \''.addslashes($typeId).'\' && pubState=1'.$countModif.' ORDER BY lastUpdateOn DESC LIMIT 0,10');
      // select last 10 draft items per type
      if ($last10Items) {
        for ($i=0;$i<count($last10Items);$i++) {
          $navArray[1]['menu'][$i+2]['label'] = $last10Items[$i]['handle'];
          $navArray[1]['menu'][$i+2]['value'] = $last10Items[$i]['itemId'];
        }
      }
      else {
        $navArray[1]['menu'] = false;
        $navArray[1]['label'] = 'no submitted items';
      }
      if ($clearance['rights'][$typeId]<2) {
        unset($navArray[2]);
      }
      else if (!pcdb_select('SELECT itemId FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.addslashes($typeId).'\' && pubState=5'.$countModif)) {
        // see if there are any published items per type
        $navArray[2]['href'] = false;
        $navArray[2]['label'] = 'no published items';
      }
      $queryChars = pcdb_select('SELECT COUNT(charId) AS numChars FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE typeId=\''.addslashes($typeId).'\'');
      //show the number of characterics per type
      $numChars = $queryChars[0]['numChars'];
      $queryItems = pcdb_select('SELECT COUNT(itemId) AS numItems FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.addslashes($typeId).'\''.$countModif);
      //show the number of items per type
      $numItems = $queryItems[0]['numItems'];
			if ($oneType['inherit_from']) {
				echo makeNavbox('type menu',$oneType['label'],"type.php?typeId=".$oneType['typeId'],"Type Id: ".$oneType['typeId'].' inherited from type '.$oneType['inherit_from'],"$numChars chars, $numItems items",$navArray);
			} else {
				echo makeNavbox('type menu',$oneType['label'],"type.php?typeId=".$oneType['typeId'],"Type Id: ".$oneType['typeId'],"$numChars chars, $numItems items",$navArray);
			}
    }
    // End foreach type
  break;
  // End of case general
}
// End of action switch

echo pageFooter();

?>
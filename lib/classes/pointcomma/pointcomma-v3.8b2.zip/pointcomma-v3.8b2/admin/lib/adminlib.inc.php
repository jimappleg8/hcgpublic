<?php

  include("lib/htmllib.inc.php");


/*
    boolean deleteRole(int $roleId)
      returns a 0 or 1 if it worked
*/


// comment still have to handle the errors. But this works, sort of ;)
function deleteRole($roleId){
  global $pcConfig;
  if (pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE roleId='.addslashes($roleId))){
   //echo "roles are deleted";
   return 1;
  }
  else {
   //echo "roles are NOT deleted";
   return 0;
  }
  if (pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'assignments` WHERE roleId='.addslashes($roleId))){
   //echo "assignments are deleted";
   return 1;
  }
  else {
   //echo "assignments are NOT deleted";
   return 0;
  }
  if (pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'authorizations` WHERE roleId='.addslashes($roleId))){
   //echo "authz are deleted";
   return 1;
  }
  else {
   //echo "authz are NOT deleted";
   return 0;
  }
}

function deleteType($typeId) {
  global $pcConfig;
  $typeId = pcSanitizeStr($typeId,'/[^a-z0-9_]/', 18);
  $clearance = unserialize(CLEARANCE);
  $typeQuery = pcdb_select('SELECT moduleId FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId=\''.$typeId.'\'');
  if (!$clearance['isModuleMgr'][$typeQuery[0]['moduleId']]) {
    trigger_error('You are not authorized to delete this type',ERROR);
    return false;
  }
  $allDeleted = true;
  if ($allItems = pcdb_select('SELECT itemId FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.$typeId.'\'')) {
    foreach ($allItems as $oneItem) {
      $allDeleted = writeItem($oneItem['itemId'], 0) && $allDeleted;
      // Deletes each item
    }
  }
  $allDeleted = pcdb_query('DROP TABLE `'.addslashes($pcConfig['dbPrefix']).$typeId.'`') && $allDeleted;
  $allDeleted = pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE typeId=\''.$typeId.'\'') && $allDeleted;
  $allDeleted = pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'authorizations` WHERE typeId=\''.$typeId.'\'') && $allDeleted;
  $allDeleted = pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId=\''.$typeId.'\'') && $allDeleted;
  return $allDeleted;
}

function deleteXvalsFromChar($charId) {
  global $pcConfig;
	$charId= (int)$charId;
  $returnBool = true;
  $rsCheckCharType = pcdb_select('SELECT typeId, format,columnId FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE charId='.$charId);
  $checkCharType = $rsCheckCharType[0];
	$typeId = $checkCharType['typeId'];
	$charColumnId = $checkCharType['columnId'];
  if ($checkCharType['format'] == 'f') {

    // delete the file corresponding to the item
		$filesToDelete = pcdb_select('SELECT `'.$charColumnId.'` AS file FROM `'.$pcConfig['dbPrefix'].addslashes($typeId).'` WHERE `'.addslashes($charColumnId).'` != \'\' ');
 
    if ($filesToDelete) {
      foreach ($filesToDelete as $delFile) {
        if (!unlink($pcConfig['upload']['dir'].$delFile['file'])) {
          trigger_error('File cannot be deleted',ERROR);
          $returnBool = false;
        }
      }
    } else {
      //no file to delete
    }
  }
  $returnBool = pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).addslashes($checkCharType['typeId']).'` SET `'.addslashes($charColumnId).'`=NULL') && $returnBool;
  return $returnBool;
}

?>
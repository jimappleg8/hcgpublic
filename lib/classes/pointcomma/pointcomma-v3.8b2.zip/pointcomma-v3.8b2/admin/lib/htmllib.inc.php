<?php

/*

    HTML lib

    generates HTML and navigation according to the current user's authorizations

    string pageHeader([title], [message], [moduleId, moduleName], [typeId, typeName])
      without argument, returns the top of the HTML file, without a title and with only the
      main links in the top nav menu. It accepts the following arguments:
        . title, which is added in the <title> tag and at the top of the document's main zone
        . message, error or status message
        . moduleId and moduleName trigger the display of the appropriate second level nav bar
        . typeId and typeName trigger the display of the appropriate second (if no module) or
          third level nav bar

    string pageFooter([mainNav], [moduleId, moduleName], [typeId, typeName])
      without any arguments, returns the bottom of the HTML file with a minimal nav bar.
      It accepts the following arguments:
        . mainNav, if true, triggers the repetition of the main navigation bar at the bottom
          of the page
        . moduleId, moduleName trigger the display of a second level nav bar above the main
          nav bar at the bottom of the page
        . typeId, typeName trigger the display of a second (if no module) or third level nav
          bar, above the main nav bar (and the module nav bar) at the bottom of the page

    string makeNavLine([type, level, name, id])
      this function is called by the two above and should not be called directly. Without any
      arguments, returns the main nav bar. It accepts the following:
        . type, which can be set to 'main' (default), 'module' or 'type'.
        . level configures the CSS selectors
        . name describes the type or the module
        . id is used in links

  NOTE: NavArrays are an array of arrays. Each element will be handled by the function that is
    using it either as a simple HTML link or as a javascript-powered pull-down action menu.
      - To make a simple link, the element must be an array featuring the following keys:
          . ['label'] (string)
          . ['href'] (string)
      - To make a pull-down action menu, the element must be an array featuring the following
        keys:
          . ['action'] (string), the page the form will be submitted to
          . ['selectName'] (string), name of the pull-down form element
          . ['hiddenName1'] (string), name of first optional hidden field
          . ['hiddenVal1'] (string), value of first optional hidden field
          . ['hiddenName2'] (string), name of second optional hidden field
          . ['hiddenVal2'] (string), value of second optional hidden field
          . ['menu'] (array)
            Menu is an array of arrays. It will be displayed as a pull-down menu, and each of
            its elements will be displayed as one option in the menu. Those option arrays
            feature the following keys:
            > ['label'] (string)
            > ['value'] (string)
            > ['isSelected'] (bool)
    Final note about NavArrays: they're handled by a displayNavArray function which should never
    be called directly but only from other display functions.

    string makeNavBox(string menu, string title, string href, string [descr], string [xData],
          NavArray [links], bool [isFlat])
      returns a navigation box, which gives access to first and second-level functionality
      about one element. Accepts the following arguments:
        . menu, the link giving access to the full menu (one-level jump). Should be type menu',
          'module menu', etc.
        . title, name of the element (features the same link as the menu)
        . href, the URL of menu and title links
        . descr, displayed under the title, as simple text
        . xData, displayed under the descr, extra information about the element
        . links, displayed in the right column, giving access to second-level functionality
          for the element
        . isFlat, if set to true, ensures that the action menu is displayed as horizontal
          buttons instead of displaying it as a vertical list

    string makeSimpleNavBox(string title, NavMenu linksArray)
      returns a simple navigation box. Accepts the following arguments:
        . title
        . linksArray

    string makeMenuBox(string title, string [descr], NavArray [menuArray], NavArray [linksArray])
      returns a menu box, which gives access to first-level functionality about one element
      (to be displayed on the "same" page) and to other elements. By same page, it is meant
      that the menu remains the same if first-level functionality is used, even if the file
      actually changes. Accepts the following arguments:
        . title, the name of the element presented by the menu
        . descr, displayed under the title, as simple text
        . menuArray, displayed under the descr, contains the options to navigate within this
          menu.
        . linksArray, displayed on the right of the main box, which allows to click through to
          the same menu for another element.

    string makeLoginForm(string [errMessage], string [targetPage='index.php'], array [postData])
      returns a login form. Accepts the following arguments:
        . errMessage, which triggers the display of an error message from the 'login' part.
          This is the string used as key to obtain the value stored in
          $pcLocalizedErrorMessages['adminLogin'][errMessage]
        . targetPage, URL of the page the form will be submitted to
        . postData should be given $HTTP_POST_VARS (or whatever array constructed in a similar
          way that contains the relevant info that must be submitted to the next page)
      If called properly, this should allow the user to take up his session where he left it
      and not lose any input even if the session has broken in the meanwhile.

    string makeDisplayBox(string boxContent, string [boxTitle], string [submitToPage])
      returns a display and edit box. Accepts the following arguments:
        . boxContent is displayed as passed inside the box.
        . boxTitle is the title of the box
        . if set, submitToPage transforms the display box into an edit form which is
          submitted to the page referenced by submitToPage\


 */

include ('lib/messages.inc.php');

function pageHeader($title=false, $message=false, $moduleId=false, $moduleName=false, $typeId=false, $typeName=false) {
  global $pcAdminMsg;
  $returnHeader = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>PointComma admin';
  if ($title) {
    $returnHeader .= " - $title";
  }
  $returnHeader .= '</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<link rel="stylesheet" href="img/style.css" type="text/css"/>
';
	if (isset($_SESSION['pcDebugSwitch'])) {
		if ($_SESSION['pcDebugSwitch'] == 1) {
		$returnHeader .= '
<style type="text/css">
pre.debug {
	font-size: 1.5em;
}
</style>
';
		}
	}
	$returnHeader .= '
<script type="text/javascript"><!--
if (navigator.appName=="Netscape") {
  fichier = "nn" ;
} else {
  fichier = "ie";
}
document.write(\'<link href="img/\'+ fichier + \'.css" rel="stylesheet" type="text/css">\');

function jumpPage(what) {
  if (what.value != "0") {
    what.form.submit();
  }
}

// --></script>
</head>
<body>
<div><a name="pagetop"></a></div>
';

if ((isset($_SESSION['pcDebugDisplay'])) and ($_SESSION['pcDebugDisplay'])) {
	$returnHeader .= "<script type=\"text/javascript\">
	<!--
	debugconsole = window.open(\"debug.php\",\"PointCommaDebugConsole\",\"width=680,height=600,resizable,scrollbars=yes\",true);
	//-->
	</script>";
}
  $returnHeader .= '<div class="nav">'."\n";
  if ($moduleId && $typeId) {
    $maxLevel = 3;
  } else if ($moduleId || $typeId) {
    $maxLevel = 2;
  } else {
    $maxLevel = 1;
  }
  $returnHeader .= makeNavLine();
  if ($moduleId) {
    $returnHeader .= makeNavLine('module', 2, $moduleName, $moduleId);
  }
  if ($typeId) {
    $returnHeader .= makeNavLine('type', $maxLevel, $typeName, $typeId);
  }
  $returnHeader .= "\n</div>\n"; // div class="nav"
  $returnHeader .= '<div class="main" id="main'.$maxLevel.'">'."\n";
  if ($title) {
    $returnHeader .= '  <h1>'.$title."</h1>\n";
  }
  if ($pcAdminMsg) {
      trigger_error(strip_tags($pcAdminMsg),WARNING);
      $fullAdminMsg = $pcAdminMsg;
  } 
  return $returnHeader;
}

function pageFooter($mainNav=false, $moduleId=false, $moduleName=false, $typeId=false, $typeName=false) {
  $returnFooter = "\n</div>\n".'<div class="nav">'."\n";
  if ($moduleId && $typeId) {
    $maxLevel = 3;
  } else if ($moduleId || $typeId) {
    $maxLevel = 2;
  }
  if ($mainNav) {
    if ($typeId) {
      $returnFooter .= makeNavLine('type', $maxLevel, $typeName, $typeId);
    }
    if ($moduleId) {
      $returnFooter .= makeNavLine('module', 2, $moduleName, $moduleId);
    }
    $returnFooter .= makeNavLine();
  } else {
    $returnFooter .= makeNavLine('mini');
  }
  $returnFooter .= "\n</div>\n</body>\n</html>";
  return $returnFooter;
}

function makeNavLine($type='main', $level=1, $name=false, $id=false) {
  global $pcConfig;

  $clearance = unserialize(CLEARANCE);

  switch ($type) {

    case 'main':
      $leftNav = '<b>;PointComma</b> | '.$pcConfig['siteName'];
      $rightNav = '<a href="index.php">main menu</a> |';
      if ($clearance['isSupervisor']) {
        $rightNav .= '| <a href="user.php">users</a> |';
      } else if (!empty($clearance['userName'])) {
        $rightNav .= '| <a href="user.php?userName='.$clearance['userName'].'">my account</a> |';
      }
      $rightNav .= '| <a href="'.$pcConfig['productionServer'].'">web site</a>';
      if ($clearance['userName']) {
        $rightNav .= ' || <a href="logout.php">logout</a>';
      }
    break;

    case 'mini':
      $level = 'footer';
      $leftNav = '';
      $rightNav = '<a href="#pagetop">top</a> || <a href="index.php">main menu</a> || <a href="test.php">debug info</a> || <a href="'.$pcConfig['productionServer'].'">web site</a>';
      if ($clearance['userName']) {
        $rightNav .= ' || <a href="logout.php">logout</a>';
      }
    break;

    case 'module':
      $leftNav = 'Module: <b>'.$name.'</b>';
      $rightNav = '<a href="module.php?moduleId='.$id.'">module menu</a>';
      if ($clearance['isModuleSupervisor'][$id]) {
        $rightNav .= ' || <a href="user.php?moduleId='.$id.'">users</a> ';
      }
      if ($clearance['isFrameworkMgr']) {
        $rightNav .= ' || <a href="type.php?typeId=new&amp;moduleId='.$id.'">new type</a>';
      }
    break;

    case 'type':
      $leftNav = 'Type: <b>'.$name.'</b>';
      $rightNav = '<a href="type.php?typeId='.$id.'">type menu</a> || ';
      if ($clearance['rights'][$id] > 1) {
        $rightNav .= '<a href="type.php?typeId='.$id.'&amp;action=items&amp;pubState=1">submitted items</a> | <a href="type.php?typeId='.$id.'&amp;action=items&amp;pubState=5">published items</a>';
      } else {
        $rightNav .= '<a href="type.php?typeId='.$id.'&amp;action=items">submitted items</a>';
      }
      $rightNav .= ' | <a href="item.php?typeId='.$id.'&amp;itemId=new">new item</a>';
    break;

  }

  $returnNav = '  <div class="navline" id="nav'.$level.'">
    <span class="navleft">'.$leftNav.'</span>
    <span class="navright">'.$rightNav.'</span>
    <div class="spacer"></div>
  </div>';
  return $returnNav;
}

function makeNavBox($menu, $title, $href, $descr=false, $xData=false, $links=false) {
  $returnBox = '<table class="actionbox" border="0" cellpadding="0" cellspacing="0"><tr><td width="100%">';
  $returnBox .= '  <div class="boxtitle"><a href="'.$href.'">'.$title."</a></div>\n\n";
  if ($descr) {
    $returnBox .= '  <p class="boxdescr">'.$descr."</p>\n\n";
  }
  if ($xData) {
    $returnBox .= '  <p class="boxextra">'.$xData."</p>\n\n";
  }
  $returnBox .= '  </td><td class="boxright">
    <div class="spaceboxright"></div>
    <p class="boxmenu"><a href="'.$href.'">'.$menu.'</a></p>';

  $returnBox .= displayNavArray($links);
  // Deal with links

  $returnBox .= "\n</td></tr></table>\n";

  return $returnBox;
}

function makeMenuBox($title, $descr=false, $menu=false, $links=false) {
  $returnBox = '<table class="actionbox" border="0" cellpadding="0" cellspacing="0"><tr><td width="100%">';
  $returnBox .= '  <h1>'.$title."</h1>\n\n";
  if ($descr) {
    $returnBox .= '  <p class="boxdescr">'.$descr."</p>\n\n";
  }

  $returnBox .= "\n".'<div class="actionlinks">';
  $returnBox .= displayNavArray($menu, true);
  $returnBox .= "\n</div>\n";
  // Deal with menu action links
  // Creates a flat menu bar (buttons)

  $returnBox .= '  </td><td class="boxright">
    <div class="spaceboxright"></div>';

  $returnBox .= displayNavArray($links);
  // Deal with nav links

  $returnBox .= "\n</td></tr></table>\n";

  return $returnBox;
}

function makeSimpleNavBox($title, $links) {
  $returnBox = '<div class="actionbox">';
  $returnBox .= '<p class="actiontitle">'.$title."</p>\n";
  $returnBox .= '<div class="actionlinks">';
  $returnBox .= displayNavArray($links, true);
  // Request a flat links list
  $returnBox .= "\n</div>\n</div>\n";
  return $returnBox;
}

function displayNavArray($links, $isFlat=false) {
  if (!is_array($links) || !count($links) || !$links) {
    return '';
  }
  $returnLinks = "";
  foreach ($links as $oneLink) {
    if ($isFlat) {
      // Return a horizontal, button-like list of items.
      $returnLinks .= '<div class="boxflatlink">';
      if (isset($oneLink['label'])) {
        // A simple item
        if ($oneLink['href']) {
          // It's a link
          $returnLinks .= ' [<a href="'.$oneLink['href'].'">'.$oneLink['label']."</a>] ";
        } else {
          // It's just a text item, return bold text
          $returnLinks .= ' <b><p class="boxitem">- '.$oneLink['label']."</b> ";
        }
      }
      else {
        // A pull-down action menu
        $returnLinks .= '      <form action="'.$oneLink['action'].'" method="get"><p class="boxform">';
        if (isset($oneLink['hiddenName1'])) {
          $returnLinks .= '<input type="hidden" name="'.$oneLink['hiddenName1'].'" value="'.$oneLink['hiddenVal1'].'"/>';
        }
        if (isset($oneLink['hiddenName2'])) {
          $returnLinks .= '<input type="hidden" name="'.$oneLink['hiddenName2'].'" value="'.$oneLink['hiddenVal2'].'"/>';
        }
        $returnLinks .= '
        <select name="'.$oneLink['selectName'].'" onchange="if(this.value!=0){this.form.submit();}">'."\n";
        foreach ($oneLink['menu'] as $oneOption) {
          $returnLinks .= '          <option value="'.$oneOption['value'].'"';
          if ($oneOption['isSelected']) {
            $returnLinks .= ' selected="selected"';
          }
          $returnLinks .= '>'.$oneOption['label']."</option>\n";
        }
        $returnLinks .= '        </select></p></form>';
      }
      $returnLinks .= "</div>\n";
    } else {
      // Returns a vertical, bulleted list of items.
      if (isset($oneLink['label'])) {
        // A simple item
        if (isset($oneLink['href'])) {
          // It's a link
          $returnLinks .= '      <p class="boxitem">- <a href="'.$oneLink['href'].'">'.$oneLink['label']."</a></p>\n";
        } else {
          // It's just a text item
          $returnLinks .= '      <p class="boxitem">- '.$oneLink['label']."</p>\n";
        }
      } else {
        // A pull-down action menu
        $returnLinks .= '      <form action="'.$oneLink['action'].'" method="get"><p>- ';
        if (isset($oneLink['hiddenName1'])) {
          $returnLinks .= '<input type="hidden" name="'.$oneLink['hiddenName1'].'" value="'.$oneLink['hiddenVal1'].'"/>';
        }
        if (isset($oneLink['hiddenName2'])) {
          $returnLinks .= '<input type="hidden" name="'.$oneLink['hiddenName2'].'" value="'.$oneLink['hiddenVal2'].'"/>';
        }
        $returnLinks .= '
        <select name="'.$oneLink['selectName'].'" onchange="if(this.value!=0){this.form.submit();}">'."\n";
        foreach ($oneLink['menu'] as $oneOption) {
          $returnLinks .= '          <option value="'.$oneOption['value'].'"';
          if (isset($oneOption['isSelected']) && $oneOption['isSelected']) {
            $returnLinks .= ' selected="selected"';
          }
          $returnLinks .= '>'.$oneOption['label']."</option>\n";
        }
        $returnLinks .= '        </select></p></form>';
      }
      // end if link or pull-down
    }
    // end else !isFlat
  }
  // end foreach link

  return $returnLinks."\n";
}


function makeLoginForm($errMessage='notloggedin', $targetPage='index.php', $postData=false) {
  if ($errMessage == 'logout') {
    $loginForm = pageHeader('Logged out',"You've successfully logged out. You may now close your broswer window safely.");
  } else {
    $loginForm = pageHeader('Login');
  }
  ob_start();
  pcErrorDisplay(WARNING);
  $loginForm .= ob_get_contents();
  ob_end_clean();
  $loginForm .= '<form action="'.$targetPage.'" method="post">
  <table border="0" cellpadding="1" cellspacing="0">
    <tr>
      <td align="right">User name:</td>
      <td><input type="text" name="pcLoginUserName"/></td>
    </tr>
    <tr>
      <td align="right">Password:</td>
      <td><input type="password" name="pcLoginPassword"/></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" value="Log in"/></td>
    </tr>
  </table>
  ';

  if ($postData) {
    // Ensures posted data is not lost if the session has closed
    foreach ($postData as $key => $val) {
      $loginForm .= '<input type="hidden" name="'.$key.'" value="'.$val.'"/>';
    }
  }
  $loginForm .= '</form>';
  $loginForm .= pageFooter();
  return $loginForm;
}


function makeDisplayBox($boxContent, $boxTitle=false, $submitToPage=false, $onSubmitAction=false) {
  $returnBox="";
  if ($boxTitle) {
    $returnBox .= "\n".'<div class="dispboxtitle">'.$boxTitle."</div>\n";
  }
  $returnBox .= "\n".'<div class="displaybox">';
  if ($submitToPage) {
    $returnBox .= "\n".'<form action="'.$submitToPage.'" method="post"';
    if ($onSubmitAction) {
      $returnBox .= ' onSubmit="'.$onSubmitAction.'"';
    }
    $returnBox .= ' name="editform">';
  }
  $returnBox .= $boxContent;
  if ($submitToPage) {
    $returnBox .= '<div class="dispboxsubmit"><input type="submit" value="submit" /></div>'."\n</form>\n";
  }
  $returnBox .= "\n</div>\n";
  return $returnBox;
}

?>
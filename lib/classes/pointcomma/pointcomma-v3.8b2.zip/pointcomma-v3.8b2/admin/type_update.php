<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcinput.php');
include("lib/adminlib.inc.php");

$action = pcDefaultValue('string', '', 'action', 'P');
$typeId = pcDefaultValue('pcTypeId', '', 'typeId', 'P');
$label = pcDefaultValue('string', '', 'label', 'P');
$typeIdent = pcDefaultValue('string', '', 'typeIdent', 'P');
$typeInherited = pcDefaultValue('pcTypeId', '', 'inherit_from', 'P');
$moduleId = pcDefaultValue('pcStrId', '', 'moduleId', 'P');
$numChars = pcDefaultValue('numeric', 0, 'numChars', 'P');
$numDelChars = pcDefaultValue('numeric', 0, 'numDelChars', 'P');
$sureDelete = pcDefaultValue('bool', 0, 'sureDelete', 'P');
$charId = pcDefaultValue('array', array(), 'charId', 'P');
$showChar = pcDefaultValue('array', array(), 'showChar', 'P');
$moveChar = pcDefaultValue('array', array(), 'moveChar', 'P');
$defining = pcDefaultValue('array', array(), 'defining', 'P');
$charLabel = pcDefaultValue('array', array(), 'charLabel', 'P');
$charKey = pcDefaultValue('array', array(), 'charKey', 'P');
$charFormat = pcDefaultValue('array', array(), 'charFormat', 'P');
$limitTo = pcDefaultValue('array', 0, 'limitTo', 'P');
$valuesList = pcDefaultValue('array', 0, 'valuesList', 'P');

$numCharsToAdd = 0;

if (empty($typeId)) {
  header('Location: ./?pcAdminMsg=errtypenotspecified');
	exit();
}

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // User must be logged in
  echo makeLoginForm('notloggedin', "type.php", $HTTP_POST_VARS);
  exit();
}

if ($typeId == 'new') {
  $action = 'new';
  if (!$clearance['isModuleMgr'][$moduleId]) {
    // User must have module management rights to this type's module
    echo makeLoginForm('authtoolow');
    exit();
  }
	// test if the user has right over the inherited type
	if ($typeInherited) {
		if (!$clearance['rights'][$typeInherited]) {
			// User must have right over the inherited type
			echo makeLoginForm('authtoolow');
			exit();
		}
	}
} else {
  if (!$typeQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId LIKE \''.addslashes($typeId).'\'')) {
    header('Location: ./?pcAdminMsg=errwrongtype');
    exit();
  }
  $type = $typeQuery[0];

  if (!$clearance['isModuleMgr'][$type['moduleId']]) {
    // User must have module management rights to this type's module
    echo makeLoginForm('authtoolow');
    exit();
  }
}

// recheck action
$action = pcDefaultValue('string', $action, 'action');

switch ($action) {
  // What are we doing?

	//create a new type
  case 'new':
		//help the user by avoiding to much error messages
		$typeIdent = strtolower(trim($typeIdent));
	
		//test that it is a legal label
		if ($typeIdent === '') {
				trigger_error('The label of a type cannot be empty, the type can\'t be created',ERROR);
			  header('Location: module.php?moduleId='.$moduleId);
				exit();
		} elseif (!preg_match('/^[a-z][a-z0-9_]{0,6}[a-z0-9]$/', $typeIdent)) {
			trigger_error('You provided a bad identifier: it may contain only alphanumeric characters and the underscore; it must contain between 2 and 8 characters; it must start with a letter; it must end with a letter or a number. Cannot create type',ERROR);
			header('Location: module.php?moduleId='.$moduleId);
			exit();
	}

		//build the typeID
		$typeId =  $moduleId . '__' . $typeIdent;

		//test if the table already exist
	 $result = pcdb_select('show tables like \''.addslashes($pcConfig['dbPrefix']).addslashes($typeId).'\'');

		if ( (isset($result[0])) and (in_array($pcConfig['dbPrefix'].$typeId,$result[0]))) {
			trigger_error('The type table you tried to create already exists, type not generated.',ERROR);
			header('Location: module.php?moduleId='.$moduleId);
			exit();
		}

		//test if the type is already defined
		//the previous test indirectly provided that information but the test is not explicitly carried out
		$boolTypeExist = pcdb_select('SELECT typeId FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId LIKE \''.addslashes($typeId).'\'');

		if (isset($boolTypeExist[0]) and ($boolTypeExist[0]['typeId']==$typeId)) {
			trigger_error('A type with that identifier already exist in that module, you cannot create a new one, please change the identifier',ERROR);
			header('Location: module.php?moduleId='.$moduleId);
			exit();
		}

		//create the table for item of this type
		if ($typeInherited) {
			$returnId = pcdb_insert('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'types` (typeId,moduleId, label, inherit_from, createdBy) VALUES (\''.addslashes($typeId).'\',\''.addslashes($moduleId).'\', \''.addslashes($label).'\',\''.addslashes($typeInherited).'\',\''.addslashes($clearance['userName']).'\')');
		} else {
			$returnId = pcdb_insert('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'types` (typeId,moduleId, label, createdBy) VALUES (\''.addslashes($typeId).'\',\''.addslashes($moduleId).'\', \''.addslashes($label).'\',\''.addslashes($clearance['userName']).'\')');
		}

    if ($returnId === 0) {
      pcdb_query('CREATE TABLE `'.addslashes($pcConfig['dbPrefix']).addslashes($typeId).'` (itemId SMALLINT NOT NULL)') or trigger_error('The database for type can\'t be created',ERROR);
      setGlobal('lastAdminUpdateOn', time());
      setGlobal('lastAdminUpdateBy', $clearance['userName']);
      header('Location: type.php?typeId='.$typeId.'&action=chars&pcAdminMsg=typecreated');
      exit();
    } else {
      header('Location: module.php?moduleId='.$moduleId.'&pcAdminMsg=errtypenotcreated');
      exit();
    }
  break;

  case 'descr':
		 if (pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'types` SET label=\''.addslashes($label).'\' WHERE typeId=\''.addslashes($typeId).'\'')) {
      setGlobal('lastAdminUpdateOn', time());
      setGlobal('lastAdminUpdateBy', $clearance['userName']);
      header('Location: type.php?typeId='.$typeId.'&pcAdminMsg=typedescrupdated');
      exit();
    }
    else {
      header('Location: type.php?typeId='.$typeId.'&pcAdminMsg=errtypedescrnotupd&action=descr');
      exit();
    }
  break;

  case 'chars':
    $pcDealWithType = true;
    $pcDealWithType = pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'types` SET lastUpdateBy=\''.addslashes($clearance['userName']).'\' WHERE typeId=\''.addslashes($typeId).'\'') && $pcDealWithType;

    $numCharsToHandle = $numChars + $numDelChars;
    assert("\$pcConfig['debug']['errorLevel'] > pcDebugInfo(get_defined_vars(),'pcTypeManagement', 'type update',2,\"Chars to handle: \$numCharsToHandle (\$numChars + \$numDelChars)\")");

    if ($numCharsToHandle > 0) {
      $numCharsToAdd = 0;
      // Initialize the counter of blank char forms to request from type.php after this update

      for ($i=0; $i < $numCharsToHandle; $i++) {
				if (isset($showChar[$i])) {
          assert("\$pcConfig['debug']['errorLevel'] > pcDebugInfo(get_defined_vars(),'pcTypeManagement', 'type update',0,\"This char (\$i): ".$showChar[$i]."\")");
					if ($moveChar[$i] == 1) {
						$sequence = $i + 1;
					} else if ($moveChar[$i] == 2) {
						$sequence = $i - 1;
					} else {
						$sequence = $i;
					}
					if ($defining[$i] == '1') {
						$defining[$i] = 1;
						$def[$i] = 1;
					} else {
						$defining[$i] = 0;
						$def[$i] = 0;
					}
				}
        if (!isset($charId[$i])) {
          // Increases the blank forms counter: the char data is not submitted, but its creation is requested
          $numCharsToAdd++;
        } elseif ($showChar[$i] == 1) {
          // the char data has been submitted, it's either new or existing
          if ($charId[$i] == "new") {
            // for a new char

						//for being a bit user friendly lower the case
						$charKey[$i] = strtolower(trim($charKey[$i]));

						// Check if the Char Key is not empty
						if ($charKey[$i] === '') {
							trigger_error('A label cannot be left blank or contain no alphanumeric character',ERROR);
							header('Location: type.php?typeId='.$typeId.'&action=chars');
						}elseif (!preg_match('/^[a-z][a-z0-9_]{0,16}[a-z0-9]$/', $charKey[$i])) {
							trigger_error('Key identifier '.$charKey[$i].' was not accepted: it may contain only alphanumeric characters and the underscore; it must contain between 2 and 18 characters; it must start with a letter; it must end with a letter or a number. Characteristic not created',ERROR);
							header('Location: type.php?typeId='.$typeId.'&action=chars');
							exit();
						}

						//Check that this columnId is unique in the type
						$boolColumnExist = pcdb_select('SELECT columnId FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE columnId LIKE \''.addslashes($charKey[$i]).'\' AND typeId LIKE \''.addslashes($typeId).'\'');

						if (isset($boolColumnExist[0]) and ($boolColumnExist[0]['columnId']==$charKey[$i])) {
								trigger_error('A characteristic with that identifier already exist in that type, you cannot create a new one, please change the identifier',ERROR);
								header('Location: type.php?typeId='.$typeId.'&action=chars');
								exit();
						}

            // everything that not matches the pattern will be removed from the string
            // oh, maximum length = 8, same as in database
            // constrained format shoud be fixed now
            if ($charFormat[$i]!='0') {
              $newCharId = pcdb_insert('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'characteristics` (typeId, columnId, label, format, defining, sequence) VALUES (\''.addslashes($typeId)."','".addslashes($charKey[$i])."', '".addslashes($charLabel[$i])."', '".addslashes($charFormat[$i])."', '".addslashes($def[$i])."', '".addslashes($sequence)."')");
              if ($newCharId) {
                  $pcDealWithType = pcdb_query('ALTER TABLE `'.addslashes($pcConfig['dbPrefix']).addslashes($typeId).'` ADD `'.addslashes($charKey[$i])."` ".addslashes($pcColumns['charTypes'][$charFormat[$i]]).addslashes($pcColumns['charModifier'][$charFormat[$i]])) && $pcDealWithType;
									assert("\$pcConfig['debug']['errorLevel'] > pcDebugInfo(get_defined_vars(),'pcCharManagement', 'Create a new char: new column',4,'ColumnId: '.\$charKey[\$i].' Format: '.\$pcColumns['charTypes'][\$charFormat[\$i]].\$pcColumns['charModifier'][\$charFormat[\$i]])");
									trigger_error('New Characteristic  '.$charKey[$i]. ' added',WARNING);
              }
            } else {
              // no default value set, don't take action
              header('Location: type.php?typeId='.$typeId.'&pcAdminMsg=errnocharformat&action=chars');
              exit();
            }

          } elseif ($charId[$i] != "new") {
            // for an existing char

						//get the old label
						$tempArray = pcdb_select('SELECT columnId,format from `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE charId ='.addslashes($charId[$i]));

						if (!$tempArray) {
							//problem with the id asked
							trigger_error('Unknown error in the characteristic\'s information, characteristic won\'t be modified',ERROR);
							header('Location: type.php?typeId='.$typeId.'&action=chars');
              exit();
						}

						$oldKey[$i] = $tempArray[0]['columnId'];
						$oldFormat[$i] = $tempArray[0]['format'];

						$charKey[$i] = strtolower($charKey[$i]);

						// Check if the Char Key is not empty
						if ($charKey[$i] == '') {
							trigger_error('A label cannot be left blank or contain no alphanumeric character',ERROR);
							header('Location: type.php?typeId='.$typeId.'&action=chars');
						}		elseif (!preg_match('/^[a-z][a-z0-9_]{0,16}[a-z0-9]$/', $charKey[$i])) {
							trigger_error('Key identifier '.$charKey[$i].' was not accepted: it may contain only alphanumeric characters and the underscore; it must contain between 2 and 18 characters; it must start with a letter; it must end with a letter or a number. Characteristic has not been modified',ERROR);
							header('Location: type.php?typeId='.$typeId.'&action=chars');
							exit();
						}

            if ($charFormat[$i] != $oldFormat[$i]) {
							//Different Characteristic Format

							//TODO: Improve it : not simply delete the data but try to retype them

							//Delete the data already stored in the old type format
              $pcDealWithType = deleteXvalsFromChar($charId[$i]) && $pcDealWithType;

							trigger_error('You modified the format of a the characteristic '.$charKey[$i]. ': all data stored in the previous format have been deleted');

							//Update the characteristic table
							$pcDealWithType = pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'characteristics` SET format=\''.addslashes($charFormat[$i]) .'\' WHERE charId='.addslashes($charId[$i])) && $pcDealWithType;

							//Modify the table type
							$pcDealWithType = pcdb_query('ALTER TABLE `'.addslashes($pcConfig['dbPrefix']).addslashes($typeId).'` CHANGE `'.addslashes($oldKey[$i])."` `".addslashes($oldKey[$i])."` ".addslashes($pcColumns['charTypes'][$charFormat[$i]].$pcColumns['charModifier'][$charFormat[$i]])) && $pcDealWithType;

							assert("\$pcConfig['debug']['errorLevel'] > pcDebugInfo(get_defined_vars(),'pcCharManagement', 'Change old column format',4,'ColumnId: '.\$oldKey[\$i].' NewColumnFormat: '.\$pcColumns['charTypes'][\$charFormat[\$i]].\$pcColumns['charModifier'][\$charFormat[\$i]])");
            }

						//Check it he Char Key has change
						 if ($charKey[$i] != $oldKey[$i]) {
								//modify the table name
								$pcDealWithType = pcdb_query('ALTER TABLE `'.addslashes($pcConfig['dbPrefix']).addslashes($typeId).'` CHANGE `'.addslashes($oldKey[$i])."` `".addslashes($charKey[$i])."` ".addslashes($pcColumns['charTypes'][$charFormat[$i]])) && $pcDealWithType;
								assert("\$pcConfig['debug']['errorLevel'] > pcDebugInfo(get_defined_vars(),'pcCharManagement', 'Modify Column Name',4,\"for type \$typeId , char label: \$oldKey[\$i] into \$charKey[\$i]  \")");
								trigger_error('You change the label of the characteristic '.$charKey[$i]. ': the name of the column in the corresponding table has been changed',WARNING);
						 }

						 //store the characteristics
            $pcDealWithType = pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'characteristics` SET label=\''.
            addslashes($charLabel[$i])."', columnId='".
						addslashes($charKey[$i])."', defining='".
            addslashes($defining[$i])."', limitTo='".
            addslashes($limitTo[$i])."', valuesList='".
            addslashes($valuesList[$i])."', sequence=$sequence WHERE charId=".
						addslashes($charId[$i])) && $pcDealWithType;
          }
        } else { // if char deletion requested
          if ($charId[$i] != "new") {
            $pcDealWithType = deleteXvalsFromChar($charId[$i]) && $pcDealWithType;
            $pcDealWithType = pcdb_query('ALTER TABLE `'.addslashes($pcConfig['dbPrefix']).addslashes($typeId).'` DROP `'.addslashes($charKey[$i])."`") && $pcDealWithType;
            $pcDealWithType = pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE charId='.addslashes($charId[$i])) && $pcDealWithType;
						trigger_error('The characteristic  '.$charKey[$i]. ' has been deleted',WARNING);
          }
        }
      }
      // End For
    } else {
      // if $numCharsToHandle == "0"
      $returnBool = true;
			foreach ($charId as $i => $char) {
				$returnBool = deleteXvalsFromChar($char) && $returnBool;
				// +++
				$pcDealWithType = pcdb_query('ALTER TABLE `'.addslashes($pcConfig['dbPrefix']).addslashes($typeId).'` DROP `'.addslashes($charKey[$i])."`") && $pcDealWithType;
			}
      $pcDealWithType = pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE typeId=\''.addslashes($typeId).'\'') && $pcDealWithType;
    }
    setGlobal('lastAdminUpdateOn', time());
    setGlobal('lastAdminUpdateBy', $clearance['userName']);
    if (!$pcDealWithType) {
      echo pageHeader("Error");
			trigger_error('an error occured during the update of your type, it can\'t be saved',ERROR);
      pcErrorDisplay(WARNING);

      echo pageFooter();
    } else if ($numCharsToAdd > 0) {
      header('Location: type.php?typeId='.$typeId.'&action=chars&addChars='.$numCharsToAdd);
			exit();
    } else {
      header('Location: type.php?typeId='.$typeId.'&action=chars');
			exit();
    }
  break;

  case 'del':
    if ($sureDelete) {
      // Deletes the type
      if (deleteType($typeId)) {
        setGlobal('lastAdminUpdateOn', time());
        setGlobal('lastAdminUpdateBy', $clearance['userName']);
        header('Location: module.php?moduleId='.$type['moduleId'].'&pcAdminMsg=typedeleted');
        exit();
      } else {
        // Deletion failed
        header('Location: type.php?typeId='.$typeId.'&pcAdminMsg=errtypenotdeleted');
        exit();
      }
    } else {
      // Deletion was not requested
      header('Location: type.php?typeId='.$typeId.'&pcAdminMsg=typenotdeleted');
			exit();
    }
  break;

  default :
}
// End switch $action

?>
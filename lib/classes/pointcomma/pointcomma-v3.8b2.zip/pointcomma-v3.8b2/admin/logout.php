<?php
$pcLoginUserName='logout';
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
include("lib/htmllib.inc.php");

echo makeLoginForm('logout');
?>
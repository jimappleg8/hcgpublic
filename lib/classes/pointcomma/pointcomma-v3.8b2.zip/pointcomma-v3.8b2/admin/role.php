<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pceditor.php');
include("lib/adminlib.inc.php");

$clearance = unserialize(CLEARANCE);

$pcAdminMsg = pcDefaultValue('string', '', 'pcAdminMsg', 'G');
$roleId = pcDefaultValue('pcId', 0, 'roleId', 'GP');
$moduleId = pcDefaultValue('pcStrId', '', 'moduleId', 'GP');
$action = pcDefaultValue('string', '', 'action', 'G');
$displayString = '';

if ($roleId == 'new') {
  // Create new role
  if (!$clearance['isModuleSupervisor'][$moduleId]) {
    echo makeLoginForm('authtoolow', 'module.php?moduleId='.$moduleId);
    exit();
  }
  $action = 'edit';
  $currentRole = array();
} else {
  $rsCurrentSelectedRole = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE roleId='.addslashes($roleId));
  $currentRole = $rsCurrentSelectedRole[0];
  $moduleId = $currentRole['moduleId'];
  if (!$clearance['isModuleSupervisor'][$moduleId]) {
    echo makeLoginForm('authtoolow', 'module.php?moduleId='.$moduleId);
    exit();
  }

  $navArray = array(
    array(
      'label' => 'new role',
      'href' => 'role.php?roleId=new&amp;action=new&amp;moduleId='.$moduleId
    ),
    array(
      'formName' => 'role',
      'action' => "role.php?moduleId=".$moduleId,
      'selectName' => 'roleId'
    )
  );

  $menuArray = array(
    array(
      'label' => 'general',
      'href' => "role.php?roleId=".$roleId
    ),
    array(
      'label' => 'assignments',
      'href' => "role.php?roleId=".$roleId."&amp;action=assign"
    ),
    array(
      'label' => 'authorization',
      'href' => "role.php?roleId=".$roleId."&amp;action=auth"
    ),
    array(
      'label' => 'edit',
      'href' => "role.php?roleId=".$roleId."&amp;action=edit"
    ),
    array(
      'label' => 'delete',
      'href' => "role.php?roleId=".$roleId."&amp;action=del"
    )
  );
    $rsAvailableModuleRoles = pcdb_select('SELECT roleId, label FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId=\''.addslashes($moduleId).'\'');

    for ($i=0;$i<count($rsAvailableModuleRoles);$i++) {
      $navArray[1]['menu'][$i]['label'] = $rsAvailableModuleRoles[$i]['label'];
      $navArray[1]['menu'][$i]['value'] = $rsAvailableModuleRoles[$i]['roleId'];
      $navArray[1]['menu'][$i]['isSelected'] = ($rsAvailableModuleRoles[$i]['roleId'] == $roleId);
    }
}

  $rsModInfo = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId=\''.addslashes($moduleId).'\'');
  echo pageHeader("Roles menu", 0, $moduleId, $rsModInfo[0]['label']);
  pcErrorDisplay(WARNING);
  // comment : this part displays the form to change the role if the user has selected a
  //           role from the jump menu, thus the roleId is NOT 0, zero be nothing selected.
if ($roleId != 'new') {
  echo makeMenuBox($currentRole['label'], $currentRole['description'] , $menuArray, $navArray);
}

if (!isset($currentRole['label'])) {
	$currentRole['label'] = false;
	$currentRole['description'] = false;
	$currentRole['isModuleSupervisor'] = false;
	$currentRole['isModuleMgr'] = false;
}
switch($action){

	case 'edit' :
		$displayString = makeInputField('', 'moduleId', 'hidden', $moduleId);
		$displayString .= makeInputField('', 'roleId', 'hidden', $roleId);
		$displayString .= makeInputField('', 'action', 'hidden', 'edit');
		$displayString .= makeInputField('Label', 'label', 'string', $currentRole['label']);
		$displayString .= makeInputField('Description', 'description', 'text', $currentRole['description']);
		$displayString .= makeInputField('Module supervisor', 'isModuleSupervisor', 'bool', $currentRole['isModuleSupervisor'], 'Users may create users and handle roles in the module');
		$displayString .= makeInputField('Module manager', 'isModuleMgr', 'bool', $currentRole['isModuleMgr'], 'Users may manage types in the module');
		$boxDescr = ($roleId == 'new') ? 'Add a new role' : 'Edit role';
		echo makeDisplayBox($displayString, $boxDescr, 'role_update.php');
	break;


	case 'del' :
		$displayString  = makeInputField('Are you sure to delete this role, it will also delete its assignments and authorisations', 'sure', 'confirm');
		$displayString .= makeInputField(0, 'moduleId', 'hidden', $moduleId);
		$displayString .= makeInputField(0, 'roleId', 'hidden', $roleId);
		$displayString .= makeInputField(0, 'action', 'hidden', 'del');
		echo makeDisplayBox($displayString, 'Deleting the role','role_update.php');
	break;

	case 'assign' :
		// make sure we know what module and what role we are working in
		$displayString .= makeInputField('', 'roleId', 'hidden', $roleId);
		$displayString .= makeInputField('', 'moduleId', 'hidden', $moduleId);
		// get all the users
		// with left join to see whether they're
		// already assigned the current role
		$rsUserAssignments = pcdb_select('SELECT `'.addslashes($pcConfig['dbPrefix']).'webusers`.userName, firstName, lastName, roleId FROM `'.addslashes($pcConfig['dbPrefix']).'webusers` LEFT JOIN `'.addslashes($pcConfig['dbPrefix']).'assignments` ON `'.addslashes($pcConfig['dbPrefix']).'webusers`.userName = `'.addslashes($pcConfig['dbPrefix']).'assignments`.userName AND `'.addslashes($pcConfig['dbPrefix']).'assignments`.roleId = '.addslashes($roleId));
		for($i=0;$i<count($rsUserAssignments);$i++){
			$displayString .= makeInputField(
				$rsUserAssignments[$i]['userName'],
				'addAssignment['.$rsUserAssignments[$i]['userName'].']',
				'bool',
				($rsUserAssignments[$i]['roleId']==$roleId),
				// check if the user has an assignment to the current role
				$rsUserAssignments[$i]['firstName'].' '.$rsUserAssignments[$i]['lastName']
			);
		}
		$displayString .= makeInputField('', 'roleId', 'hidden', $roleId);
		$displayString .= makeInputField('', 'moduleId', 'hidden', $moduleId);
		$displayString .= makeInputField('', 'action', 'hidden', 'assign');
		echo makeDisplayBox($displayString, 'Assigments', 'role_update.php');
	break;

	case 'auth' :
		// make sure we know what module and what role we are working in
		$displayString .= makeInputField('', 'roleId', 'hidden', $roleId);
		$displayString .= makeInputField('', 'moduleId', 'hidden', $moduleId);
		// get all the types belonging to the current module
		$rsAllModuleTypes = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId=\''.addslashes($moduleId).'\'');
		// for all the types in the module check if they have a authorization belonging to the current role
		// and get their label
		for($i=0;$i<count($rsAllModuleTypes);$i++){
			// check if the type has an authorization to current role
			$rsAuthorizedType = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'authorizations` WHERE typeId LIKE \''.addslashes($rsAllModuleTypes[$i]['typeId'])."' AND roleId=".addslashes($roleId));
			if ($rsAuthorizedType) {
				$displayString .= makeInputField('', 'authId['.$rsAllModuleTypes[$i]['typeId'].']', 'hidden', $rsAuthorizedType[0]['authId']);
			} else {
				$rsAuthorizedType = array(0);
			}
			$selectArray = array(
				array(
					'value' => '0',
					'label' => "view"
				),
				array(
					'value' => '1',
					'label' => "submit",
					'isSelected' => ($rsAuthorizedType[0]['writeLevel'] == 1)
				),
				array(
					'value' => '2',
					'label' => "own",
					'isSelected' => ($rsAuthorizedType[0]['writeLevel'] == 2)
				),
				array(
					'value' => '3',
					'label' => "all",
					'isSelected' => ($rsAuthorizedType[0]['writeLevel'] == 3)
				)
			);
			$displayString .= makeInputField($rsAllModuleTypes[$i]['label'], 'addType['.$rsAllModuleTypes[$i]['typeId'].']', 'menu', $selectArray);
			$displayString .= makeInputField('', 'action', 'hidden', 'auth');
		}
		echo makeDisplayBox($displayString, 'Type Authorization', 'role_update.php');
	break;

	default :
		// This is to display the general part
		$displayString = '<p>All "published" items of all types are visible to all users.</p><p>Further rights:</p><ul>';
		$rsAuthorizedRoles = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'authorizations` WHERE roleId='.addslashes($roleId));
		for ($i=0;$i<count($rsAuthorizedRoles);$i++){
			$rsTypes = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId LIKE \''.addslashes($rsAuthorizedRoles[$i]['typeId']).'\'');
			switch ($rsAuthorizedRoles[$i]['writeLevel']){
			 case '0':
				 $displayString.= '<li>'.$rsTypes[0]['label'].': view all items</li>';
				 break;

			 case '1':
				 $displayString .= '<li>'.$rsTypes[0]['label'].': submit draft items</li>';
				 break;

			 case '2':
				 $displayString .= '<li>'.$rsTypes[0]['label'].': publish own items</li>';
				 break;

			 case '3':
				 $displayString .= '<li>'.$rsTypes[0]['label'].': fully control all items</li>';
				 break;

			}
		}
		if (!$rsAuthorizedRoles) {
			$displayString .= '<li>(none)</li>';
		}
		$displayString .= '</ul>';
		if ($currentRole['isModuleSupervisor']) {
			$displayString .= '<p>Promotes to <strong>module supervisor</strong> (full control on the module\'s types).</p>';
		}
		if ($currentRole['isModuleMgr']) {
			$displayString .= '<p>Promotes to <strong>module manager</strong> (full control on users and rights within the module).</p>';
		}
		echo makeDisplayBox($displayString, 'General Information');
}

echo pageFooter();
?>
<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pceditor.php');
include("lib/adminlib.inc.php");

$pcAdminMsg = pcDefaultValue('string', '', 'pcAdminMsg', 'G');
$action = pcDefaultValue('string', '', 'action', 'G');
$typeId = pcDefaultValue('pcTypeId', '', 'typeId', 'G');
$moduleId = pcDefaultValue('pcStrId', '', 'moduleId', 'G');
$addChars = pcDefaultValue('numeric', 0, 'addChars', 'G');
$orderBy = pcDefaultValue('numeric', 0, 'orderBy', 'G');
$pubState = pcDefaultValue('numeric', 1, 'pubState', 'G');
$editBox = '';

if (!$typeId) {
  header('Location: ./?pcAdminMsg=errtypenotspecified');
  exit();
}

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // User must be logged in
  echo makeLoginForm('notloggedin', "type.php?typeId=$typeId&amp;moduleId=$moduleId");
  exit();
}

if ($typeId == 'new') {
  if (!$clearance['isModuleMgr'][$moduleId]) {
    // User must have some rights to this type
    echo makeLoginForm('authtoolow');
    exit();
  }
  $action = 'descr';
  $moduleQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
  $module = $moduleQuery[0];
} else {
  if (!$clearance['rights'][$typeId]) {
    // User must have some rights to this type
    echo makeLoginForm('authtoolow');
    exit();
  }
  if (!$typeQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId LIKE \''.addslashes($typeId).'\'')) {
    header('Location: ./?pcAdminMsg=errwrongtype');
    exit();
  }
  $type = $typeQuery[0];
  if (!$moduleQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($type['moduleId']).'\'')) {
    header('Location: ./?pcAdminMsg=errwrongmodule');
    exit();
  }
  $module = $moduleQuery[0];
}

if (!isset($type)) {
	$type['typeId'] = false;
	$type['label'] = false;
	$type['typeIdent'] = false;
}
echo pageHeader("type menu", 0, $module['moduleId'], $module['label'], $type['typeId'], $type['label']);
pcErrorDisplay(WARNING);
// ----------------------------------------------------------------------------------------------------
// Now the functions used for the types

$charFormats = array(
  "i" => "One item",
  "s" => "String",
  "d" => "Date",
  "n" => "Number",
  "t" => "Text",
  "f" => "File",
  "b" => "Checkbox",
  "l" => "Selection menu",
  "u" => "User"
);

function makeTypeCharEditBox($maxNumChars, $sequence, $moduleId, $char=false) {
  global $charFormats, $pcConfig;
  // Generates the edit form for one char
  // if no $char is specified, returns a default form

if (!$char) {
  // Defaults to a new char
  $char = array();
  $char['charId'] = 'new';
  $char['columnId']= '';
  $char['label'] = "";
  $char['format'] = "";
  $char['defining'] = "";
  } else {
    $char['idLabel'] = ' (id '.$char['charId'].')';
  }

  $charToolBox = '<div class="charToolbox"><a href="JavaScript:deleteChar('.$sequence.')"><img src="img/delunit.gif" border="0" width="11" height="12" hspace="5" alt="Delete characteristic"></a>';
  if ($sequence > 0 && $sequence < $maxNumChars) {
    $charToolBox .= '<a href="JavaScript:moveChars('.$sequence.','.($sequence-1).')"><img src="img/up.gif" border="0" width="11" height="12" alt="move char up"></a>';
  } else {
    $charToolBox .= '<img src="img/transp.gif" width="11" height="12">';
  }
  if (!($sequence < ($maxNumChars-1)) || $maxNumChars == 1) {
    $charToolBox .= '<img src="img/transp.gif" width="11" height="12">';
  } else {
    $charToolBox .= '<a href="JavaScript:moveChars('.($sequence+1).','.$sequence.')"><img src="img/down.gif" border="0" width="11" height="12" alt="move char down"></a>';
  }
  $charToolBox .= makeInputField(false, 'moveChar['.$sequence.']', 'hidden', 0).makeInputField(false, 'showChar['.$sequence.']', 'hidden', 1).'</div>';

  $returnBox = "\n<h3>".$charToolBox.'Characteristic '.$char['label']."</h3>\n";
//  $returnBox = makeInputField($charToolBox.'Characteristic'.$char['idLabel'], 'showChar['.$sequence.']', 'keep', 'deleteOneChar(this.form, this)');
  $returnBox .= makeInputField('Label', 'charLabel['.$sequence.']', 'string', $char['label']);
  $returnBox .= makeInputField('Identifier', 'charKey['.$sequence.']', 'string', $char['columnId']);
  $returnBox .= makeInputField('Defining', 'defining['.$sequence.']', 'bool', $char['defining'], 'This characteristic is used to create the handle of items');
  $formatArray = array(
    array(
      'value' => 0,
      'label' => 'Choose a format'
    ), array (
      'value' => 0,
      'label' => ''
    )
  );
  foreach ($charFormats as $formatKey => $formatLabel) {
    $formatArray[$formatKey] = array(
      'value' => $formatKey,
      'label' => $formatLabel
    );
    if ($formatKey == $char['format']) {
      $formatArray[$formatKey]['isSelected'] = true;
    }
  }
  $returnBox .= makeInputField('Format', 'charFormat['.$sequence.']', 'menu', $formatArray);
  $returnBox .= makeInputField('', 'charId['.$sequence.']', 'hidden', $char['charId']);

  switch ($char['format']) {

    case 'b':
      // Boolean / checkbox
      $returnBox .= makeInputField('Description', 'valuesList['.$sequence.']', 'string', $char['valuesList']);
      $returnBox .= makeInputField('', 'limitTo['.$sequence.']', 'hidden');
    break;

    case 'd':
      // Date and/or time
      $timeSorts = array(
        1 => 'Year and month (10/2002)',
        2 => 'Date (21/10/2002)',
        3 => 'Date and time (21/10/2002 17:24)',
        4 => 'Date and full time (21/10/2002 17:24:33)',
        5 => 'Time (17:24)',
        6 => 'Full time (17:24:33)'
      );
      foreach ($timeSorts as $sortId => $sortLabel) {
        $limitToArray[] = array(
          'value' => $sortId,
          'label' => $sortLabel,
          'isSelected' => ($sortId == $char['limitTo'])
        );
      }
      $returnBox .= makeInputField('', 'limitTo['.$sequence.']', 'menu', $limitToArray);
      $returnBox .= makeInputField('', 'valuesList['.$sequence.']', 'hidden');
    break;

    case 'f':
      // File
      $returnBox .= makeInputField('Authorized extensions', 'valuesList['.$sequence.']', 'list', $char['valuesList'], '<b>EXAMPLES</b><br><b>gif, jpeg, jpg, png</b>: images<br><b>doc, xls, ppt</b>: MS office docs<br><b>swf</b>: Flash files');
      $returnBox .= makeInputField('', 'limitTo['.$sequence.']', 'hidden');
    break;

    case 'i':
      // Link to one item
      $arrayTypeValue = array(
        array(
          'value' => 0,
          'label' => 'Any type'
        )
      );
      if ($valueList = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId LIKE \''.addslashes($moduleId).'\' ORDER BY label')) {
        foreach ($valueList as $oneType) {
          $arrayTypeValue[] = array(
            'value' => $oneType['typeId'],
            'label' => $oneType['label'],
            'isSelected' => ($oneType['typeId'] == $char['valuesList'])
          );
        }
      }
      $returnBox .= makeInputField('Limit choice to', 'valuesList['.$sequence.']', 'menu', $arrayTypeValue);
      $returnBox .= makeInputField('', 'limitTo['.$sequence.']', 'hidden');
    break;

    case 'l':
      // Selection menu
      $returnBox .= makeInputField('Menu items', 'valuesList['.$sequence.']', 'list', $char['valuesList']);
      $returnBox .= makeInputField('', 'limitTo['.$sequence.']', 'hidden');
    break;

    case 't':
      // Text
      $arrayStyleValue = array(
        array(
          'value' => 'NONE',
          'label' => 'None',
					'isSelected' => ('NONE' == $char['valuesList'])
        ),
				array(
          'value' => 'RTE',
          'label' => 'Rich Text Editor',
					'isSelected' => ('RTE' == $char['valuesList'])
        ),
				array(
          'value' => 'SPIP',
          'label' => 'Spip',
					'isSelected' => ('SPIP' == $char['valuesList'])
        )
      );
      $returnBox .= makeInputField('Text Processing', 'valuesList['.$sequence.']', 'menu', $arrayStyleValue);
      $returnBox .= makeInputField('', 'limitTo['.$sequence.']', 'hidden');
    break;
    case 'n':
      // Number
    case 's':
      // String
    case 'u':
      // User
      $returnBox .= makeInputField('', 'limitTo['.$sequence.']', 'hidden');
      $returnBox .= makeInputField('', 'valuesList['.$sequence.']', 'hidden');
    break;

  }

//  $returnBox .= "\n</div>\n";
  // End of charbox

  return $returnBox;
}

function makeTypePageJS($numOldChars) {
  return "<script language=\"JavaScript\"><!--

document.oldNumChars = $numOldChars;

function checkForm(where) {
  // Characteristics
  if (!(where.numChars.value >= 0 && where.numChars.value < 50)) {
    alert('The number of extra characteristics\\nyou specified is not correct.\\nIt must be a number between\\n0 and 50.');
    where.numChars.value = document.oldNumChars;
    where.numChars.focus();
    return false;
  } else if (where.numChars.value == 0 && where.numChars.value < document.oldNumChars) {
    return confirm('Are you sure you want to\\nDELETE ALL CHARACTERISTICS\\nfrom this type?');
  } else if (where.numChars.value < document.oldNumChars) {
    alert('The number of characteristics you chose\\nis inferior to the previous value.\\nPlease specify a number GREATER\\nthan the previous value, or zero\\nto delete all chars.');
    document.xvalscorrect = false;
    where.numChars.value = document.oldNumChars;
    where.numChars.focus();
    return false;
  } else {
    return true;
  }
}

function deleteOneChar(where, box) {
  if (box.checked) {
    where.numChars.value++;
    document.oldNumChars++;
    where.numDelChars.value--;
  } else {
    where.numChars.value--;
    document.oldNumChars--;
    where.numDelChars.value++;
  }
}

function deleteChar(charId) {
  document.editform.numChars.value--;
  document.oldNumChars--;
  document.editform.numDelChars.value++;
  document.editform.elements['showChar[' + charId + ']'].value = 0;
  document.editform.submit();
}

function moveChars(mvup, mvdown) {
  document.editform.elements['moveChar[' + mvdown + ']'].value = 1;
  document.editform.elements['moveChar[' + mvup + ']'].value = 2;
  document.editform.submit();
}

// --></script>
<script language=\"JavaScript\" src=\"img/script.js\"></script>
";
}


// End of type functions
// ----------------------------------------------------------------------------------------------------


if ($clearance['isModuleMgr'][$module['moduleId']]) {
  // Type management only available to module managers
  $menuArray[0] = array(
    'label' => "general",
    'href' => 'type.php?typeId='.$typeId
  );
  $menuArray[1] = array(
    'label' => "description",
    'href' => 'type.php?typeId='.$typeId.'&amp;action=descr'
  );
//  $menuArray[2] = array(
//    'label' => "caching control",
//    'href' => 'type.php?typeId='.$typeId.'&amp;action=caching'
//  );
  $menuArray[3] = array(
    'label' => "characteristics",
    'href' => 'type.php?typeId='.$typeId.'&amp;action=chars'
  );
  $menuArray[4] = array(
    'label' => "delete",
    'href' => 'type.php?typeId='.$typeId.'&amp;action=del'
  );
}

if (isset($clearance['isModuleManager']) && $clearance['isModuleManager'][$module['moduleId']]) {
  $navArray[0] = array(
    'label' => 'new type for this module',
    'href' => 'type.php?typeId=new&amp;moduleId='.$module['moduleId']
  );
}

$navArray[1] = array(
  'action' => 'type.php',
  'selectName' => 'typeId',
  'menu' => array()
);
if ($allTypes = pcdb_select('SELECT typeId, label FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId LIKE \''.addslashes($module['moduleId']).'\'')) {
  for($i=0;$i<count($allTypes);$i++) {
    if ($clearance['rights'][$allTypes[$i]['typeId']]) {
      // Only those who have the proper rights may see the types
      $navArray[1]['menu'][$i]['label'] = $allTypes[$i]['label'];
      $navArray[1]['menu'][$i]['value'] = $allTypes[$i]['typeId'];
      if ($typeId == $allTypes[$i]['typeId']) {
        $navArray[1]['menu'][$i]['isSelected'] = true;
      }
    }
  }
}

if ($typeId != 'new') {
	if ($type['inherit_from']) {
		echo makeMenuBox($type['label'], 'This is type '.$type['typeId'].' inherited from type '.$type['inherit_from'], $menuArray, $navArray);
	} else {
		echo makeMenuBox($type['label'], 'This is type '.$type['typeId'], $menuArray, $navArray);
	}
}

switch ($action) {
  // Is there something we have to do?

  case 'descr':
    // Display description
    if ($typeId == 'new') {
			$editForm = makeInputField('Type name', 'label', 'string', '');
			$editForm .= makeInputField('Type identifier', 'typeIdent', 'string', '', '', 8);
			$editForm .= makeInputField(0, 'typeId', 'hidden', $typeId);
      $editForm .= makeInputField(0, 'moduleId', 'hidden', $moduleId);
      $boxDescr = "Enter the new type's name";

		//add the management of inheritance

		// determine the allowed type
		$arrayTypeValue[] = array('label'=> 'None','value'=> '0', 'isSelected'=> true);
		if ($allTypes = pcdb_select('SELECT typeId, label FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId LIKE \''.addslashes($module['moduleId']).'\'')) {
			for($i=0;$i<count($allTypes);$i++) {
				if ($clearance['rights'][$allTypes[$i]['typeId']]) {
					// Only those who have the proper rights may see the types
					$arrayTypeValue[] = array('label'=> $allTypes[$i]['label'],'value'=> $allTypes[$i]['typeId']);
					}
				}
		}
			//display the selection menu
			$editForm .= makeInputField('Inherit From', 'inherit_from', 'menu', $arrayTypeValue);
    } else {
      $boxDescr = "Edit this type's description";
			$editForm = makeInputField('Name', 'label', 'string', $type['label']);
      $editForm .= makeInputField(0, 'action', 'hidden', 'descr');
			$editForm .= makeInputField(0, 'typeId', 'hidden', $typeId);
    }
    echo makeDisplayBox($editForm, $boxDescr, 'type_update.php');
  break;

  case 'chars':
    // Display the type's characteristics

    $allTypeChars = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE typeId=\''.addslashes($typeId).'\' ORDER BY sequence');
    if (!is_array($allTypeChars)) {
      $allTypeChars = array();
    }
    $numOldTypeChars = count($allTypeChars);

    $numChars = $numOldTypeChars + $addChars;

    $editBox .= makeTypePageJS($numOldTypeChars);

    $editBox .= makeInputField(0, 'typeId', 'hidden', $type['typeId']);
    $editBox .= makeInputField(0, 'numDelChars', 'hidden', 0);
    $editBox .= makeInputField(0, 'action', 'hidden', 'chars');

    $editBox .= makeInputField('Characterisitcs', 'numChars', 'num', $numChars, '&nbsp; <input type="button" value="Add one" onClick="document.editform.numChars.value++;document.editform.submit()">');

    for ($i=0;$i<$numChars;$i++) {
	  if(isset($allTypeChars[$i])) {
        $oneChar = $allTypeChars[$i];
	  } else {
	    $oneChar = false;
	  }
      $editBox .= makeTypeCharEditBox($numChars, $i, $module['moduleId'], $oneChar);
    }

    echo makeDisplayBox($editBox, "Edit this type's characteristics", "type_update.php", 'return checkForm(this)');

  break;

  case 'del':
    $editBox = makeInputField('Yes, I really want to DELETE this type and all its items', 'sureDelete', 'confirm');
    $editBox .= makeInputField(0, 'typeId', 'hidden', $type['typeId']);
    $editBox .= makeInputField(0, 'action', 'hidden', 'del');
    echo makeDisplayBox($editBox, "Edit this type's characteristics", "type_update.php");
  break;

  case 'items':
    if ($clearance['rights'][$typeId] < 3) {
      // Defaults to showing only user's own submissions
      $pubState .= " && createdBy='".$clearance['userName']."' && lastUpdateBy = '".$clearance['userName']."'";
    }

		$orderByPossibilities = array(
			array('lastUpdateOn', 'last update'),
			array('createdOn', 'creation date'),
			array('handle', 'title'),
			array('itemId', 'item id')
		);

    if ($allItems = pcdb_select('SELECT itemId, handle FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.addslashes($typeId).'\' && pubState='.addslashes($pubState).' ORDER BY '.addslashes($orderByPossibilities[$orderBy][0]))) {
      $editBox .= '<p><b>Items</b> (order by: ';
			foreach ($orderByPossibilities as $key => $one) {
				if ($orderBy == $key) {
					$editBox .= '<strong>'.$one[1].'</strong>';
				} else {
					$editBox .= '<a href="type.php?typeId='.$typeId.'&amp;action=items&amp;pubState='.$pubState.'&amp;orderBy='.$key.'">'.$one[1].'</a>';
				}
				if ($key < count($orderByPossibilities) - 1) {
					$editBox .= ' - ';
				}
			}
			$editBox .= ')</p><ul>';
      foreach ($allItems as $item) {
        $editBox .= $item['itemId'].': <a href="item.php?itemId='.$item['itemId'].'">';
        $editBox .= ($item['handle'] != '') ? $item['handle'] : 'no title';
        $editBox .= "</a><br>\n";
      }
      $editBox .= "</ul>\n";
    }
    else {
      $editBox = "\n<p><b>No such items found.</b></p>\n";
    }

    echo makeDisplayBox($editBox, "List");
  break;

  default:
    // Corresponds to the "general" tab

    if ($clearance['rights'][$typeId]) {
      // Type toolobox only available to users with some type rights
      $typeTools = array(
        array(
          'label' => 'new item',
          'href' => 'item.php?itemId=new&amp;typeId='.$typeId
        )
      );

      if ($clearance['rights'][$typeId] > 1) {
        // Tools limited to users with publishing rights
        if ($clearance['rights'][$typeId] < 3) {
          $limitList .= " && createdBy='".addslashes($clearance['userName'])."' && lastUpdateBy = '".addslashes($clearance['userName'])."'";
        } else {
          $limitList = '';
        }

        // Submitted items
        if ($subItemsArray = pcdb_select('SELECT itemId, handle FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.addslashes($typeId).'\' && pubState=1 '.addslashes($limitList).' ORDER BY lastUpdateOn DESC LIMIT 0,9')) {
          $typeTools[1] = array(
            'action' => 'item.php',
            'selectName' => 'itemId',
            'menu' => array(
              array(
                'label' => 'recent submissions',
                'value' => 0
              ),
              array(
                'label' => ' ',
                'value' => 0
              )
            )
          );
          // Populate submitted items menu
          for ($i=0;$i<count($subItemsArray);$i++) {
            $typeTools[1]['menu'][$i+2] = array(
              'label' => ($subItemsArray[$i]['handle'] != '') ? $subItemsArray[$i]['handle'] : 'no title',
              'value' => $subItemsArray[$i]['itemId']
            );
          }
          $typeTools[2] = array(
            'label' => 'all submitted items',
            'href' => 'type.php?action=items&amp;pubState=1&amp;typeId='.$typeId
          );
        }
        else {
          // There aren't any such items
          $typeTools[1] = array (
            'label' => 'no recent submissions'
          );
        }
        // End submitted items

        // Published items
        $countPublished = pcdb_select('SELECT COUNT(itemId) AS published FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.addslashes($typeId).'\' && pubState=5'.$limitList);
        if ($countPublished[0]['published'] > 0) {
          $typeTools[3] = array(
            'label' => 'published items',
            'href' => 'type.php?action=items&amp;pubState=5&amp;typeId='.$typeId
          );
        }
        else {
          $typeTools[3] = array(
            'label' => 'no published items'
          );
        }
        // End published items

        // Archived items
        $countArchived = pcdb_select('SELECT COUNT(itemId) AS archived FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.addslashes($typeId).'\' && pubState=8'.$limitList);
        if ($countArchived[0]['archived'] > 0) {
          $typeTools[4] = array(
            'label' => 'archived items',
            'href' => 'type.php?action=items&amp;pubState=8&amp;typeId='.$typeId
          );
        }
        else {
          $typeTools[4] = array(
            'label' => 'no archived items'
          );
        }
        // End archived items
      }
      // End of tools limited to users with publishing rights
      else {
        // Tools for users with only submission rights
        if ($subItemsArray = pcdb_select('SELECT itemId, handle FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE typeId=\''.addslashes($typeId).'\' && pubState=1 && createdBy=\''.addslashes($clearance['userName'])."' && lastUpdateBy='".addslashes($clearance['userName'])."' ORDER BY lastUpdateOn DESC LIMIT 0,9")) {
          $typeTools[1] = array(
            'action' => 'item.php',
            'selectName' => 'itemId',
            'menu' => array(
              array(
                'label' => 'your recent submissions',
                'value' => 0
              ),
              array(
                'label' => ' ',
                'value' => 0
              )
            )
          );
          // Populate submitted items menu
          for ($i=0;$i<count($subItemsArray);$i++) {
            $typeTools[1]['menu'][$i+2] = array(
              'label' => $subItemsArray[$i]['handle'],
              'value' => $subItemsArray[$i]['itemId']
            );
          }
          $typeTools[2] = array(
            'label' => 'all submitted items',
            'href' => 'type.php?action=items&amp;typeId='.$typeId
          );
        }
        else {
          $typeTools[1] = array(
            'label' => 'no submitted items'
          );
        }
      }
      // End of tools limited to users with only submission rights

      $generalDisplay = "\n<p><b>Type elements toolbox</b></p>\n".displayNavArray($typeTools);
    }
    // End of type toolbox only available to type users

    if ($clearance['isModuleMgr'][$module['moduleId']]) {
			$typeParentsArr = _pcGetParentTree($typeId);
			$allTypeChars = array();
			for ($i=count($typeParentsArr)-1;$i>=0;$i--) {
				$allTypeChars = array_merge(pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'characteristics` WHERE typeId=\''.addslashes($typeParentsArr[$i]).'\' ORDER BY sequence'), $allTypeChars);
			}
      if (count($allTypeChars) == 0) {
        $generalDisplay .= "\n<p>There are no characteristics defined in this type</p>\n";
      } else {
        $generalDisplay .= '
<p><b><br>Type characteristics</b></p>
<table border="0" cellpadding="1" cellspacing="1">
	<tr bgcolor="#CCCCCC">
		<th>#</th>
		<th>id</th>
		<th>label</th>
		<th>format</th>
';
				if ($type['inherit_from']) {
					$generalDisplay .= '
		<th>inherited from</th>
';
				}
				$generalDisplay .= '
	</tr>
';
        $listBinary = false;
        foreach ($allTypeChars as $char) {
          if ($listBinary) {
            $elementColor = "CCCCCC";
          } else {
            $elementColor = "FFFFFF";
          }
          $listBinary = !$listBinary;
          if ($char['defining'] == 1) {
            $makeBold = "<b>&nbsp;";
            $makeUnBold = "&nbsp;</b>";
          } else {
            $makeBold = "&nbsp;";
            $makeUnBold = "&nbsp;";
          }
          $generalDisplay .= '
	<tr bgcolor="#'.$elementColor.'">
		<td>'.$makeBold.$char['charId'].$makeUnBold.'</td>
		<td>'.$makeBold.$char['columnId'].$makeUnBold.'</td>
		<td>'.$makeBold.$char['label'].$makeUnBold.'</td>
		<td>'.$makeBold.$charFormats[$char['format']].$makeUnBold.'</td>
';
					if ($type['inherit_from']) {
						$generalDisplay .= '
		<td>';
						if ($char['typeId'] != $typeId) {
							$generalDisplay .= $char['typeId'];
						}
						$generalDisplay .= '</td>
';
					}
					$generalDisplay .= '
	</tr>
';
        }
        $generalDisplay .= '
</table>
';
      }
      // End of building $generalDisplay
    }
    // End of list of char building (only visible to module managers)

    echo makeDisplayBox($generalDisplay, "General");
  break;

}
// End switch $action

echo pageFooter();

?>
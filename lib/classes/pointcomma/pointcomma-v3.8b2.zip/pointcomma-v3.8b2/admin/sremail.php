<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcuserlib.inc.php');
include('lib/adminlib.inc.php');

echo pageHeader('Email verification');

if (empty($password)) {
  // Display form
?>
<form name="activate" action="sremail.php" method="post">
<table border="0">
<tr><td>User name:</td><td><input type="hidden" name="u" value="<?php echo $u; ?>"><?php echo $u; ?></td></tr>
<input type="hidden" name="t" value="<?php echo $t; ?>">
<tr><td>Password:</td><td><input type="password" name="password"></td></tr>
<tr><td></td><td><input type="submit" value="verify my email"></td></tr>
</table>
</form>
<?php
} else {
  // Do verification
  if (pcConfirmUserEmail('admin', $u, $password, $t)) {
    echo '<p>&nbsp;<br><b>Success</b><br>Your email has been verified. You may now proceed to <a href="./">the login page</a>.<br>&nbsp;</p>';
  } else {
    echo '<p>&nbsp;<br><b>Error</b><br>Email verification failed, sorry: '.$pcCreateUserLog.'.<br>&nbsp;</p>';
  }
}

echo pageFooter();
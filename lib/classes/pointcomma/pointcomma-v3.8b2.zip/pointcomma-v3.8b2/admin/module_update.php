<?php
// PointComma admin site module_update.php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcinput.php');
include('lib/adminlib.inc.php');
// The admin interface HTML generation libraries

$clearance = unserialize(CLEARANCE);
if ((!$clearance['isFrameworkMgr'])&&(!$clearance['isModuleMgr'][$moduleId])) {
  //check user is framework manager or module manager or not
  echo makeLoginForm('notmodulemanager','module.php', $_POST);
  // show login form, makeLoginForm function can be seen in htmllib.inc.php
  exit();
}
// if user is framework manager or module manager

// Initialize variables
$action = pcDefaultValue('string', '', 'action', 'P');
$moduleName = pcDefaultValue('string', '', 'moduleName', 'P');
$moduleIdent = pcDefaultValue('string', '', 'moduleIdent', 'P');
$moduleDescription = pcDefaultValue('string', '', 'moduleDescription', 'P');
$moduleId = pcDefaultValue('pcStrId', '', 'moduleId', 'P');
$sure = pcDefaultValue('bool', false, 'sure', 'P');

switch ($action) {
  case 'new':
	//Help the user:
	$moduleId = strtolower(trim($moduleIdent));

	//empty moduleIdentifier provided
	if ($moduleId === '') {
		trigger_error('You provide an empty module name, cannot create module',ERROR);
		header("Location:module.php?action=new&modescr=".urlencode($moduleDescription)."&modename=".urlencode($moduleName));
		exit();
	}	// test if that kind of id is allowed
	elseif (!preg_match('/^[a-z][a-z0-9_]{0,6}[a-z0-9]$/', $moduleId)) {
			trigger_error('You provided a bad identifier: it may contain only alphanumeric characters and the underscore; it must contain between 2 and 8 characters; it must start with a letter; it must end with a letter or a number. Cannot create module.',ERROR);
			header("Location:module.php?action=new&modescr=".urlencode($moduleDescription)."&modename=".urlencode($moduleName)."&moduleIdent=".urlencode($moduleId));
			exit();
	}

		//Test if a module with that identifier already exist
		$boolModuleExist = pcdb_select('SELECT moduleId FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleID LIKE \''.addslashes($moduleId).'\'');

		if (isset($boolModuleExist[0]) and ($boolModuleExist[0]['moduleId']==$moduleId)) {
			trigger_error('A module with that identifier already exist, you cannot create a new one, please change the identifier',ERROR);
			header("Location:module.php?action=new&modescr=".urlencode($moduleDescription)."&modename=".urlencode($moduleName)."&moduleIdent=".urlencode($moduleId));
			exit();
		}

  //update for new added modules
    $InsertedRow = pcdb_insert('INSERT INTO `'.addslashes($pcConfig['dbPrefix']).'modules` SET moduleId=\''.addslashes($moduleId).'\', label=\''.addslashes($moduleName).'\', description=\''.addslashes($moduleDescription).'\'');
		// there is a bug in the mysql framework when the table has no autoincremental index it returned false (now it return 0)
		if ($InsertedRow==0) {
			setGlobal('lastAdminUpdateOn', time());
			setGlobal('lastAdminUpdateBy', $clearance['userName']);
      header("location:module.php?moduleId=$moduleId&pcAdminMsg=modulesaved");
      exit();
    } else {
      //if $moduleAddnewQuery=false then show error
      header("Location:module.php?action='new'&modescr='".urlencode($moduleDescription)."'&modename='".urlencode($moduleName)."'&pcAdminMsg=errmodulenotsaved");
      exit();
    }
  break;

  case 'edit' :
  //update edited modules
    $moduleUpdateQuery=pcdb_query('UPDATE `'.addslashes($pcConfig['dbPrefix']).'modules` SET label=\''.addslashes($moduleName).'\', description=\''.addslashes($moduleDescription).'\' WHERE moduleId=\''.addslashes($moduleId).'\'');
    //update correspondent module data using moduleId with new data from module_edit.php
    if (!$moduleUpdateQuery) {
    //if $moduleQuery=false then show error
      header("Location:module.php?action='edit'&moduleId=$moduleId&pcAdminMsg=errmodulenotsaved");
      exit();
    }
    else {
    //if success
    header("Location:module.php?moduleId=$moduleId&pcAdminMsg=modulesaved");
    exit();
    }
  break;

  case 'del' :
    if ($sure == 1) {
	    //update deleted modules
      $moduleDeleteQuery=pcdb_query('DELETE FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId=\''.addslashes($moduleId).'\'');
      //delete correspondent module data using moduleId provided
      if (!$moduleDeleteQuery) {
      //if $moduleDeleteQuery=false then show error
        header("Location:module.php?moduleId=$moduleId&pcAdminMsg=errmodulenotdeleted");
        exit();
      } else {
      	// if successfully delete Modules of $moduleId then delete all the relevant tabels' records left
        if ($rolesQuery=pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId=\''.addslashes($moduleId).'\'')) {
          //select all roles from roles per moduleId
          foreach($rolesQuery as $allRoles) {
            deleteRole($allRoles['roleId']);
            // delete every role in Roles and Authorizationa and Assignments where roleId=$allRoles
          }
        }
        if ($typesQuery=pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId=\''.addslashes($moduleId).'\'')) {
          //select all types from types per moduleId
          foreach ($typesQuery as $allTypes) {
            //here call the function of deleting the Xvals and Characteristics andUnits and Items per type using argument=$allTypes['typeId']
            deleteType($allTypes['typeId']);
          }
        }
        //if delete module successfully show message about that and return to index page and re-generate user correspondent clearance
        setGlobal('lastAdminUpdateOn', time());
        setGlobal('lastAdminUpdateBy', $clearance['userName']);
        header('Location:index.php?pcAdminMsg=moduledeleted');
        exit();
      }
    } else {
	    header("Location:module.php?moduleId=".$moduleId."&pcAdminMsg=abort");
	    exit();
    }
  break;
}


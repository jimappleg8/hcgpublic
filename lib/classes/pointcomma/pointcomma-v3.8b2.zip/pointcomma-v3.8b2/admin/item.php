<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pceditor.php');
include("lib/adminlib.inc.php");


$pcAdminMsg = pcDefaultValue('string', '', 'pcAdminMsg', 'G');
$typeId = pcDefaultValue('pcTypeId', '', 'typeId', 'G');
$itemId = pcDefaultValue('pcId', 0, 'itemId', 'G');

if (empty($itemId)) {
  header('Location: ./?pcAdminMsg=erritemnotspecified');
  exit();
}

$clearance = unserialize(CLEARANCE);
if (!$clearance['userName']) {
  // User must be logged in
  trigger_error('notloggedin',ERROR);
  echo makeLoginForm('notloggedin', "item.php?typeId=$typeId&amp;itemId=$itemId");
  exit();
}

// Let's try to identify the item, its type and its module
if ($itemId == 'new') {
  // New item
  if (!$clearance['rights'][$typeId]) {
		trigger_error('authtoolow',ERROR);
    // User must have some rights to this type
    echo makeLoginForm('authtoolow');
    exit();
  }

  $typeQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId LIKE \''.addslashes($typeId).'\'');
  $type = $typeQuery[0];

  $moduleQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($type['moduleId']).'\'');
  $module = $moduleQuery[0];
} else {
  // Existing item
  if (!$itemQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'items` WHERE itemId='.addslashes($itemId))) {
    header('Location: ./?pcAdminMsg=errwrongitem');
    exit();
  }
  $item = $itemQuery[0];

  if (!$clearance['rights'][$item['typeId']]) {
    // User must have some rights to this type
    echo makeLoginForm('authtoolow');
    exit();
  }
  if ($clearance['rights'][$item['typeId']] < 2 && ($clearance['userName'] != $item['createdBy'] || $clearance['userName'] != $item['lastUpdateBy'] || $item['pubState'] > 1)) {
    // Submitters may only access their own submissions, while they are still in submitted state
    // TODO create a different error message for the different errors
    echo makeLoginForm('authtoolow');
    exit();
  }

  assert("\$pcConfig['debug']['errorLevel'] > pcDebugInfo(get_defined_vars(),'pcItemManagement', 'Get the current Item',0)");

  // Create $fullItem which contains all item's data, as formatted by the getItem function
  $fullItem = getItem($item['itemId'], $item['pubState']);

  if (!$typeQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId LIKE \''.addslashes($item['typeId']).'\'')) {
    header('Location: ./?pcAdminMsg=errwrongtype');
    exit();
  }
  $type = $typeQuery[0];

  if (!$moduleQuery = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` WHERE moduleId LIKE \''.addslashes($type['moduleId']).'\'')) {
    header('Location: ./?pcAdminMsg=errwrongmodule');
    exit();
  }
  $module = $moduleQuery[0];
}
// End identification

// Limit the publishing rights of submitters
if ($clearance['rights'][$type['typeId']] > 1) {
  $maxPubState = 10;
  $saveItemModifier = 'true';
} else {
  $maxPubState = 1;
}

echo pageHeader("Edit item", 0, $module['moduleId'], $module['label'], $type['typeId'], $type['label']);
pcErrorDisplay(WARNING);
// Define the current item's characteristics
$fullType = genTypeArray($type['typeId']);

// Determine if the javascript for RTE must be shown or not
if (is_array($fullType['chars'])) {
    is_RTE($fullType['chars']);
}
// end of determination

//display javascript depending on is_RTE result
echo makeEditPageJS();

// Display top tools
echo '<form name="editform" action="item_update.php" ENCTYPE="multipart/form-data" method="post">';

if (!isset($fullItem)) {$fullItem=false;} // init missing vars

if ($clearance['rights'][$type['typeId']] > 1) {
  // Offer publication state menu only to users who have sufficient rights
  $pubStateMenu = array(
    array(
      'value' => 1,
      'label' => 'Submission',
      'isSelected' => ($fullItem['pubState'] == 1)
    ),
    array(
      'value' => 5,
      'label' => 'Published',
      'isSelected' => ($fullItem['pubState'] == 5)
    ),
    array(
      'value' => 8,
      'label' => 'Archive',
      'isSelected' => ($fullItem['pubState'] == 8)
    )
  );
  echo makeInputField("State", 'pubState', 'menu', $pubStateMenu);
}
else {
  // Provide an indication that the user is only submitting the item
  echo "<p>You are submitting an item.</p>";
  echo makeInputField('', 'pubState', 'hidden', 1);
}

// Pass existing item properties
echo makeInputField(0, 'itemId', 'hidden', $itemId);
echo makeInputField(0, 'typeId', 'hidden', $type['typeId']);

// Loop for each char
if (is_array($fullType['chars'])) {
		foreach ($fullType['chars'] as $oneChar) {
			//if the format is a text editor give the raw data as value	
			if ($oneChar['format'] == 't') {
				echo makeCharEditor($oneChar, $fullItem[$oneChar['key'].'_raw']);
			} else {
				echo makeCharEditor($oneChar, $fullItem[$oneChar['key']]);
			}
		}
  // End for each char
}
// End if chars are present for this item's type

echo makeEditPageFooter();

// Display toolbar (save, delete)
echo makeInputField('', 'deleteItemCheck', 'hidden', '0');
echo '<p class="itemToolbox"><input type="button" value="save item" onclick="saveItem()" /><input type="button" value="save item and close" onclick="closeItem('.$saveItemModifier.')" /> &nbsp; <input type="button" value="delete item" onclick="deleteItem()" /></p>';

// Close form and display foot

echo "\n\n</form>\n\n";

echo pageFooter();

?>
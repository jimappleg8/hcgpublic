<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require("lib/htmllib.inc.php");

if (!pcIsLogged()) {
  echo makeLoginForm();
  exit();
}

$clearance = unserialize(CLEARANCE);

$pcAdminMsg = pcDefaultValue('string', '', 'pcAdminMsg', 'G');

echo pageHeader("PointComma administration: main menu");
pcErrorDisplay(WARNING);

$isDisplayAdmin = false;
if ($clearance['isSupervisor']) {
  $navArray = array(
    array(
      'label' => 'Create new user',
      'href' => 'user.php?userId=new&amp;action=new'
    )
  );
  $isDisplayAdmin = true;
}

if ($clearance['isFrameworkMgr']) {
  $navArray[2] = array(
    'label' => "New module",
    'href' => "module.php?action=new"
  );
  $isDisplayAdmin = true;
}
if ($isDisplayAdmin) {
  echo makeSimpleNavBox('Site management', $navArray);
}

foreach($clearance['rights'] as $oneType=>$right) {
  // Obtain a list of all modules that contain types that the current user can instanciate
  if ($right) {
    if ($typeQuery = pcdb_select('SELECT moduleId FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE typeId=\''.addslashes($oneType).'\'')) {
      foreach ($typeQuery as $oneTypesModule) {
        $allModulesRights[$oneTypesModule['moduleId']] = true;
      }
    }
  }
}

// Now make a list of all modules and generate a box for each one of them
if (!$allModules = pcdb_select('SELECT * FROM `'.addslashes($pcConfig['dbPrefix']).'modules` ORDER BY label')) {
  $allModules = array();
}
//display module
foreach ($allModules as $oneModule) {
  $moduleId = $oneModule['moduleId'];
  if ((isset($clearance['isModuleMgr'][$moduleId]) and $clearance['isModuleMgr'][$moduleId]) || $clearance['isModuleSupervisor'][$moduleId] || $allModulesRights[$moduleId]) {
		
		// The box is made only if user is module manager or supervisor for the current module, or may create items of a type of this module
    $countTypes = pcdb_select('SELECT count(typeId) as numTypes FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
    $numTypes = $countTypes[0]['numTypes'];
    $countItems = pcdb_select('SELECT count(itemId) as numItems FROM `'.addslashes($pcConfig['dbPrefix']).'types`, `'.addslashes($pcConfig['dbPrefix']).'items` WHERE `'.addslashes($pcConfig['dbPrefix']).'items`.typeId=`'.addslashes($pcConfig['dbPrefix']).'types`.typeId && `'.addslashes($pcConfig['dbPrefix']).'types`.moduleId LIKE \''.addslashes($moduleId).'\'');
    $numItems = $countItems[0]['numItems'];
    $countRoles = pcdb_select('SELECT count(roleId) as numRoles FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId LIKE \''.addslashes($moduleId).'\'');
    $numRoles = $countRoles[0]['numRoles'];

    if ($clearance['isModuleMgr'][$moduleId]) {
      // Module manager may create types
      $navArray[0] = array(
        'label' => 'new type',
        'href' => "type.php?typeId=new&moduleId=$moduleId"
      );
    }
    // End of limited display to only module managers

    // Anyone who may see the module may see some of the module's types
    $navArray[1] = array(
      'action' => 'type.php',
      'selectName' => 'typeId',
      'menu' => array(
        array(
          'label' => "module's types",
          'value' => '0'
        ),
        array(
          'label' => '',
          'value' => '0'
        )
      )
    );
    $allTypes = pcdb_select('SELECT typeId, label FROM `'.addslashes($pcConfig['dbPrefix']).'types` WHERE moduleId LIKE \''.addslashes($oneModule['moduleId']).'\'');
    $moduleHasTypes = false;
    if ($allTypes) {
      for($i=0;$i<count($allTypes);$i++) {
        if ($clearance['rights'][$allTypes[$i]['typeId']]) {
          // Only those who have the proper rights may see the types
          $navArray[1]['menu'][$i+2]['label'] = $allTypes[$i]['label'];
          $navArray[1]['menu'][$i+2]['value'] = $allTypes[$i]['typeId'];
          $moduleHasTypes = true;
        }
      }
    }
    if (!$moduleHasTypes) {
      $navArray[1]['menu'] = false;
      $navArray[1]['label'] = "no types";
    }


    if ($clearance['isModuleSupervisor'][$moduleId]) {
      // Module supervisor may see and create roles
      $navArray[2] = array(
        'label' => 'new role',
        'href' => "role.php?roleId=new&moduleId=$moduleId"
      );
      $navArray[3] = array(
        'action' => 'role.php',
        'selectName' => 'roleId',
        'menu' => array(
          array(
            'label' => "Module's roles",
            'value' => '0'
          ),
          array(
            'label' => '',
            'value' => '0'
          )
        )
      );
      $allRoles = pcdb_select('SELECT roleId, label FROM `'.addslashes($pcConfig['dbPrefix']).'roles` WHERE moduleId LIKE \''.addslashes($oneModule['moduleId']).'\'');
      // Generate list of roles for the type
      if ($allRoles) {
        for($i=0;$i<count($allRoles);$i++) {
          $navArray[3]['menu'][$i+2]['label'] = $allRoles[$i]['label'];
          $navArray[3]['menu'][$i+2]['value'] = $allRoles[$i]['roleId'];
        }
      } else {
        $navArray[3]['menu'] = false;
        $navArray[3]['label'] = "no roles";
      }
    }
    // End of limited display to only module supervisors


    // Now make the nav box for this menu
    echo makeNavBox('module menu', stripslashes($oneModule['label']), "module.php?moduleId=$moduleId", stripslashes($oneModule['description']), "$numTypes types, $numItems items, $numRoles roles", $navArray);
  }
  // End limited display to only people who may see the module
}
// End for each module

echo pageFooter();
?>
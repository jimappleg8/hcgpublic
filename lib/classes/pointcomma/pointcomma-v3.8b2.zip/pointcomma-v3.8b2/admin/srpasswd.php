<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcuserlib.inc.php');
include('lib/adminlib.inc.php');

echo pageHeader('Forgotten password');

if (isset($u) && isset($password1) && ($password1 == $password2)) {
  // Reset password
  if (pcConfirmPassword('admin', $u, $password1, $t)) {
    echo '<p>&nbsp;<br><b>Success</b><br>You have successfully reset your password, please proceed to the <a href="./">login page</a>.<br>&nbsp;</p>';
  } else {
    echo '<p>&nbsp;<br><b>Error</b><br>Reset failed, sorry: '.$pcCreateUserLog.'.<br>&nbsp;</p>';
  }
} else if (isset($u)) {
  // Display password reset form
  if (isset($password1)) {
    ?><p>&nbsp;<br><b>Error</b>: the two entries of the password do not match, please try again.<br>&nbsp;</p><?php
  }
?>
<form name="create" action="srpasswd.php" method="post">
<table border="0">
<tr><td>User name:</td><td><?php echo $u; ?><input type="hidden" name="u" value="<?php echo $u; ?>"><input type="hidden" name="t" value="<?php echo $t; ?>"></td></tr>
<tr><td>New password:</td><td><input type="password" name="password1"></td></tr>
<tr><td>Type it again:</td><td><input type="password" name="password2"></td></tr>
<tr><td></td><td><input type="submit" value="reset my password"></td></tr>
</table>
</form>
<?php
} else if (isset($searchUser)) {
  // Send password reset invitation by email
  if (pcForgottenPassword('admin', $searchUser)) {
    echo '<p>&nbsp;<br><b>Success</b><br>The procedure to reset your password was sent to you by email.<br>&nbsp;</p>';
  } else {
    echo '<p>&nbsp;<br><b>Error</b><br>Lookup failed, sorry: '.$pcCreateUserLog.'.<br>&nbsp;</p>';
  }
} else {
  // Display lookup request form
?>
<form name="create" action="srpasswd.php" method="post">
<table border="0">
<tr><td colspan="2">Enter your user name or your email address:</td></tr>
<tr><td></td><td><input type="text" name="searchUser"></td></tr>
<tr><td></td><td><input type="submit" value="find my password"></td></tr>
</table>
</form>
<?php
}

echo pageFooter();
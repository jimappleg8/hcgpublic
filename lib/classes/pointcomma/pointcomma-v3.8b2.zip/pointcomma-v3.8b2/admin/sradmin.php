<?php
$pcDynamicPage = true;
require('../config.inc.php');
require($pcConfig['includePath'].'pcEngine.php');
require($pcConfig['includePath'].$pcConfig['functionFolder'].'pcuserlib.inc.php');
include('lib/adminlib.inc.php');

$clearance = unserialize(CLEARANCE);
$canSeeUsers = $clearance['isSupervisor'];
foreach ($clearance['isModuleSupervisor'] as $oneModuleSup) {
  if ($oneModuleSup) {
    $canSeeUsers = true;
  }
}
if (!$canSeeUsers) {
  echo makeLoginForm('authtoolow', 'sradmin.php?u='.$u);
  exit();
}

echo pageHeader('Activate user');

if (isset($u)) {
  // Display form
  $user = getUser($u, true);
  if (!$user) {
    ?><p><b>Error: user not found</b></p><?php
    echo pageFooter();
    exit();
  }
  $status = substr('000'.decbin($user['status']), -3, 3);
  $statusFrozen = substr($status, 0, 1);
  $statusAdminOK = substr($status, 1, 1);
  $statusEmailOK = substr($status, 2, 1);
?>
<form name="admin" action="sradmin.php" method="post">
<table border="0">
<tr><td>User:</td><td><input type="hidden" name="userName" value="<?php echo $u; ?>"><?php echo $u; ?></td</tr>
<tr><td>Name:</td><td><?php echo $user['firstName'].' '.$user['lastName']; ?></td></tr>
<tr><td>Created with:</td><td><?php echo $user['createdBy']; ?></td></tr>
<tr><td>Created on:</td><td><?php echo $user['createdOn']; ?></td></tr>
<tr><td>Email:</td><td><?php echo (($statusEmailOK)?$user['email'].'<br>verified on '.$user['activeSince']:$user['newEMail'].'<br>not yet verified');?></td></tr>
<tr><td>Action:</td><td><input type="radio" name="action" value="activate">activate<br>
  <input type="radio" name="action" value="delete">delete</td></tr>
<tr><td></td><td><input type="submit"></td></tr>
</table>
</form>
<?php
} else if (isset($userName) && ($action=='delete' || $action == 'activate')) {
  // Do activation
  if ($action == 'activate') {
    if (pcActivateUser('admin', $userName)) {
      echo '<p>It worked: '.$pcCreateUserLog.'</p>';
    } else {
      echo '<p>It failed, sorry: '.$pcCreateUserLog.'.</p>';
    }
  } else if ($action == 'delete') {
    if (pcDeleteNewUser($userName)) {
      echo '<p>It worked: '.$pcCreateUserLog.'</p>';
    } else {
      echo '<p>It failed, sorry: '.$pcCreateUserLog.'.</p>';
    }
  }
}

echo pageFooter();
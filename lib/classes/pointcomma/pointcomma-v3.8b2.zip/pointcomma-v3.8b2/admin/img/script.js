function deleteUnit(del) {
  if (arguments[1]) {
    prefix = arguments[1];
  } else {
    prefix = 'units';
  }
  document.editform.elements[prefix+'[' + del + '][delete]'].value = 1;
  document.editform.action.value = 'modif';
  saveItem();
}

function checkSaved() {
  if (document.editform.issaved.value != 1) {
    event.returnValue = 'Are you sure you want to quit before saving your changes? By clicking OK, the changes you made will be lost and unrecoverable. If you click Cancel, you have the chance to save those modifications.';
  }
}

function setSave() {
  document.editform.issaved.value = 1;
}

function unsetSave() {
  document.editform.issaved.value = 0;
}

function addAUnit(u) {
  document.editform.action.value = 'addUnit';
  document.editform.addUnit.value = u;
  saveItem();
}

function closeItem() {
  document.editform.action.value = 'close';
  pubval = document.editform.pubState.value;
  pubtrans = new Array();
  pubtrans[1] = 'Are you sure you want to save this item as a submission?\nIt will NOT BE VISIBLE on the web site.';
  pubtrans[8] = 'Are you sure you want to save this item as an archive?\nIt will NOT BE VISIBLE on the web site.';
  if (pubval != '5' && arguments[0]) { // deals with publication state
    if (confirm(pubtrans[pubval])) {
      document.editform.issaved.value = 1;
      saveItem();
    }
  } else {
    saveItem();
  }
}

function deleteItem() {
  if (confirm('Are you sure you want to\nDELETE THIS ITEM?')) {
    document.editform.issaved.value = 1;
    document.editform.action.value = 'del';
    document.editform.submit();
  }
}

function moveUnits(mvup, mvdown) {
  if (arguments[2]) {
    prefix = arguments[2];
  } else {
    prefix = 'units';
  }
  document.editform.elements[prefix+'[' + mvup + '][moveUp]'].value = 1;
  document.editform.elements[prefix+'[' + mvdown + '][moveDown]'].value = 1;
  document.editform.action.value = 'modif';
  saveItem();
}

function saveItem() {
  document.editform.issaved.value = 1;
  if (document.canedithtml) {
    updateRTEs();
  }
  document.editform.submit();
}

function validList(sequence) {
  document.editform.elements[allListMenus[sequence]].value = '';
  for(i=0;i<document.editform.elements['menulist['+sequence+']'].options.length;i++) {
    document.editform.elements[allListMenus[sequence]].value += document.editform.elements['menulist['+sequence+']'].options[i].text;
    if (i<(document.editform.elements['menulist['+sequence+']'].options.length-1)) {
      document.editform.elements[allListMenus[sequence]].value += ';';
    }
  }
  return false;
}

function addListElement(sequence) {
  if (document.editform.elements['menuadditem['+sequence+']'].value.indexOf(';') > -1) {
    alert ('The text can not contain semi-columns.\\nPlease correct the problem.');
  } else {
    newOption = new Option(document.editform.elements['menuadditem['+sequence+']'].value);
    document.editform.elements['menulist['+sequence+']'].options[document.editform.elements['menulist['+sequence+']'].options.length] = newOption;
    document.editform.elements['menuadditem['+sequence+']'].value = '';
    document.editform.elements['menuadditem['+sequence+']'].focus();
  }
  validList(sequence);
  return false;
}

function deleteListElement(sequence) {
  document.editform.elements['menulist['+sequence+']'].options[document.editform.elements['menulist['+sequence+']'].selectedIndex] = null;
  validList(sequence);
}

function moveListElementDown(sequence) {
  if ((document.editform.elements['menulist['+sequence+']'].selectedIndex+1)<document.editform.elements['menulist['+sequence+']'].options.length) {
    document.upval = document.editform.elements['menulist['+sequence+']'].options[document.editform.elements['menulist['+sequence+']'].selectedIndex].text;
    document.downval = document.editform.elements['menulist['+sequence+']'].options[(document.editform.elements['menulist['+sequence+']'].selectedIndex+1)].text;
    document.editform.elements['menulist['+sequence+']'].options[document.editform.elements['menulist['+sequence+']'].selectedIndex].text = document.downval;
    document.editform.elements['menulist['+sequence+']'].options[(document.editform.elements['menulist['+sequence+']'].selectedIndex+1)].text = document.upval;
    document.editform.elements['menulist['+sequence+']'].options[(document.editform.elements['menulist['+sequence+']'].selectedIndex+1)].selected = true;
  }
  validList(sequence);
}

function moveListElementUp(sequence) {
  if ((document.editform.elements['menulist['+sequence+']'].selectedIndex-1)>=0) {
    document.downval = document.editform.elements['menulist['+sequence+']'].options[document.editform.elements['menulist['+sequence+']'].selectedIndex].text;
    document.upval = document.editform.elements['menulist['+sequence+']'].options[(document.editform.elements['menulist['+sequence+']'].selectedIndex-1)].text;
    document.editform.elements['menulist['+sequence+']'].options[document.editform.elements['menulist['+sequence+']'].selectedIndex].text = document.upval;
    document.editform.elements['menulist['+sequence+']'].options[(document.editform.elements['menulist['+sequence+']'].selectedIndex-1)].text = document.downval;
    document.editform.elements['menulist['+sequence+']'].options[(document.editform.elements['menulist['+sequence+']'].selectedIndex-1)].selected = true;
  }
  validList(sequence);
}

function populateList(sequence, oldString, fieldName) {
  if (oldString != '') {
    oldList = new Array();
    oldList = oldString.split(';');
    for(i=0;i<oldList.length;i++) {
      newOption = new Option(oldList[i]);
      document.editform.elements['menulist['+sequence+']'].options[i] = newOption;
    }
  }
  allListMenus[sequence] = fieldName;
}

allListMenus = new Array(); // Menu items editors sorted by $numMenus

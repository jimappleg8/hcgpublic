
// Javascript lib for the Debugging Package
// Set of javascript function to filter the information displayed on the debug popup

//set the filter to default but the current filter

function reset($currentFilter) {
	
	if ($currentFilter != 'searchBox')
		document.getElementById('searchBox').value = '';
	
	if ($currentFilter != 'errorLevelBox')
		document.getElementById('errorLevelBox').selectedIndex = 'None'; 
	
	if ($currentFilter != 'packageBox')
		document.getElementById('packageBox').selectedIndex = 'None';
}

//modify the display according to the current filter
function filterDisplay() {
	var displayedElement = 0;
	for (i=0; i<document.arrayDisplayedLine.length; i++) {
		if (document.arrayDisplayedLine[i]) {
			displayedElement++;
			
			//recolor the row
				if (i % 2 == 0) {
					$trclass = 'odd';
				} 
				else {
					$trclass = 'unodd';		
				}
			show_obj('Debug' + i,$trclass);
			
		} else {
			hide_obj('Debug' + i);
		}
	}
}

//Filter function for package filtering
function filterPackage($value) {
	for (i=0; i < document.arrayDebug.length; i++) {
		if  ((document.arrayDebug[i][0] == $value) || ($value == 'None'))  {
			document.arrayDisplayedLine[i] = true;
		} else {
			document.arrayDisplayedLine[i]= false;
		}
	}
	filterDisplay();
	reset('packageBox');
}

//Filter function for error filtering
function filterError($value) {
	for (i=0; i < document.arrayDebug.length; i++) {
		if  ((document.arrayDebug[i][1] == $value) || ($value == 'None'))  {
			document.arrayDisplayedLine[i] = true;
		} else {
			document.arrayDisplayedLine[i]= false;
		}
	}
	filterDisplay();
	reset('errorLevelBox');
}

//filter function for string search filtering
function Search($value) {
	for (i=0; i < document.arrayDebug.length; i++) {
		if  ((document.arrayDebug[i][2].indexOf($value) != -1) || (document.arrayDebug[i][3].indexOf($value) != -1)) {
			document.arrayDisplayedLine[i] = true;
		} else {
			document.arrayDisplayedLine[i]= false;
		}
	}
	filterDisplay();
	reset('searchBox');
}

// Function to display information of array debug info filtered by the arrayDisplayedLine if boolfilter is true
function displayDebugInfo($arrayDebugInfo) {
var i;
//no filter display all information

	for (i=0; i<$arrayDebugInfo.length; i++) {
		//display row of different colors
		if (i % 2 == 0) {
			$trclass = 'odd';
		} 
		else {
			$trclass = 'unodd';		
		}
		document.write('<div id="Debug' + i + '" class="'+ $trclass + '">');
		vis[i]='hide';
		document.write('<table border=0 width=100% cellspacing=0 cellpadding=0>');
		document.write('<tr><td width=200px>');
		document.write('<strong><i>' + $arrayDebugInfo[i][1] + '</i></strong> - ' + $arrayDebugInfo[i][7]);
		document.write("</td><td width=200px>\n");
		document.write($arrayDebugInfo[i][0]);
		document.write("</td><td>\n");
	    if  ($arrayDebugInfo[i][3]) {
			document.write('<a href="javascript:swap_couche(\'' + i + '\', \'\');">');
			document.write($arrayDebugInfo[i][2]);
			document.write('</a>');
			document.write('<p  id="Layer' + i +'" style="display: none; margin-top: 1;">');
			document.write($arrayDebugInfo[i][3] + "\n</p>");
		}	else {
 			document.write($arrayDebugInfo[i][2]);
		}
		document.write("</td></tr>\n");
		document.write("<tr><td colspan=3>\n");
		vis[i + $arrayDebugInfo.length + 1]='hide';
		document.write('<a href="javascript:swap_couche(\'' + (i + $arrayDebugInfo.length + 1) + '\', \'\');">');
		document.write("File: " + $arrayDebugInfo[i][4] + " line:" + $arrayDebugInfo[i][5] + "\n");
		document.write('</a>');
		document.write('<p  id="Layer' + (i + $arrayDebugInfo.length + 1) +'" style="display: none; margin-top: 1;">');
		document.write($arrayDebugInfo[i][6] + "\n</p>");
		document.write("</td></tr>\n");
		document.write("<tr><td colspan=3>\n");
		document.write("</td></tr>\n");
		document.write("</table></div>");
		}
}

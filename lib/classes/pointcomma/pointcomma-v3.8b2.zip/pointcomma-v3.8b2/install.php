<html>
<head>
<title>PointComma install page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">
<?php
//the install.php is supposed to be runned under magic quotes off
if (get_magic_quotes_gpc()) {
   function stripslashes_deep($value)
   {
       $value = is_array($value) ?
                   array_map('stripslashes_deep', $value) :
                   stripslashes($value);

       return $value;
   }

   $_POST = array_map('stripslashes_deep', $_POST);
   $_GET = array_map('stripslashes_deep', $_GET);
   $_COOKIE = array_map('stripslashes_deep', $_COOKIE);
}

//disable assertions to avoid error with debugging functions by default DO NOT REMOVE IT !!!!!!
assert_options(ASSERT_ACTIVE, 0);

// Check if the sessions are supported on the hosting, if it s not the case exit
function_exists('session_start') or die("Session are not supported in this version of PHP, Please contact Your hosting provider");

$pcConfigTemplate = '<?php
$pcConfig = array(
    \'db\' => array(
        \'format\' => \'mysql\',
        // mysql only for now
        \'host\' => \'[dbhost]\',
        // database host, defaults to localhost, change if neccesary
        \'name\' => \'[dbname]\',
        // name of the database
        \'login\' => \'[dblogin]\',
        \'pass\' => \'[dbpass]\'
    ),
    \'mysqlSessions\' => false,
      // Are sessions mysql session or standard php session (mysql more secure)
    \'anonymousLogin\' => true,
      // Do you want to allow anonymous login
    \'dbPrefix\' => \'[dbprefix]\',
      // any string, to be added before all table names. May be empty.
    \'siteName\' => \'[sitename]\',
      // displayed in the admin interface (including a trailing slash)
    \'productionServer\' => \'[hostname]/\',
      // web address, like http://www.yourdomain.net/ (including a trailing slash)
    \'adminServer\' => \'[hostname]/admin/\',
      // web address, like http://www.yourdomain.net/admin/ (including a trailing slash)
    \'includePath\' => \'[includePath]\',
      //includePath = path to the framework root (including a trailing slash)
    \'wwwPath\' => \'[wwwPath]\',
      //wwwPath = Path to the root directory of the web site (containing images, styles... and config.inc.php !!!) (including a trailing slash)
    \'smartyPath\' => \'[includePath]classes/smarty/\',
      //smartyPath = Path that contains the smarty libs (root of Smarty.class.php) (including a trailing slash)
    \'classFolder\' => \'classes/\',
      //classFolder = folder in the framework path that contains classes (including a trailing slash)
    \'functionFolder\' => \'functions/\',
      //functionFolder = folder in the framework path that contains libs (including a trailing slash)
    \'adminEmail\' => \'[email]\',
       // Required to allow users to modify their password
    \'userSelfRegOpen\' => false,
       // Set to true to allow user self-creation at admin level
    \'userModeration\' => false,
       // Set to true to moderate user creation
    \'upload\' => array(
       // Here, you must specify values that allow uploading files from
       // the admin interface and viewing them from the front-end of the site
       // (including a trailing slash)
        \'dir\' => \'[pcUploadDir]\',
       // a fully qualified path will save you trouble. Include trailing /
        \'maxSize\' => 150000,
       // in bytes
        \'adminOffset\' => \'../\',
       // how to go from the admin interface to the site\'s front-end
       // (including a trailing slash)
        \'path\' => \'material/\'
    ),
       // Debug Options
    \'debug\' => array(
        \'active\' => false,
       // Actived or not the debugging procedure by default
        \'stackMaxSize\' => 20,
       // Number of debug message kept in the session
        \'errorLevel\' => 4
       // Error level displayed for the debugging stuff
    ),
    \'log\' => array(
        \'toFile\' => false,
       // true logs important messages to the file
        \'file\' => \'log/pclog.txt\',
       // path relative to the lib files - the file must be writeable
        \'size\' => 1024
       // maximum size of the log file in octect
        )
);

// redefine the user error constants - Used in the PC custom error handling - PHP 4 only
define(\'FATAL\', E_USER_ERROR);
define(\'ERROR\', E_USER_WARNING);
define(\'WARNING\', E_USER_NOTICE);
?'.'>
';

// defaults
// guess hostname
if (isset($_POST['confirmRetry'])) {
	foreach ($_POST as $key => $val) {
		$defaults[$key] = $val;
	}
} else {
	if (!isset($_SERVER["SERVER_NAME"])) {
			$defaults['domain'] = $_SERVER["SERVER_ADDR"];
	} else {
			$defaults['domain'] = $_SERVER["SERVER_NAME"];
	}
	$defaults['login'] = "pcadmin";
	$defaults['password'] = "";
	$defaults['firstname'] = "default";
	$defaults['lastname'] = "default";
	$defaults['email'] = $defaults['login']."@".$defaults['domain'];
	$defaults['sitename'] = "pointcomma";
	$defaults['dbdomain'] = "localhost";
	$defaults['dbname'] = "pointcomma";
	$defaults['dblogin'] = "";
	$defaults['dbpass'] = "";
	$defaults['dbprefix'] = "pc_";
	// get the path to this pointcomma install
	// we're usualluy in ./lib so we need to get the directory ./lib is in as a url
	$defaults['basepath'] = "http://".$defaults['domain'].dirname($_SERVER['REQUEST_URI']);
	//Framework library path
  $defaults['includePath'] = str_replace('\\', '/', realpath(dirname(__FILE__)).'/').'includes/';
  $defaults['wwwPath'] = str_replace('\\', '/', realpath(dirname(__FILE__)).'/');
  $defaults['pcUploadDir'] = str_replace('\\', '/', realpath(dirname(__FILE__).'/material/').'/');
}

if (!isset($_POST['dbdomain']) || isset($_POST['confirmRetry'])) {
  ?>
<p><b>New install PointComma 3</b></p>
<p>Warning: on an existing PointComma implementation, this installation procedure will fail and <b>destroy all existing data</b>. Please make sure that you run it on an empty database (or that you indeed want to reset your implementation).</p>
<form method="post" action="install.php">
<style>
input {
    width: 90%;
}
</style>
  <table border="0" width="50%" cellspacing="0" cellpadding="0">
    <tr>
      <th colspan="2">First user of the system</th>
    </tr>
    <tr>
      <td colspan="2"><small>Please change this to something sensible.</small></td>
    </tr>
    <tr>
      <td>Login</td>
      <td width="70%"><input type="text" name="login" value="<?php print $defaults['login'] ?>"></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type="password" name="password" value="<?php print $defaults['password'] ?>"></td>
    </tr>
    <tr>
      <td>First name</td>
      <td><input type="text" name="firstname" value="<?php print $defaults['firstname'] ?>"></td>
    </tr>
    <tr>
      <td>Last name</td>
      <td><input type="text" name="lastname" value="<?php print $defaults['lastname'] ?>"></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><input type="text" name="email" value="<?php print $defaults['email'] ?>"></td>
    </tr>
    <tr>
      <th colspan="2">Site</th>
    </tr>
    <tr>
      <td>Site name</td>
      <td><input type="text" name="sitename" value="<?php print $defaults['sitename'] ?>"></td>
    </tr>
    <tr>
      <td>Server name</td>
      <td><input type="text" name="domain" value="<?php print $defaults['domain'] ?>"></td>
    </tr>
    <tr>
      <td>Full Path</td>
      <td><input type="text" name="basepath" value="<?php print $defaults['basepath'] ?>"></td>
    </tr>
    <tr>
      <td>Website Path</td>
      <td><input type="text" name="wwwPath" value="<?php print $defaults['wwwPath'] ?>"></td>
    </tr>
    <tr>
      <td>Framework Path</td>
      <td><input type="text" name="includePath" value="<?php print $defaults['includePath'] ?>"></td>
    </tr>
    <tr>
      <td>Upload directory</td>
      <td><input type="text" name="pcUploadDir" value="<?php print $defaults['pcUploadDir'] ?>"></td>
    </tr>
    <tr>
      <th colspan="2">Database</th>
    </tr>
    <tr>
      <td>Domain</td>
      <td><input type="text" name="dbdomain" value="<?php print $defaults['dbdomain'] ?>"></td>
    </tr>
    <tr>
      <td>Name</td>
      <td><input type="text" name="dbname" value="<?php print $defaults['dbname'] ?>"></td>
    </tr>
    <tr>
      <td>Login</td>
      <td><input type="text" name="dblogin" value="<?php print $defaults['dblogin'] ?>"></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type="password" name="dbpass" value="<?php print $defaults['dbpass'] ?>"></td>
    </tr>
    <tr>
      <td>Prefix</td>
      <td><input type="text" name="dbprefix"  value="<?php print $defaults['dbprefix'] ?>"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" value="Set it up"></td>
    </tr>
  </table>
</form>
<?php
} else {
// Install file for the PointComma publishing system
// DB abstraction layer (included)
include('includes/functions/pcdb_mysql.inc.php');

//For error trigerring:
define('FATAL', E_USER_ERROR);
define('ERROR', E_USER_WARNING);
define('WARNING', E_USER_NOTICE);

// set empty error if not set yet
if (!isset($pcInstallError)) {
$pcInstallError = '';
}

if (!pcdb_connect($_POST['dbdomain'], $_POST['dblogin'], $_POST['dbpass'], $_POST['dbname'])) {
echo '
<h1>Database error</h1>
<p>The server ('.$_POST['dbdomain'].'), user name ('.$_POST['dblogin'].') and password you provided for the database are not working.</p>
<form action="install.php" method="post">';
?>
  <input type="hidden" name="domain" value="<?php echo $_POST['domain']; ?>">
  <input type="hidden" name="basepath" value="<?php echo $_POST['basepath']; ?>">
  <input type="hidden" name="includePath" value="<?php echo $_POST['includePath']; ?>">
  <input type="hidden" name="wwwPath" value="<?php echo $_POST['wwwPath']; ?>">
  <input type="hidden" name="pcUploadDir" value="<?php echo $_POST['pcUploadDir']; ?>">
  <input type="hidden" name="dbdomain" value="<?php echo $_POST['dbdomain']; ?>">
  <input type="hidden" name="dblogin" value="<?php echo $_POST['dblogin']; ?>">
  <input type="hidden" name="dbpass" value="<?php echo $_POST['dbpass']; ?>">
  <input type="hidden" name="dbname" value="<?php echo $_POST['dbname']; ?>">
  <input type="hidden" name="sitename" value="<?php echo $_POST['sitename']; ?>">
  <input type="hidden" name="dbformat" value="multiple">
  <input type="hidden" name="dbprefix" value="<?php echo $_POST['dbprefix']; ?>">
  <input type="hidden" name="login" value="<?php echo $_POST['login']; ?>">
  <input type="hidden" name="password" value="<?php echo $_POST['password']; ?>">
  <input type="hidden" name="firstname" value="<?php echo $_POST['firstname']; ?>">
  <input type="hidden" name="lastname" value="<?php echo $_POST['lastname']; ?>">
  <input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
  <input type="hidden" name="confirmRetry" value="true">
  <p><input type="submit" value="Return to form"></p>
  </form>
  <?php
  $pcInstallError .= 'Fatal error: could not connect to the database';
  exit();
}
if (!isset($_POST['confirmAction'])) {
$_POST['confirmAction']=false;
}
if (!isset($_POST['mustConfirmDrop'])) {
$_POST['mustConfirmDrop']=false;
}
if (!isset($_POST['confirmDrop'])) {
$_POST['confirmDrop']=false;
}

if (!$_POST['confirmAction'] || ($_POST['mustConfirmDrop'] && !$_POST['confirmDrop'])) {
  $tablesExist = array();
  ?>
  <h1>Confirm install</h1>
  <form name="confirm" action="install.php" method="post">
<?php
  if ($_POST['mustConfirmDrop'] && !$_POST['confirmDrop']) {
    echo '<p><b>Error</b>, you must confirm erasing all data before you can continue.</p>';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'assignments` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'assignments';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'authorizations` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'authorizations';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'characteristics` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'characteristics';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'global` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'global';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'items` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'items';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'modules` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'modules';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'profiles` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'profiles';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'roles` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'roles';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'types` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'types';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'webusers` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'webusers';
  }
  if (pcdb_query('SELECT * FROM `'.addslashes($_POST['dbprefix']).'xvals` LIMIT 0')) {
    $tablesExist[] = $_POST['dbprefix'].'xvals';
  }
  if (count($tablesExist)) {
    echo '<p><b>Warning</b>: some required tables already exist ('.implode(', ', $tablesExist).'). If you proceed, you will <b>erase all existing data</b>.</p>
    <p><input type="hidden" name="mustConfirmDrop" value="true"><input type="checkbox" name="confirmDrop" value="drop"> confirm erasing all exiting data</p>';
  }
?>
  <input type="hidden" name="domain" value="<?php echo $_POST['domain']; ?>">
  <input type="hidden" name="sitename" value="<?php echo $_POST['sitename']; ?>">
  <input type="hidden" name="basepath" value="<?php echo $_POST['basepath']; ?>">
  <input type="hidden" name="includePath" value="<?php echo $_POST['includePath']; ?>">
  <input type="hidden" name="wwwPath" value="<?php echo $_POST['wwwPath']; ?>">
  <input type="hidden" name="pcUploadDir" value="<?php echo $_POST['pcUploadDir']; ?>">
  <input type="hidden" name="dbdomain" value="<?php echo $_POST['dbdomain']; ?>">
  <input type="hidden" name="dblogin" value="<?php echo $_POST['dblogin']; ?>">
  <input type="hidden" name="dbpass" value="<?php echo $_POST['dbpass']; ?>">
  <input type="hidden" name="dbname" value="<?php echo $_POST['dbname']; ?>">
  <input type="hidden" name="dbformat" value="multiple">
  <input type="hidden" name="dbprefix" value="<?php echo $_POST['dbprefix']; ?>">
  <input type="hidden" name="login" value="<?php echo $_POST['login']; ?>">
  <input type="hidden" name="password" value="<?php echo $_POST['password']; ?>">
  <input type="hidden" name="firstname" value="<?php echo $_POST['firstname']; ?>">
  <input type="hidden" name="lastname" value="<?php echo $_POST['lastname']; ?>">
  <input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
  <input type="hidden" name="confirmAction" value="true">
  <p>Proceed with install?</p>
  <p><input type="submit" value="YES"> &nbsp; <input type="button" value="NO" onClick="history.go(-1)"></p>
  </form>
  <?php
} else {

$installSuccess = true;

  if (isset($_POST['confirmDrop']) && $_POST['confirmDrop'] == "drop") {
    print "<strong>Cleaning up tables</strong><br>";
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'assignments`') && $installSuccess;
    if ($installSuccess) { print "dropped assignments<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'authorizations`') && $installSuccess;
    if ($installSuccess) { print "dropped authorizations<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'characteristics`') && $installSuccess;
    if ($installSuccess) { print "dropped characteristics<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'global`') && $installSuccess;
    if ($installSuccess) { print "dropped global<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'items`') && $installSuccess;
    if ($installSuccess) { print "dropped items<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'modules`') && $installSuccess;
    if ($installSuccess) { print "dropped modules<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'profiles`') && $installSuccess;
    if ($installSuccess) { print "dropped profiles<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'roles`') && $installSuccess;
    if ($installSuccess) { print "dropped roles<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'types`') && $installSuccess;
    if ($installSuccess) { print "dropped types<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'units`') && $installSuccess;
    if ($installSuccess) { print "dropped webusers<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'xvals`') && $installSuccess;
    if ($installSuccess) { print "dropped sessions<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'webusers`') && $installSuccess;
    if ($installSuccess) { print "dropped sessions<br>"; }
    $installSuccess = pcdb_query('DROP TABLE IF EXISTS `'.addslashes($_POST['dbprefix']).'sessions`') && $installSuccess;
    if ($installSuccess) { print "dropped xvals<br>tables deleted"; } else { print "some tables were not correctly deleted, please delete the tables in the database manually and retry<br>";}
  }

$dropArray = array();

// Creating table assignments

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'assignments` (
    `assignmentId` SMALLINT UNSIGNED NOT NULL auto_increment,
    `userName` varchar(12) NOT NULL default \'\',
    `roleId` mediumint(8) unsigned NOT NULL default \'0\',
    PRIMARY KEY  (`assignmentId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'assignments`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'assignments`</b> ('.mysql_error().').';
}


// Creating table authorizations

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'authorizations` (
    `authId` SMALLINT UNSIGNED NOT NULL auto_increment,
    `roleId` SMALLINT UNSIGNED NOT NULL default \'0\',
    `typeId` varchar(18) NOT NULL default \'\',
    `writeLevel` smallint(1) unsigned NOT NULL default \'0\',
    PRIMARY KEY  (`authId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'authorizations`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'authorizations`</b> ('.mysql_error().').';
}


// Creating table characteristics

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'characteristics` (
    `charId` SMALLINT UNSIGNED NOT NULL auto_increment,
    `columnId` varchar(18) NOT NULL default \'\',
    `typeId` varchar(18) NOT NULL default \'\',
    `sequence` tinyint(3) unsigned default NULL,
    `format` char(1) default NULL,
    `label` varchar(60) NOT NULL default \'\',
    `defining` char(1) NOT NULL default \'0\',
    `limitTo` SMALLINT UNSIGNED default NULL,
    `valuesList` text,
    PRIMARY KEY  (`charId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'characteristics`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'characteristics`</b> ('.mysql_error().').';
}


// Creating table global

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'global` (
    `setting` varchar(60) NOT NULL default \'\',
    `value` varchar(240) default NULL,
    PRIMARY KEY  (`setting`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'global`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'global`</b> ('.mysql_error().').';
}


// Creating table items

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'items` (
    `itemId` mediumint(8) unsigned NOT NULL auto_increment,
    `handle` varchar(120) default NULL,
    `typeId` varchar(18) NOT NULL default \'\',
    `createdOn` date default NULL,
    `lastUpdateOn` date default NULL,
    `lastUpdateBy` varchar(12) default NULL,
    `createdBy` varchar(12) default NULL,
    `pubState` char(1) default \'0\',
    PRIMARY KEY  (`itemId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'items`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'items`</b> ('.mysql_error().').';
}


// Creating table modules

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'modules` (
    `moduleId` varchar(8) NOT NULL default \'\',
    `description` text,
    `label` varchar(240) NOT NULL default \'\',
    PRIMARY KEY  (`moduleId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'modules`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'modules`</b> ('.mysql_error().').';
}


// Creating table profiles

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'profiles` (
    `profileId` SMALLINT UNSIGNED NOT NULL auto_increment,
    `moduleId` varchar(8) NOT NULL default \'\',
    `label` varchar(240) NOT NULL default \'\',
    `description` text,
    `requireAdminConfirm` char(1) default NULL,
    `defaultRoles` varchar(255) default NULL,
    `password` varchar(32) default NULL,
    `adminEmail` varchar(255) default NULL,
    `signupMsg` text,
    `adminMsg` text,
    `confirmMsg` text,
    `passwdMsg` text,
    `signupSubj` varchar(255) default NULL,
    `adminSubj` varchar(255) default NULL,
    `confirmSubj` varchar(255) default NULL,
    `passwdSubj` varchar(255) default NULL,
    PRIMARY KEY  (`profileId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'profiles`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'profiles`</b> ('.mysql_error().').';
}


// Creating table roles

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'roles` (
    `roleId` SMALLINT UNSIGNED NOT NULL auto_increment,
    `moduleId` varchar(8) NOT NULL default \'\',
    `label` varchar(240) NOT NULL default \'\',
    `description` text NOT NULL,
    `isModuleSupervisor` char(1) NOT NULL default \'0\',
    `isModuleMgr` char(1) NOT NULL default \'0\',
    PRIMARY KEY  (`roleId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'roles`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'roles`</b> ('.mysql_error().').';
}


// Creating table types

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'types` (
    `typeId` varchar(18) NOT NULL default \'\',
    `moduleId` varchar(8) NOT NULL default \'\',
    `label` varchar(60) default NULL,
    `inherit_from` varchar(18) NOT NULL default \'\',
    `lastUpdateBy` varchar(12) default NULL,
    `createdBy` varchar(12) default NULL,
    PRIMARY KEY  (`typeId`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'types`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'types`</b> ('.mysql_error().').';
}

// Creating table webusers

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'webusers` (
    `userName` varchar(12) NOT NULL default \'\',
    `status` tinyint(1) unsigned NOT NULL default \'0\',
    `password` varchar(32) default NULL,
    `firstName` varchar(60) default NULL,
    `lastName` varchar(60) default NULL,
    `eMail` varchar(120) default NULL,
    `newEMail` varchar(120) default NULL,
    `createdBy` varchar(24) default NULL,
    `emailToken` varchar(32) default NULL,
    `createdOn` datetime NOT NULL default \'0000-00-00 00:00:00\',
    `activeSince` datetime NOT NULL default \'0000-00-00 00:00:00\',
    `isFrameworkMgr` char(1) NOT NULL default \'0\',
    `isSupervisor` char(1) NOT NULL default \'0\',
    PRIMARY KEY  (`userName`)
  )
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'webusers`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'webusers`</b> ('.mysql_error().').';
}

// Creating table sessions

if (pcdb_query('
  CREATE TABLE `'.addslashes($_POST['dbprefix']).'sessions` (
  `strSessionId` varchar(32) NOT NULL default \'\',
  `intDeathTime` int(11) NOT NULL default \'0\',
  `strSessionData` longtext NOT NULL,
  PRIMARY KEY  (`strSessionId`)
);
')) {
  $dropArray[] = 'DROP TABLE `'.addslashes($_POST['dbprefix']).'sessions`;';
} else {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem with table <b>`'.addslashes($_POST['dbprefix']).'sessions`</b> ('.mysql_error().').';
}

// Inserting first user

if (!pcdb_query('INSERT INTO `'.addslashes($_POST['dbprefix'])."webusers` (`userName`, `password`, `status`, `firstName`, `lastName`, `eMail`, `createdBy`, `createdOn`, `isFrameworkMgr`, `isSupervisor`) VALUES ('".addslashes($_POST['login'])."','".md5($_POST['password'])."',3,'".addslashes($_POST['firstname'])."','".addslashes($_POST['lastname'])."','".addslashes($_POST['email'])."','_install',NOW(),'1','1')")) {
  $installSuccess = false;
  $pcInstallError .= '<br>Problem creating the <b>admin user</b> (name: '.addslashes($_POST['login']).', password: '.addslashes($_POST['password']).').';
}

if ($installSuccess) {
?>
  <p><b>Install completed</b></p>
  <p>Don't forget to delete <code><b>install.php</b></code> from the root directory of your web site, for safety purposes. Note that a potential attacker would have to know your database user name and password to successfully make use of that file. If access is granted, your entire PointComma database could be erased.</p>
<?php
// prepare configuratiuon file
if (isset($defaults) && is_array($defaults)) {
    foreach ($defaults as $key => $value) {
        $current[$key] = $value;
    }
    if (isset($_POST) && is_array($_POST)) {
        foreach ($_POST as $key => $value) {
            $current[$key] = $value;
        }
    }
    $patterns = array(
        '/\[dbhost\]/i',
        '/\[dbname\]/i',
        '/\[dblogin\]/i',
        '/\[dbpass\]/i',
        '/\[dbprefix\]/i',
        '/\[sitename\]/i',
        '/\[hostname\]/i',
        '/\[includePath\]/i',
        '/\[wwwPath\]/i',
        '/\[pcUploadDir\]/i',
        '/\[email\]/i'
    );
    $replaces = array(
        $current['dbdomain'],
        $current['dbname'],
        $current['dblogin'],
        $current['dbpass'],
        $current['dbprefix'],
        $current['sitename'],
        (substr($current['basepath'], -1)=='/')?substr($current['basepath'], 0, -1):$current['basepath'],
        $current['includePath'],
        $current['wwwPath'],
        $current['pcUploadDir'],
        $current['email']
    );
    $pcConfigTemplate = preg_replace($patterns,$replaces,$pcConfigTemplate);
}
// check if the file is writable
$configfile = "config.inc.php";
// Let's make sure the file exists and is writable first.
// create it if it's not there
if (!file_exists($configfile)) {
    $created = touch($configfile);
} else {
/// if it's there, move it to a backup
    if (file_exists ($configfile.'.delete_old_backups.php')){
        unlink ($configfile.'.delete_old_backups.php');
        print "<strong>Really old backup found, please cleanup the directory first next time you reinstall...</strong><br>";
    }
    if (file_exists ($configfile.'.bak.php')) {
        rename($configfile.'.bak.php', $configfile.'.delete_old_backups.php');
        print "Old backup found, please cleanup the directory first next time you reinstall...<br>";
    }
    if (rename($configfile, $configfile.'.bak.php')) {
        print "Backed up $configfile...<br>";
// then delete the original
        $created = touch($configfile);
    }
}
if (is_writable($configfile) || isset($created)) {
    // write the file
    if (!$handle = fopen($configfile, 'a')) {
        // opening failed
        print "<h2>Config file not written (no handle)</h2>";
        print "<p>Due to a technical error, the configuration file was not automatically generated.<br>The following lines of code are the contents of the global configuration file, you <strong>must copy</strong> those lines and place them in <code>config.inc.php</code> in the root directory of your site.</p>";
    } else {
        if (fwrite($handle, $pcConfigTemplate) === FALSE) {
            // writing failed
            print "<h2>Config file not written (write failed)</h2>";
            print "<p>Due to a technical error, the configuration file was not automatically generated.<br>The following lines of code are the contents of the global configuration file, you <strong>must copy</strong> those lines and place them in <code>config.inc.php</code> in the root directory of your site.</p>";
        } else {
            print "<h2>Config written</h2>";
            print "<p>Your configuration file is automatically generated.<br>You can find the configuration in <code>config.inc.php</code> in your <code>lib</code> directory.<br>For your information, the following lines were added.</p>";
        }
        fclose($handle);
    }
} else {
    // config not writable
    print "<h2>Config file not writable</h2>";
    print "<p>Due to a wrong permissions, the configuration file was not automatically generated.<br>The following lines of code are the contents of the global configuration file, you <strong>must copy</strong> those lines and place them in <code>config.inc.php</code> in the root directory of your site.</p>";
}
print "<hr><pre>";
print htmlentities($pcConfigTemplate);
print "</pre><hr>";
echo '<p><strong>Do not forget to change the permissions on the folders used by Smarty:</strong><br/>';
echo 'By default the cache and templates_c folder are located in '.$defaults['includePath'].' and must be writable by the web server<br/>';
echo 'By default the templates and configs folder are located in '.$defaults['wwwPath'].'<br/>';
echo 'If you moved those folders from the default location, please update <code>config.inc.php</code><br/>';
echo '<br/>';
echo "If you want to use the template engine independantly, just require \$pcConfig['includePath'].\$pcConfig['classFolder'].'pcTemplate.php'</p>";
?>
  <p><a href='admin/'>Go to the admin interface.</a></p>
  <?php
} else {
  $cleanupSuccess = true;
  foreach ($dropArray as $dropOne) {
    if ($dropOne != '') {
      if (!pcdb_query($dropOne)) {
        $cleanupSuccess = false;
      }
    }
  }
  if ($cleanupSuccess) {
?>
  <p><b>Problem with installing the tables</b>: <?php echo $pcInstallError ?><br>Faulty installation cleaned up.<br><br><b>The system was NOT installed correctly.</b></p>
<?php
  } else {
?>
  <p><b>Big problem with the database</b>.<br><br><b>The system was NOT installed correctly.</b></p>
<?php
  }
}
}
}
?>
</body>
</html>
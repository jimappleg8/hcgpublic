<?php /* Smarty version 2.6.9, created on 2005-04-20 11:27:49
         compiled from pcerror_user.tpl */ ?>
<div id="errmsg">
<?php if ($this->_tpl_vars['arrayErrorMessage']): ?>
	<p class="ErrorMessage">	
<?php $_from = $this->_tpl_vars['arrayErrorMessage']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['currentMsg']):
?>
		<strong>Error:</strong><br/>
		<?php echo $this->_tpl_vars['currentMsg']; ?>
<br/>
<?php endforeach; endif; unset($_from); ?>
	</p>
<?php endif; ?>

<?php if ($this->_tpl_vars['arrayWarningMessage']): ?>
	<p class="WarningMessage">
		<strong>Information:</strong><br/>
<?php $_from = $this->_tpl_vars['arrayWarningMessage']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['currentMsg']):
?>
		<?php echo $this->_tpl_vars['currentMsg']; ?>
<br/>
<?php endforeach; endif; unset($_from); ?>
	</p>
<?php endif; ?>

<?php if ($this->_tpl_vars['arrayMiscMessage']): ?>
	<p class="MiscMessage">
		<strong>Misc Error:</strong><br/>
<?php $_from = $this->_tpl_vars['arrayMiscMessage']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['currentMsg']):
?>
		<?php echo $this->_tpl_vars['currentMsg']; ?>
<br/>
<?php endforeach; endif; unset($_from); ?>
	</p>
<?php endif; ?>
</div>
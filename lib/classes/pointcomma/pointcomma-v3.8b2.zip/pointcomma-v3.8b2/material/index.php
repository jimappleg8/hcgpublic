<?php
header('Location: ../');